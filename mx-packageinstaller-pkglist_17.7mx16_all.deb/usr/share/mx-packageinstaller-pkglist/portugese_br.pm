<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Portugese(BR) 
</name>

<description>  
Portugese(BR) Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-pt-br
      myspell-pt-br
      manpages-pt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-pt-br
      myspell-pt-br
      manpages-pt
</uninstall_package_names>
</app>