<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>  
Palemoon
</name>

<description>  
Palemoon from the mx repo
</description>

<installable>
all
</installable>

<screenshot>http://www.palemoon.org/images/screenshots/Win10-start-portal-th.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
palemoon
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
palemoon
</uninstall_package_names>
</app>