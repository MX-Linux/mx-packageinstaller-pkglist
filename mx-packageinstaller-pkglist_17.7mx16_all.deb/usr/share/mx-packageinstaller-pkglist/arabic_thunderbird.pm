<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Arabic_Thunderbird
</name>

<description>  
Arabic localisation of Thunderbird
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-xpi-ar
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-xpi-ar
</uninstall_package_names>
</app>