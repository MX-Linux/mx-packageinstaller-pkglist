<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Portugese(PT) Thunderbird
</name>

<description>  
Portugese(PT) localisation of Thunderbird
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-xpi-pt-pt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-xpi-pt-pt
</uninstall_package_names>
</app>