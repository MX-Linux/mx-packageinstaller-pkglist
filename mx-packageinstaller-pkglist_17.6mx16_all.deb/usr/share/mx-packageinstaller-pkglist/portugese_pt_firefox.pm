<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Portugese(PT) Firefox
</name>

<description>  
Portugese(PT) localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-pt-pt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-pt-pt
</uninstall_package_names>
</app>