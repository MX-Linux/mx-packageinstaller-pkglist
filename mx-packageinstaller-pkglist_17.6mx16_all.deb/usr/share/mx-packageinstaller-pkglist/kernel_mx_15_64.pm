<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
MX15 64 bit
</name>

<description>  
Default Kernel MX-15 64 bit (4.2)
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.2.0-0.bpo.1-amd64
linux-headers-4.2.0-0.bpo.1-amd64
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.2.0-0.bpo.1-amd64
linux-headers-4.2.0-0.bpo.1-amd64
</uninstall_package_names>
</app>