<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Slovenian_Firefox
</name>

<description>  
Slovenian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sl
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sl
</uninstall_package_names>
</app>