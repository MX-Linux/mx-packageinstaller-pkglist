<?xml version="1.0"?>
<app>

<category>
Printing
</category>

<name>  
HP Printing extras
</name>

<description>  
HP printing extras
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
printer-driver-hpijs
hpijs-ppds
hplip-data
hplip-gui
cups
cups-pdf
cups-client
magicfilter
gv
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
printer-driver-hpijs
hpijs-ppds
hplip-data
hplip-gui
magicfilter
gv
</uninstall_package_names>
</app>