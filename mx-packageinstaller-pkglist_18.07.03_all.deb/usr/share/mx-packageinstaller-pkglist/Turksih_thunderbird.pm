<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Turkish_Thunderbird
</name>

<description>
   <am>Turkish localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Turc</ca>
   <cs>Turkish localisation of Thunderbird</cs>
   <de>Türkische Lokalisierung von Thunderbird</de>
   <el>Turkish localisation of Thunderbird</el>
   <en>Turkish localisation of Thunderbird</en>
   <es>Turkish localisation of Thunderbird</es>
   <fi>Turkish localisation of Thunderbird</fi>
   <fr>Turkish localisation of Thunderbird</fr>
   <hi>Turkish localisation of Thunderbird</hi>
   <hr>Turkish localisation of Thunderbird</hr>
   <hu>Turkish localisation of Thunderbird</hu>
   <it>Turkish localisation of Thunderbird</it>
   <ja>Turkish localisation of Thunderbird</ja>
   <kk>Turkish localisation of Thunderbird</kk>
   <lt>Turkish localisation of Thunderbird</lt>
   <nl>Turkish localisation of Thunderbird</nl>
   <pl>Turkish localisation of Thunderbird</pl>
   <pt_BR>Turkish localisation of Thunderbird</pt_BR>
   <pt>Turkish localisation of Thunderbird</pt>
   <ro>Turkish localisation of Thunderbird</ro>
   <ru>Turkish localisation of Thunderbird</ru>
   <sk>Turkish localisation of Thunderbird</sk>
   <sv>Turkisk lokalisering av Thunderbird</sv>
   <tr>Turkish localisation of Thunderbird</tr>
   <uk>Turkish localisation of Thunderbird</uk>
   <zh_TW>Turkish localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-tr
lightning-l10n-tr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-tr
lightning-l10n-tr
</uninstall_package_names>
</app>
