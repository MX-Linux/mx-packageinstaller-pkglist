<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>
Moka/Faba Icon Themes
</name>

<description>
   <am>a comprehensive icon set with a uniform flat "rounded square" look</am>
   <ca>a comprehensive icon set with a uniform flat "rounded square" look</ca>
   <cs>a comprehensive icon set with a uniform flat "rounded square" look</cs>
   <de>Ein umfangreiches Icon-Set in einheitlich flacher "runder quadratischer" Optik</de>
   <el>a comprehensive icon set with a uniform flat "rounded square" look</el>
   <en>a comprehensive icon set with a uniform flat "rounded square" look</en>
   <es>a comprehensive icon set with a uniform flat "rounded square" look</es>
   <fi>a comprehensive icon set with a uniform flat "rounded square" look</fi>
   <fr>a comprehensive icon set with a uniform flat "rounded square" look</fr>
   <hi>a comprehensive icon set with a uniform flat "rounded square" look</hi>
   <hr>a comprehensive icon set with a uniform flat "rounded square" look</hr>
   <hu>a comprehensive icon set with a uniform flat "rounded square" look</hu>
   <it>a comprehensive icon set with a uniform flat "rounded square" look</it>
   <ja>a comprehensive icon set with a uniform flat "rounded square" look</ja>
   <kk>a comprehensive icon set with a uniform flat "rounded square" look</kk>
   <lt>a comprehensive icon set with a uniform flat "rounded square" look</lt>
   <nl>a comprehensive icon set with a uniform flat "rounded square" look</nl>
   <pl>a comprehensive icon set with a uniform flat "rounded square" look</pl>
   <pt_BR>a comprehensive icon set with a uniform flat "rounded square" look</pt_BR>
   <pt>a comprehensive icon set with a uniform flat "rounded square" look</pt>
   <ro>a comprehensive icon set with a uniform flat "rounded square" look</ro>
   <ru>a comprehensive icon set with a uniform flat "rounded square" look</ru>
   <sk>a comprehensive icon set with a uniform flat "rounded square" look</sk>
   <sv>ett omfattande ikon-set med en uniform platt "rundad fyrkant" look</sv>
   <tr>a comprehensive icon set with a uniform flat "rounded square" look</tr>
   <uk>a comprehensive icon set with a uniform flat "rounded square" look</uk>
   <zh_TW>a comprehensive icon set with a uniform flat "rounded square" look</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
moka-icon-theme
faba-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
moka-icon-theme
faba-icon-theme
</uninstall_package_names>
</app>
