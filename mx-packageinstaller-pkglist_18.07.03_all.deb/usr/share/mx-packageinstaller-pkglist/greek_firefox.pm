<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Greek_Firefox
</name>

<description>
   <am>Greek localisation of Firefox</am>
   <ca>Localització de Firefox en Grec</ca>
   <cs>Greek localisation of Firefox</cs>
   <de>Griechische Lokalisierung von Firefox</de>
   <el>Greek localisation of Firefox</el>
   <en>Greek localisation of Firefox</en>
   <es>Greek localisation of Firefox</es>
   <fi>Greek localisation of Firefox</fi>
   <fr>Greek localisation of Firefox</fr>
   <hi>Greek localisation of Firefox</hi>
   <hr>Greek localisation of Firefox</hr>
   <hu>Greek localisation of Firefox</hu>
   <it>Greek localisation of Firefox</it>
   <ja>Greek localisation of Firefox</ja>
   <kk>Greek localisation of Firefox</kk>
   <lt>Greek localisation of Firefox</lt>
   <nl>Greek localisation of Firefox</nl>
   <pl>Greek localisation of Firefox</pl>
   <pt_BR>Greek localisation of Firefox</pt_BR>
   <pt>Greek localisation of Firefox</pt>
   <ro>Greek localisation of Firefox</ro>
   <ru>Greek localisation of Firefox</ru>
   <sk>Greek localisation of Firefox</sk>
   <sv>Grekisk lokalisering för Firefox</sv>
   <tr>Greek localisation of Firefox</tr>
   <uk>Greek localisation of Firefox</uk>
   <zh_TW>Greek localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-el
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-el
</uninstall_package_names>
</app>
