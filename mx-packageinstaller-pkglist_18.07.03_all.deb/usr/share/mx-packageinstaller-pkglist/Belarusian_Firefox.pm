<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Belarusian_Firefox
</name>

<description>
   <am>Belarusian localisation of Firefox</am>
   <ca>Localització de Firefox en Belarus</ca>
   <cs>Belarusian localisation of Firefox</cs>
   <de>Weißrussische Lokalisierung von Firefox</de>
   <el>Belarusian localisation of Firefox</el>
   <en>Belarusian localisation of Firefox</en>
   <es>Belarusian localisation of Firefox</es>
   <fi>Belarusian localisation of Firefox</fi>
   <fr>Localisation biélorusse pour Firefox</fr>
   <hi>Belarusian localisation of Firefox</hi>
   <hr>Bjeloruska lokalizacija Firefoxa</hr>
   <hu>Belarusian localisation of Firefox</hu>
   <it>Localizzazione bielorussa di Firefox</it>
   <ja>Belarusian localisation of Firefox</ja>
   <kk>Belarusian localisation of Firefox</kk>
   <lt>Belarusian localisation of Firefox</lt>
   <nl>Belarusian localisation of Firefox</nl>
   <pl>Belarusian localisation of Firefox</pl>
   <pt_BR>Belarusian localisation of Firefox</pt_BR>
   <pt>Belarusian localisation of Firefox</pt>
   <ro>Belarusian localisation of Firefox</ro>
   <ru>Belarusian localisation of Firefox</ru>
   <sk>Belarusian localisation of Firefox</sk>
   <sv>Belarus lokalisering av Firefox</sv>
   <tr>Belarusian localisation of Firefox</tr>
   <uk>Belarusian localisation of Firefox</uk>
   <zh_TW>Belarusian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-be
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-be
</uninstall_package_names>
</app>
