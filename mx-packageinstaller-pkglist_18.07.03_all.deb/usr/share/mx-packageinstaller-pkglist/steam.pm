<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>
Steam
</name>

<description>
   <am>Steam powered games</am>
   <ca>Steam powered games</ca>
   <cs>Steam powered games</cs>
   <de>Steam powered Games</de>
   <el>Steam powered games</el>
   <en>Steam powered games</en>
   <es>Steam powered games</es>
   <fi>Steam powered games</fi>
   <fr>Steam powered games</fr>
   <hi>Steam powered games</hi>
   <hr>Steam powered games</hr>
   <hu>Steam powered games</hu>
   <it>Steam powered games</it>
   <ja>Steam powered games</ja>
   <kk>Steam powered games</kk>
   <lt>Steam powered games</lt>
   <nl>Steam powered games</nl>
   <pl>Steam powered games</pl>
   <pt_BR>Steam powered games</pt_BR>
   <pt>Steam powered games</pt>
   <ro>Steam powered games</ro>
   <ru>Steam powered games</ru>
   <sk>Steam powered games</sk>
   <sv>Steam-drivna spel</sv>
   <tr>Steam powered games</tr>
   <uk>Steam powered games</uk>
   <zh_TW>Steam powered games</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/991/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
steam
</install_package_names>


<postinstall>
apt-get install -f
</postinstall>


<uninstall_package_names>
steam
</uninstall_package_names>
</app>
