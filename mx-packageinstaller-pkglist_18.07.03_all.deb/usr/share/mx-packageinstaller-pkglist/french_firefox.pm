<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
French_Firefox
</name>

<description>
   <am>French localisation of Firefox</am>
   <ca>Localització de Firefox en Francès</ca>
   <cs>French localisation of Firefox</cs>
   <de>Französische Lokalisierung von Firefox</de>
   <el>French localisation of Firefox</el>
   <en>French localisation of Firefox</en>
   <es>French localisation of Firefox</es>
   <fi>French localisation of Firefox</fi>
   <fr>French localisation of Firefox</fr>
   <hi>French localisation of Firefox</hi>
   <hr>French localisation of Firefox</hr>
   <hu>French localisation of Firefox</hu>
   <it>French localisation of Firefox</it>
   <ja>French localisation of Firefox</ja>
   <kk>French localisation of Firefox</kk>
   <lt>French localisation of Firefox</lt>
   <nl>French localisation of Firefox</nl>
   <pl>French localisation of Firefox</pl>
   <pt_BR>French localisation of Firefox</pt_BR>
   <pt>French localisation of Firefox</pt>
   <ro>French localisation of Firefox</ro>
   <ru>French localisation of Firefox</ru>
   <sk>French localisation of Firefox</sk>
   <sv>Fransk lokalisering av Firefox</sv>
   <tr>French localisation of Firefox</tr>
   <uk>French localisation of Firefox</uk>
   <zh_TW>French localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-fr
</uninstall_package_names>
</app>
