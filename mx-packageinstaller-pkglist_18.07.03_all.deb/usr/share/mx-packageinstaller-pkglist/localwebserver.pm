<?xml version="1.0"?>
<app>

<category>
Server
</category>

<name>
Local Web Server
</name>

<description>
   <am>apache2, php7, mariaDB</am>
   <ca>apache2, php7, mariaDB</ca>
   <cs>apache2, php7, mariaDB</cs>
   <de>Apache2, PHP7, MariaDB</de>
   <el>apache2, php7, mariaDB</el>
   <en>apache2, php7, mariaDB</en>
   <es>apache2, php7, mariaDB</es>
   <fi>apache2, php7, mariaDB</fi>
   <fr>apache2, php7, mariaDB</fr>
   <hi>apache2, php7, mariaDB</hi>
   <hr>apache2, php7, mariaDB</hr>
   <hu>apache2, php7, mariaDB</hu>
   <it>apache2, php7, mariaDB</it>
   <ja>apache2, php7, mariaDB</ja>
   <kk>apache2, php7, mariaDB</kk>
   <lt>apache2, php7, mariaDB</lt>
   <nl>apache2, php7, mariaDB</nl>
   <pl>apache2, php7, mariaDB</pl>
   <pt_BR>apache2, php7, mariaDB</pt_BR>
   <pt>apache2, php7, mariaDB</pt>
   <ro>apache2, php7, mariaDB</ro>
   <ru>apache2, php7, mariaDB</ru>
   <sk>apache2, php7, mariaDB</sk>
   <sv>apache2, php7, mariaDB</sv>
   <tr>apache2, php7, mariaDB</tr>
   <uk>apache2, php7, mariaDB</uk>
   <zh_TW>apache2, php7, mariaDB</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
apache2
apache2-utils
curl
mariadb-server
mariadb-client
php7.0
libapache2-mod-php7.0
php7.0-mysql
php-common
php7.0-cli
php7.0-common
php7.0-json
php7.0-opcache
php7.0-readline
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
apache2
apache2-utils
curl
mariadb-server
mariadb-client
php7.0
libapache2-mod-php7.0
php7.0-mysql
php-common
php7.0-cli
php7.0-common
php7.0-json
php7.0-opcache
php7.0-readline
</uninstall_package_names>
</app>
