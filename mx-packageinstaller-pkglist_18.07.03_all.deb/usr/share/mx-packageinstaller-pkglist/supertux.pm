<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>
SuperTux
</name>

<description>
   <am>Mario style platform game w/ Tux</am>
   <ca>Mario style platform game w/ Tux</ca>
   <cs>Mario style platform game w/ Tux</cs>
   <de>Mario Style Plattformspiel mit Tux</de>
   <el>Mario style platform game w/ Tux</el>
   <en>Mario style platform game w/ Tux</en>
   <es>Mario style platform game w/ Tux</es>
   <fi>Mario style platform game w/ Tux</fi>
   <fr>Jeu de plate-formes de style Mario, mais avec Tux</fr>
   <hi>Mario style platform game w/ Tux</hi>
   <hr>Mario style platform game w/ Tux</hr>
   <hu>Mario style platform game w/ Tux</hu>
   <it>Mario style platform game w/ Tux</it>
   <ja>Mario style platform game w/ Tux</ja>
   <kk>Mario style platform game w/ Tux</kk>
   <lt>Mario style platform game w/ Tux</lt>
   <nl>Mario style platform game w/ Tux</nl>
   <pl>Mario style platform game w/ Tux</pl>
   <pt_BR>Mario style platform game w/ Tux</pt_BR>
   <pt>Mario style platform game w/ Tux</pt>
   <ro>Mario style platform game w/ Tux</ro>
   <ru>Mario style platform game w/ Tux</ru>
   <sk>Mario style platform game w/ Tux</sk>
   <sv>Plattformsspel i Mariostil med Tux</sv>
   <tr>Mario style platform game w/ Tux</tr>
   <uk>Mario style platform game w/ Tux</uk>
   <zh_TW>Mario style platform game w/ Tux</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/007/228/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
supertux
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
supertux
</uninstall_package_names>
</app>
