<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Serbian_Firefox
</name>

<description>
   <am>Serbian localisation of Firefox</am>
   <ca>Localització de Firefox en Serbi</ca>
   <cs>Serbian localisation of Firefox</cs>
   <de>Serbische Lokalisierung von Firefox</de>
   <el>Serbian localisation of Firefox</el>
   <en>Serbian localisation of Firefox</en>
   <es>Serbian localisation of Firefox</es>
   <fi>Serbian localisation of Firefox</fi>
   <fr>Serbian localisation of Firefox</fr>
   <hi>Serbian localisation of Firefox</hi>
   <hr>Serbian localisation of Firefox</hr>
   <hu>Serbian localisation of Firefox</hu>
   <it>Serbian localisation of Firefox</it>
   <ja>Serbian localisation of Firefox</ja>
   <kk>Serbian localisation of Firefox</kk>
   <lt>Serbian localisation of Firefox</lt>
   <nl>Serbian localisation of Firefox</nl>
   <pl>Serbian localisation of Firefox</pl>
   <pt_BR>Serbian localisation of Firefox</pt_BR>
   <pt>Serbian localisation of Firefox</pt>
   <ro>Serbian localisation of Firefox</ro>
   <ru>Serbian localisation of Firefox</ru>
   <sk>Serbian localisation of Firefox</sk>
   <sv>Serbisk  lokalisering av Firefox</sv>
   <tr>Serbian localisation of Firefox</tr>
   <uk>Serbian localisation of Firefox</uk>
   <zh_TW>Serbian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sr
</uninstall_package_names>
</app>
