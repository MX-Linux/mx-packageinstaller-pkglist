<?xml version="1.0"?>
<app>

<category>
Torrent
</category>

<name>
qBittorrent
</name>

<description>
   <am>a QT4 feature rich but lightweight client that is very similar to uTorrent</am>
   <ca>a QT4 feature rich but lightweight client that is very similar to uTorrent</ca>
   <cs>a QT4 feature rich but lightweight client that is very similar to uTorrent</cs>
   <de>Ein Qt4-Client mit vielen Funktionen, der dem µTorrent sehr ähnlich ist.</de>
   <el>a QT4 feature rich but lightweight client that is very similar to uTorrent</el>
   <en>a QT4 feature rich but lightweight client that is very similar to uTorrent</en>
   <es>a QT4 feature rich but lightweight client that is very similar to uTorrent</es>
   <fi>a QT4 feature rich but lightweight client that is very similar to uTorrent</fi>
   <fr>a QT4 feature rich but lightweight client that is very similar to uTorrent</fr>
   <hi>a QT4 feature rich but lightweight client that is very similar to uTorrent</hi>
   <hr>a QT4 feature rich but lightweight client that is very similar to uTorrent</hr>
   <hu>a QT4 feature rich but lightweight client that is very similar to uTorrent</hu>
   <it>a QT4 feature rich but lightweight client that is very similar to uTorrent</it>
   <ja>a QT4 feature rich but lightweight client that is very similar to uTorrent</ja>
   <kk>a QT4 feature rich but lightweight client that is very similar to uTorrent</kk>
   <lt>a QT4 feature rich but lightweight client that is very similar to uTorrent</lt>
   <nl>a QT4 feature rich but lightweight client that is very similar to uTorrent</nl>
   <pl>a QT4 feature rich but lightweight client that is very similar to uTorrent</pl>
   <pt_BR>a QT4 feature rich but lightweight client that is very similar to uTorrent</pt_BR>
   <pt>a QT4 feature rich but lightweight client that is very similar to uTorrent</pt>
   <ro>a QT4 feature rich but lightweight client that is very similar to uTorrent</ro>
   <ru>a QT4 feature rich but lightweight client that is very similar to uTorrent</ru>
   <sk>a QT4 feature rich but lightweight client that is very similar to uTorrent</sk>
   <sv>en Qt4 lättvikts klient rik på möjligheter som är mycket lik uTorrent</sv>
   <tr>a QT4 feature rich but lightweight client that is very similar to uTorrent</tr>
   <uk>a QT4 feature rich but lightweight client that is very similar to uTorrent</uk>
   <zh_TW>a QT4 feature rich but lightweight client that is very similar to uTorrent</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/486/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qbittorrent
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qbittorrent
</uninstall_package_names>
</app>
