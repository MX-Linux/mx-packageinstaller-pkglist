<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>
Qupzilla
</name>

<description>
   <am>Latest Qupzilla lightweight browser</am>
   <ca>Darrera versió del navegador lleuger Qupzilla</ca>
   <cs>Latest Qupzilla lightweight browser</cs>
   <de>Neuester Qupzilla leichtgewichtiger Browser</de>
   <el>Latest Qupzilla lightweight browser</el>
   <en>Latest Qupzilla lightweight browser</en>
   <es>Latest Qupzilla lightweight browser</es>
   <fi>Latest Qupzilla lightweight browser</fi>
   <fr>Latest Qupzilla lightweight browser</fr>
   <hi>Latest Qupzilla lightweight browser</hi>
   <hr>Latest Qupzilla lightweight browser</hr>
   <hu>Latest Qupzilla lightweight browser</hu>
   <it>Latest Qupzilla lightweight browser</it>
   <ja>Latest Qupzilla lightweight browser</ja>
   <kk>Latest Qupzilla lightweight browser</kk>
   <lt>Latest Qupzilla lightweight browser</lt>
   <nl>Latest Qupzilla lightweight browser</nl>
   <pl>Latest Qupzilla lightweight browser</pl>
   <pt_BR>Latest Qupzilla lightweight browser</pt_BR>
   <pt>Latest Qupzilla lightweight browser</pt>
   <ro>Latest Qupzilla lightweight browser</ro>
   <ru>Latest Qupzilla lightweight browser</ru>
   <sk>Latest Qupzilla lightweight browser</sk>
   <sv>Senaste Qupzilla lättviktswebbläsare</sv>
   <tr>Latest Qupzilla lightweight browser</tr>
   <uk>Latest Qupzilla lightweight browser</uk>
   <zh_TW>Latest Qupzilla lightweight browser</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/301/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qupzilla
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qupzilla
</uninstall_package_names>
</app>
