<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>
Preschool
</name>

<description>
   <am>Pre-School. Includes: gamine, gcompris and tuxpaint</am>
   <ca>Pre-escolar: inclou gamine, gcompris i tuxpaint</ca>
   <cs>Pre-School. Includes: gamine, gcompris and tuxpaint</cs>
   <de>Vorschule: Inklusive Gamine, Gcompris und Tuxpaint</de>
   <el>Pre-School. Includes: gamine, gcompris and tuxpaint</el>
   <en>Pre-School. Includes: gamine, gcompris and tuxpaint</en>
   <es>Pre-School. Includes: gamine, gcompris and tuxpaint</es>
   <fi>Pre-School. Includes: gamine, gcompris and tuxpaint</fi>
   <fr>Pre-School. Includes: gamine, gcompris and tuxpaint</fr>
   <hi>Pre-School. Includes: gamine, gcompris and tuxpaint</hi>
   <hr>Pre-School. Includes: gamine, gcompris and tuxpaint</hr>
   <hu>Pre-School. Includes: gamine, gcompris and tuxpaint</hu>
   <it>Pre-School. Includes: gamine, gcompris and tuxpaint</it>
   <ja>Pre-School. Includes: gamine, gcompris and tuxpaint</ja>
   <kk>Pre-School. Includes: gamine, gcompris and tuxpaint</kk>
   <lt>Pre-School. Includes: gamine, gcompris and tuxpaint</lt>
   <nl>Pre-School. Includes: gamine, gcompris and tuxpaint</nl>
   <pl>Pre-School. Includes: gamine, gcompris and tuxpaint</pl>
   <pt_BR>Pre-School. Includes: gamine, gcompris and tuxpaint</pt_BR>
   <pt>Pre-School. Includes: gamine, gcompris and tuxpaint</pt>
   <ro>Pre-School. Includes: gamine, gcompris and tuxpaint</ro>
   <ru>Pre-School. Includes: gamine, gcompris and tuxpaint</ru>
   <sk>Pre-School. Includes: gamine, gcompris and tuxpaint</sk>
   <sv>Pre-School. Inkluderar: gamine, gcompris och tuxpaint</sv>
   <tr>Pre-School. Includes: gamine, gcompris and tuxpaint</tr>
   <uk>Pre-School. Includes: gamine, gcompris and tuxpaint</uk>
   <zh_TW>Pre-School. Includes: gamine, gcompris and tuxpaint</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gamine
gcompris
gcompris-sound-en
tuxpaint
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gamine
gcompris
gcompris-sound-en
tuxpaint
</uninstall_package_names>
</app>
