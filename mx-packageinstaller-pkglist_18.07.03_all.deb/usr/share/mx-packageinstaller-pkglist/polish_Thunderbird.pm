<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Polish_Thunderbird
</name>

<description>
   <am>Polish localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Polonès</ca>
   <cs>Polish localisation of Thunderbird</cs>
   <de>Polnische Lokalisierung von Thunderbird</de>
   <el>Polish localisation of Thunderbird</el>
   <en>Polish localisation of Thunderbird</en>
   <es>Polish localisation of Thunderbird</es>
   <fi>Polish localisation of Thunderbird</fi>
   <fr>Polish localisation of Thunderbird</fr>
   <hi>Polish localisation of Thunderbird</hi>
   <hr>Polish localisation of Thunderbird</hr>
   <hu>Polish localisation of Thunderbird</hu>
   <it>Polish localisation of Thunderbird</it>
   <ja>Polish localisation of Thunderbird</ja>
   <kk>Polish localisation of Thunderbird</kk>
   <lt>Polish localisation of Thunderbird</lt>
   <nl>Polish localisation of Thunderbird</nl>
   <pl>Polish localisation of Thunderbird</pl>
   <pt_BR>Polish localisation of Thunderbird</pt_BR>
   <pt>Polish localisation of Thunderbird</pt>
   <ro>Polish localisation of Thunderbird</ro>
   <ru>Polish localisation of Thunderbird</ru>
   <sk>Polish localisation of Thunderbird</sk>
   <sv>Polsk lokalisering av Thunderbird</sv>
   <tr>Polish localisation of Thunderbird</tr>
   <uk>Polish localisation of Thunderbird</uk>
   <zh_TW>Polish localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-pl
lightning-l10n-pl
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-pl
lightning-l10n-pl
</uninstall_package_names>
</app>
