<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Portugese(PT) Firefox
</name>

<description>
   <am>Portugese(PT) localisation of Firefox</am>
   <ca>Localització de Firefox en Portuguès (PT)</ca>
   <cs>Portugese(PT) localisation of Firefox</cs>
   <de>Portugiesische (PT) Lokalisierung von Firefox</de>
   <el>Portugese(PT) localisation of Firefox</el>
   <en>Portugese(PT) localisation of Firefox</en>
   <es>Portugese(PT) localisation of Firefox</es>
   <fi>Portugese(PT) localisation of Firefox</fi>
   <fr>Portugese(PT) localisation of Firefox</fr>
   <hi>Portugese(PT) localisation of Firefox</hi>
   <hr>Portugese(PT) localisation of Firefox</hr>
   <hu>Portugese(PT) localisation of Firefox</hu>
   <it>Portugese(PT) localisation of Firefox</it>
   <ja>Portugese(PT) localisation of Firefox</ja>
   <kk>Portugese(PT) localisation of Firefox</kk>
   <lt>Portugese(PT) localisation of Firefox</lt>
   <nl>Portugese(PT) localisation of Firefox</nl>
   <pl>Portugese(PT) localisation of Firefox</pl>
   <pt_BR>Portugese(PT) localisation of Firefox</pt_BR>
   <pt>Portugese(PT) localisation of Firefox</pt>
   <ro>Portugese(PT) localisation of Firefox</ro>
   <ru>Portugese(PT) localisation of Firefox</ru>
   <sk>Portugese(PT) localisation of Firefox</sk>
   <sv>Portugisisk(PT) lokalisering för Firefox</sv>
   <tr>Portugese(PT) localisation of Firefox</tr>
   <uk>Portugese(PT) localisation of Firefox</uk>
   <zh_TW>Portugese(PT) localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-pt-pt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-pt-pt
</uninstall_package_names>
</app>
