<?xml version="1.0"?>
<app>


<category>
Screenshot Utilities
</category>

<name>
Shutter
</name>

<description>
   <am>a feature rich screenshot app</am>
   <ca>a feature rich screenshot app</ca>
   <cs>a feature rich screenshot app</cs>
   <de>Eine funktionsreiche Screenshot-Anwendung</de>
   <el>a feature rich screenshot app</el>
   <en>a feature rich screenshot app</en>
   <es>a feature rich screenshot app</es>
   <fi>a feature rich screenshot app</fi>
   <fr>a feature rich screenshot app</fr>
   <hi>a feature rich screenshot app</hi>
   <hr>a feature rich screenshot app</hr>
   <hu>a feature rich screenshot app</hu>
   <it>a feature rich screenshot app</it>
   <ja>a feature rich screenshot app</ja>
   <kk>a feature rich screenshot app</kk>
   <lt>a feature rich screenshot app</lt>
   <nl>a feature rich screenshot app</nl>
   <pl>a feature rich screenshot app</pl>
   <pt_BR>a feature rich screenshot app</pt_BR>
   <pt>a feature rich screenshot app</pt>
   <ro>a feature rich screenshot app</ro>
   <ru>a feature rich screenshot app</ru>
   <sk>a feature rich screenshot app</sk>
   <sv>en skärmdumpsapp med många möjligheter</sv>
   <tr>a feature rich screenshot app</tr>
   <uk>a feature rich screenshot app</uk>
   <zh_TW>a feature rich screenshot app</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://shutter-project.org/wp-content/uploads/key_feature_030.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
shutter
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
shutter
</uninstall_package_names>

</app>
