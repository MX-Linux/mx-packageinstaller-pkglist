<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>
Scratch
</name>

<description>
   <am>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</am>
   <ca>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ca>
   <cs>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</cs>
   <de>Scratch Graphical Programming Umgebung von M.I.T. https://scratch.mit.edu/</de>
   <el>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</el>
   <en>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</en>
   <es>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</es>
   <fi>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</fi>
   <fr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</fr>
   <hi>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</hi>
   <hr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</hr>
   <hu>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</hu>
   <it>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</it>
   <ja>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ja>
   <kk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</kk>
   <lt>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</lt>
   <nl>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</nl>
   <pl>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</pl>
   <pt_BR>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</pt_BR>
   <pt>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</pt>
   <ro>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ro>
   <ru>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ru>
   <sk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</sk>
   <sv>Scratch Grafisk Programmeringsmiljö från M.I.T. https://scratch.mit.edu/</sv>
   <tr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</tr>
   <uk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</uk>
   <zh_TW>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
scratch
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
scratch
</uninstall_package_names>
</app>
