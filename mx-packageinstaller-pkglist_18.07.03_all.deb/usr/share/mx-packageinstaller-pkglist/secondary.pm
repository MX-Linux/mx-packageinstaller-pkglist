<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>
Secondary
</name>

<description>
   <am>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</am>
   <ca>Secundària: inclou calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li i stellarium</ca>
   <cs>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</cs>
   <de>Oberschule: Beinhaltet: Kaliber, Celestia, Dia, Laby, Lightspeed, Lybniz, Schmelzen, Ri-li und Stellarium.</de>
   <el>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</el>
   <en>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</en>
   <es>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</es>
   <fi>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</fi>
   <fr>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</fr>
   <hi>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</hi>
   <hr>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</hr>
   <hu>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</hu>
   <it>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</it>
   <ja>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</ja>
   <kk>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</kk>
   <lt>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</lt>
   <nl>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</nl>
   <pl>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</pl>
   <pt_BR>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</pt_BR>
   <pt>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</pt>
   <ro>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</ro>
   <ru>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</ru>
   <sk>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</sk>
   <sv>Secondary. Inkluderar: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li och stellarium</sv>
   <tr>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</tr>
   <uk>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</uk>
   <zh_TW>Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
calibre
dia-gnome
laby
lightspeed
lybniz
melting
melting-gui
ri-li
stellarium
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
calibre
dia-gnome
laby
lightspeed
lybniz
melting
melting-gui
ri-li
stellarium
</uninstall_package_names>
</app>
