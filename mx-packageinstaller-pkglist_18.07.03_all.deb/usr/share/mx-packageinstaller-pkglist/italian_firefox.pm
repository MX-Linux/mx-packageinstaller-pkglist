<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Italian_Firefox
</name>

<description>
   <am>Italian localisation of Firefox</am>
   <ca>Localització de Firefox en Italià</ca>
   <cs>Italian localisation of Firefox</cs>
   <de>Italienische Lokalisierung von Firefox</de>
   <el>Italian localisation of Firefox</el>
   <en>Italian localisation of Firefox</en>
   <es>Italian localisation of Firefox</es>
   <fi>Italian localisation of Firefox</fi>
   <fr>Italian localisation of Firefox</fr>
   <hi>Italian localisation of Firefox</hi>
   <hr>Italian localisation of Firefox</hr>
   <hu>Italian localisation of Firefox</hu>
   <it>Localizzazione italiana di Firefox</it>
   <ja>Italian localisation of Firefox</ja>
   <kk>Italian localisation of Firefox</kk>
   <lt>Italian localisation of Firefox</lt>
   <nl>Italian localisation of Firefox</nl>
   <pl>Italian localisation of Firefox</pl>
   <pt_BR>Italian localisation of Firefox</pt_BR>
   <pt>Italian localisation of Firefox</pt>
   <ro>Italian localisation of Firefox</ro>
   <ru>Italian localisation of Firefox</ru>
   <sk>Italian localisation of Firefox</sk>
   <sv>Italiensk lokalisering av Firefox </sv>
   <tr>Italian localisation of Firefox</tr>
   <uk>Italian localisation of Firefox</uk>
   <zh_TW>Italian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-it
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-it
</uninstall_package_names>
</app>
