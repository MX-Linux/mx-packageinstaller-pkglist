<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Czech_Thunderbird
</name>

<description>
   <am>Czech localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Txec</ca>
   <cs>Czech localisation of Thunderbird</cs>
   <de>Tschechische Lokalisierung von Thunderbird</de>
   <el>Czech localisation of Thunderbird</el>
   <en>Czech localisation of Thunderbird</en>
   <es>Czech localisation of Thunderbird</es>
   <fi>Czech localisation of Thunderbird</fi>
   <fr>Localisation tchèque pour Thunderbird</fr>
   <hi>Czech localisation of Thunderbird</hi>
   <hr>Czech localisation of Thunderbird</hr>
   <hu>Czech localisation of Thunderbird</hu>
   <it>Localizzazione in Ceco di Thunderbird</it>
   <ja>Czech localisation of Thunderbird</ja>
   <kk>Czech localisation of Thunderbird</kk>
   <lt>Czech localisation of Thunderbird</lt>
   <nl>Czech localisation of Thunderbird</nl>
   <pl>Czech localisation of Thunderbird</pl>
   <pt_BR>Czech localisation of Thunderbird</pt_BR>
   <pt>Czech localisation of Thunderbird</pt>
   <ro>Czech localisation of Thunderbird</ro>
   <ru>Czech localisation of Thunderbird</ru>
   <sk>Czech localisation of Thunderbird</sk>
   <sv>Tjeckisk lokalisering av Thunderbird</sv>
   <tr>Czech localisation of Thunderbird</tr>
   <uk>Czech localisation of Thunderbird</uk>
   <zh_TW>Czech localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-cs
lightning-l10n-cs
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-cs
lightning-l10n-cs
</uninstall_package_names>
</app>
