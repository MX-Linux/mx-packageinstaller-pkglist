<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>
DVDStyler
</name>

<description>
   <am>DVD authoring application for the creation of professional-looking DVDs</am>
   <ca>DVD authoring application for the creation of professional-looking DVDs</ca>
   <cs>DVD authoring application for the creation of professional-looking DVDs</cs>
   <de>DVD-Authoring-Anwendung zur Erstellung professionell aussehender DVDs</de>
   <el>DVD authoring application for the creation of professional-looking DVDs</el>
   <en>DVD authoring application for the creation of professional-looking DVDs</en>
   <es>DVD authoring application for the creation of professional-looking DVDs</es>
   <fi>DVD authoring application for the creation of professional-looking DVDs</fi>
   <fr>DVD authoring application for the creation of professional-looking DVDs</fr>
   <hi>DVD authoring application for the creation of professional-looking DVDs</hi>
   <hr>DVD authoring application for the creation of professional-looking DVDs</hr>
   <hu>DVD authoring application for the creation of professional-looking DVDs</hu>
   <it>DVD authoring application for the creation of professional-looking DVDs</it>
   <ja>DVD authoring application for the creation of professional-looking DVDs</ja>
   <kk>DVD authoring application for the creation of professional-looking DVDs</kk>
   <lt>DVD authoring application for the creation of professional-looking DVDs</lt>
   <nl>DVD authoring application for the creation of professional-looking DVDs</nl>
   <pl>DVD authoring application for the creation of professional-looking DVDs</pl>
   <pt_BR>DVD authoring application for the creation of professional-looking DVDs</pt_BR>
   <pt>DVD authoring application for the creation of professional-looking DVDs</pt>
   <ro>DVD authoring application for the creation of professional-looking DVDs</ro>
   <ru>DVD authoring application for the creation of professional-looking DVDs</ru>
   <sk>DVD authoring application for the creation of professional-looking DVDs</sk>
   <sv>DVD-skapande applikation för att göra proffsiga DVD</sv>
   <tr>DVD authoring application for the creation of professional-looking DVDs</tr>
   <uk>DVD authoring application for the creation of professional-looking DVDs</uk>
   <zh_TW>DVD authoring application for the creation of professional-looking DVDs</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/008/331/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
dvdstyler
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
dvdstyler
</uninstall_package_names>
</app>
