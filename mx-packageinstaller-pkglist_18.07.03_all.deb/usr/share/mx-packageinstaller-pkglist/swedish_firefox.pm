<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Swedish_Firefox
</name>

<description>
   <am>Swedish localisation of Firefox</am>
   <ca>Localització de Firefox en Suec</ca>
   <cs>Swedish localisation of Firefox</cs>
   <de>Schwedische Lokalisierung von Firefox</de>
   <el>Swedish localisation of Firefox</el>
   <en>Swedish localisation of Firefox</en>
   <es>Swedish localisation of Firefox</es>
   <fi>Swedish localisation of Firefox</fi>
   <fr>Swedish localisation of Firefox</fr>
   <hi>Swedish localisation of Firefox</hi>
   <hr>Swedish localisation of Firefox</hr>
   <hu>Swedish localisation of Firefox</hu>
   <it>Swedish localisation of Firefox</it>
   <ja>Swedish localisation of Firefox</ja>
   <kk>Swedish localisation of Firefox</kk>
   <lt>Swedish localisation of Firefox</lt>
   <nl>Swedish localisation of Firefox</nl>
   <pl>Swedish localisation of Firefox</pl>
   <pt_BR>Swedish localisation of Firefox</pt_BR>
   <pt>Swedish localisation of Firefox</pt>
   <ro>Swedish localisation of Firefox</ro>
   <ru>Swedish localisation of Firefox</ru>
   <sk>Swedish localisation of Firefox</sk>
   <sv>Svensk lokalisering av Firefox</sv>
   <tr>Swedish localisation of Firefox</tr>
   <uk>Swedish localisation of Firefox</uk>
   <zh_TW>Swedish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sv-se
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sv-se
</uninstall_package_names>
</app>
