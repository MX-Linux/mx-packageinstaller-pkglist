<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Gnumeric
</name>

<description>
   <am>lightweight spreadsheet</am>
   <ca>Full de càlcul lleuger</ca>
   <cs>lightweight spreadsheet</cs>
   <de>Leichtgewichtige Tabellenkalkulation</de>
   <el>lightweight spreadsheet</el>
   <en>lightweight spreadsheet</en>
   <es>lightweight spreadsheet</es>
   <fi>lightweight spreadsheet</fi>
   <fr>lightweight spreadsheet</fr>
   <hi>lightweight spreadsheet</hi>
   <hr>lightweight spreadsheet</hr>
   <hu>lightweight spreadsheet</hu>
   <it>lightweight spreadsheet</it>
   <ja>lightweight spreadsheet</ja>
   <kk>lightweight spreadsheet</kk>
   <lt>lightweight spreadsheet</lt>
   <nl>lightweight spreadsheet</nl>
   <pl>lightweight spreadsheet</pl>
   <pt_BR>lightweight spreadsheet</pt_BR>
   <pt>lightweight spreadsheet</pt>
   <ro>lightweight spreadsheet</ro>
   <ru>lightweight spreadsheet</ru>
   <sk>lightweight spreadsheet</sk>
   <sv>lättvikts spreadsheet</sv>
   <tr>lightweight spreadsheet</tr>
   <uk>lightweight spreadsheet</uk>
   <zh_TW>lightweight spreadsheet</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/200/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gnumeric
gnumeric-common
gnumeric-doc
gnumeric-plugins-extra
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gnumeric
gnumeric-common
gnumeric-doc
gnumeric-plugins-extra
</uninstall_package_names>
</app>
