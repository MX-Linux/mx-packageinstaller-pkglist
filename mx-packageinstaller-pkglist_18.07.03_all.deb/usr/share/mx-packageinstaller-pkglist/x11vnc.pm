<?xml version="1.0"?>
<app>

<category>
Remote Access
</category>

<name>
x11vnc
</name>

<description>
   <am>VNC server for X window environments</am>
   <ca>Servidor VNC per entorns X-window</ca>
   <cs>VNC server for X window environments</cs>
   <de>VNC-Server für X Window-Umgebungen</de>
   <el>VNC server for X window environments</el>
   <en>VNC server for X window environments</en>
   <es>VNC server for X window environments</es>
   <fi>VNC server for X window environments</fi>
   <fr>VNC server for X window environments</fr>
   <hi>VNC server for X window environments</hi>
   <hr>VNC server for X window environments</hr>
   <hu>VNC server for X window environments</hu>
   <it>VNC server for X window environments</it>
   <ja>VNC server for X window environments</ja>
   <kk>VNC server for X window environments</kk>
   <lt>VNC server for X window environments</lt>
   <nl>VNC server for X window environments</nl>
   <pl>VNC server for X window environments</pl>
   <pt_BR>VNC server for X window environments</pt_BR>
   <pt>VNC server for X window environments</pt>
   <ro>VNC server for X window environments</ro>
   <ru>VNC server for X window environments</ru>
   <sk>VNC server for X window environments</sk>
   <sv>VNC server för X window miljöer</sv>
   <tr>VNC server for X window environments</tr>
   <uk>VNC server for X window environments</uk>
   <zh_TW>VNC server for X window environments</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
x11vnc
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
x11vnc
</uninstall_package_names>
</app>
