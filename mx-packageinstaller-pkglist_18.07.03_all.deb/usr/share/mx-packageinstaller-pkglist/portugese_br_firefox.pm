<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Portugese(BR)_Firefox
</name>

<description>
   <am>Portuguese(BR) localisation of Firefox</am>
   <ca>Localització de Firefox en Portuguès</ca>
   <cs>Portuguese(BR) localisation of Firefox</cs>
   <de>Portugiesische (BR) Lokalisierung von Firefox</de>
   <el>Portuguese(BR) localisation of Firefox</el>
   <en>Portuguese(BR) localisation of Firefox</en>
   <es>Portuguese(BR) localisation of Firefox</es>
   <fi>Portuguese(BR) localisation of Firefox</fi>
   <fr>Portuguese(BR) localisation of Firefox</fr>
   <hi>Portuguese(BR) localisation of Firefox</hi>
   <hr>Portuguese(BR) localisation of Firefox</hr>
   <hu>Portuguese(BR) localisation of Firefox</hu>
   <it>Portuguese(BR) localisation of Firefox</it>
   <ja>Portuguese(BR) localisation of Firefox</ja>
   <kk>Portuguese(BR) localisation of Firefox</kk>
   <lt>Portuguese(BR) localisation of Firefox</lt>
   <nl>Portuguese(BR) localisation of Firefox</nl>
   <pl>Portuguese(BR) localisation of Firefox</pl>
   <pt_BR>Portuguese(BR) localisation of Firefox</pt_BR>
   <pt>Portuguese(BR) localisation of Firefox</pt>
   <ro>Portuguese(BR) localisation of Firefox</ro>
   <ru>Portuguese(BR) localisation of Firefox</ru>
   <sk>Portuguese(BR) localisation of Firefox</sk>
   <sv>Portugisisk (BR) lokalisering av Firefox </sv>
   <tr>Portuguese(BR) localisation of Firefox</tr>
   <uk>Portuguese(BR) localisation of Firefox</uk>
   <zh_TW>Portuguese(BR) localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-pt-br
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-pt-br
</uninstall_package_names>
</app>
