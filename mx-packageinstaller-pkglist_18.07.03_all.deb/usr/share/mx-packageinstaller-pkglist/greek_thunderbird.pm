<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Greek_Thunderbird
</name>

<description>
   <am>Greek localisation of Thunderbird</am>
   <ca>Greek localisation of Thunderbird</ca>
   <cs>Greek localisation of Thunderbird</cs>
   <de>Griechische Lokalisierung von Thunderbird</de>
   <el>Greek localisation of Thunderbird</el>
   <en>Greek localisation of Thunderbird</en>
   <es>Greek localisation of Thunderbird</es>
   <fi>Greek localisation of Thunderbird</fi>
   <fr>Greek localisation of Thunderbird</fr>
   <hi>Greek localisation of Thunderbird</hi>
   <hr>Greek localisation of Thunderbird</hr>
   <hu>Greek localisation of Thunderbird</hu>
   <it>Greek localisation of Thunderbird</it>
   <ja>Greek localisation of Thunderbird</ja>
   <kk>Greek localisation of Thunderbird</kk>
   <lt>Greek localisation of Thunderbird</lt>
   <nl>Greek localisation of Thunderbird</nl>
   <pl>Greek localisation of Thunderbird</pl>
   <pt_BR>Greek localisation of Thunderbird</pt_BR>
   <pt>Greek localisation of Thunderbird</pt>
   <ro>Greek localisation of Thunderbird</ro>
   <ru>Greek localisation of Thunderbird</ru>
   <sk>Greek localisation of Thunderbird</sk>
   <sv>Grekisk lokalisering för Thunderbird</sv>
   <tr>Greek localisation of Thunderbird</tr>
   <uk>Greek localisation of Thunderbird</uk>
   <zh_TW>Greek localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-el
lightning-l10n-el
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-el
lightning-l10n-el
</uninstall_package_names>
</app>
