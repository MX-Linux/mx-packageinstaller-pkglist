<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>
antiX 4.9 64 bit
</name>

<description>
   <am>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</am>
   <ca>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</ca>
   <cs>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</cs>
   <de>antiX 4.9.91 Kernel Meltdown und Spectre gepatcht, 64 Bit</de>
   <el>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</el>
   <en>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</en>
   <es>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</es>
   <fi>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</fi>
   <fr>Noyau antiX 4.9.91 corrections Meltdown et Spectre, 64 bit</fr>
   <hi>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</hi>
   <hr>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</hr>
   <hu>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</hu>
   <it>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</it>
   <ja>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</ja>
   <kk>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</kk>
   <lt>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</lt>
   <nl>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</nl>
   <pl>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</pl>
   <pt_BR>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</pt_BR>
   <pt>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</pt>
   <ro>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</ro>
   <ru>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</ru>
   <sk>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</sk>
   <sv>antiX 4.9.91 kärna Meltdown och Spectre patched, 64 bit</sv>
   <tr>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</tr>
   <uk>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</uk>
   <zh_TW>antiX 4.9.91 kernel Meltdown and Spectre patched, 64 bit</zh_TW>
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.91-antix.1-amd64-smp
linux-headers-4.9.91-antix.1-amd64-smp
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.91-antix.1-amd64-smp
linux-headers-4.9.91-antix.1-amd64-smp
</uninstall_package_names>
</app>
