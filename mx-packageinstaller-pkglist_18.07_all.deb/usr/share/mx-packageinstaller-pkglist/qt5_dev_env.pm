<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>
QT5 Dev Enviroment
</name>

<description>
   <am>QT5 Development Environment</am>
   <ca>Entorn de desenvolupament per QT5</ca>
   <cs>QT5 Development Environment</cs>
   <de>Qt5 Entwicklungsumgebung</de>
   <el>QT5 Development Environment</el>
   <en>QT5 Development Environment</en>
   <es>QT5 Development Environment</es>
   <fi>QT5 Development Environment</fi>
   <fr>QT5 Development Environment</fr>
   <hi>QT5 Development Environment</hi>
   <hr>QT5 Development Environment</hr>
   <hu>QT5 Development Environment</hu>
   <it>QT5 Development Environment</it>
   <ja>QT5 Development Environment</ja>
   <kk>QT5 Development Environment</kk>
   <lt>QT5 Development Environment</lt>
   <nl>QT5 Development Environment</nl>
   <pl>QT5 Development Environment</pl>
   <pt_BR>QT5 Development Environment</pt_BR>
   <pt>QT5 Development Environment</pt>
   <ro>QT5 Development Environment</ro>
   <ru>QT5 Development Environment</ru>
   <sk>QT5 Development Environment</sk>
   <sv>QT5 Utvecklingsmiljö</sv>
   <tr>QT5 Development Environment</tr>
   <uk>QT5 Development Environment</uk>
   <zh_TW>QT5 Development Environment</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/134/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qtcreator
qt5-default
qttools5-dev-tools
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qtcreator
qt5-default
qttools5-dev-tools
</uninstall_package_names>
</app>
