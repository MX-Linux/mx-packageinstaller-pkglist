<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Italian_Libreoffice
</name>

<description>
   <am>Italian LibreOffice Language Meta-Package</am>
   <ca>Italian LibreOffice Language Meta-Package</ca>
   <cs>Italian LibreOffice Language Meta-Package</cs>
   <de>Italienisches LibreOffice Meta-Paket</de>
   <el>Italian LibreOffice Language Meta-Package</el>
   <en>Italian LibreOffice Language Meta-Package</en>
   <es>Italian LibreOffice Language Meta-Package</es>
   <fi>Italian LibreOffice Language Meta-Package</fi>
   <fr>Italian LibreOffice Language Meta-Package</fr>
   <hi>Italian LibreOffice Language Meta-Package</hi>
   <hr>Italian LibreOffice Language Meta-Package</hr>
   <hu>Italian LibreOffice Language Meta-Package</hu>
   <it>Meta-pacchetto della lingua italiana per LibreOffice</it>
   <ja>Italian LibreOffice Language Meta-Package</ja>
   <kk>Italian LibreOffice Language Meta-Package</kk>
   <lt>Italian LibreOffice Language Meta-Package</lt>
   <nl>Italian LibreOffice Language Meta-Package</nl>
   <pl>Italian LibreOffice Language Meta-Package</pl>
   <pt_BR>Italian LibreOffice Language Meta-Package</pt_BR>
   <pt>Italian LibreOffice Language Meta-Package</pt>
   <ro>Italian LibreOffice Language Meta-Package</ro>
   <ru>Italian LibreOffice Language Meta-Package</ru>
   <sk>Italian LibreOffice Language Meta-Package</sk>
   <sv>Italienskt LibreOffice Språk-Meta-Paket</sv>
   <tr>Italian LibreOffice Language Meta-Package</tr>
   <uk>Italian LibreOffice Language Meta-Package</uk>
   <zh_TW>Italian LibreOffice Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw
libreoffice-impress
libreoffice-math
libreoffice-writer
libreoffice-l10n-it
libreoffice-help-it
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw
libreoffice-impress
libreoffice-math
libreoffice-writer
libreoffice-l10n-it
libreoffice-help-it
</uninstall_package_names>
</app>
