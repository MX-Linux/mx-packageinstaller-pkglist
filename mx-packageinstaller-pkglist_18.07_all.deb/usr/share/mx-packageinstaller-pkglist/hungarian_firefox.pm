<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Hungarian_Firefox
</name>

<description>
   <am>Hungarian localisation of Firefox</am>
   <ca>Localització de Firefox en Hongarès</ca>
   <cs>Hungarian localisation of Firefox</cs>
   <de>Ungarische Lokalisierung von Firefox</de>
   <el>Hungarian localisation of Firefox</el>
   <en>Hungarian localisation of Firefox</en>
   <es>Hungarian localisation of Firefox</es>
   <fi>Hungarian localisation of Firefox</fi>
   <fr>Hungarian localisation of Firefox</fr>
   <hi>Hungarian localisation of Firefox</hi>
   <hr>Hungarian localisation of Firefox</hr>
   <hu>Hungarian localisation of Firefox</hu>
   <it>Hungarian localisation of Firefox</it>
   <ja>Hungarian localisation of Firefox</ja>
   <kk>Hungarian localisation of Firefox</kk>
   <lt>Hungarian localisation of Firefox</lt>
   <nl>Hungarian localisation of Firefox</nl>
   <pl>Hungarian localisation of Firefox</pl>
   <pt_BR>Hungarian localisation of Firefox</pt_BR>
   <pt>Hungarian localisation of Firefox</pt>
   <ro>Hungarian localisation of Firefox</ro>
   <ru>Hungarian localisation of Firefox</ru>
   <sk>Hungarian localisation of Firefox</sk>
   <sv>Ungersk lokalisering av Firefox</sv>
   <tr>Hungarian localisation of Firefox</tr>
   <uk>Hungarian localisation of Firefox</uk>
   <zh_TW>Hungarian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-hu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-hu
</uninstall_package_names>
</app>
