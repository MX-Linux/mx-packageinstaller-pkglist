<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>
Pithos
</name>

<description>
   <am>a native Pandora Radio client</am>
   <ca>a native Pandora Radio client</ca>
   <cs>a native Pandora Radio client</cs>
   <de>Ein einheimischer Pandora-Radio-Client</de>
   <el>a native Pandora Radio client</el>
   <en>a native Pandora Radio client</en>
   <es>a native Pandora Radio client</es>
   <fi>a native Pandora Radio client</fi>
   <fr>a native Pandora Radio client</fr>
   <hi>a native Pandora Radio client</hi>
   <hr>a native Pandora Radio client</hr>
   <hu>a native Pandora Radio client</hu>
   <it>a native Pandora Radio client</it>
   <ja>a native Pandora Radio client</ja>
   <kk>a native Pandora Radio client</kk>
   <lt>a native Pandora Radio client</lt>
   <nl>a native Pandora Radio client</nl>
   <pl>a native Pandora Radio client</pl>
   <pt_BR>a native Pandora Radio client</pt_BR>
   <pt>a native Pandora Radio client</pt>
   <ro>a native Pandora Radio client</ro>
   <ru>a native Pandora Radio client</ru>
   <sk>a native Pandora Radio client</sk>
   <sv>en naturlig Pandora Radio klient</sv>
   <tr>a native Pandora Radio client</tr>
   <uk>a native Pandora Radio client</uk>
   <zh_TW>a native Pandora Radio client</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/199/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pithos
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pithos
</uninstall_package_names>
</app>
