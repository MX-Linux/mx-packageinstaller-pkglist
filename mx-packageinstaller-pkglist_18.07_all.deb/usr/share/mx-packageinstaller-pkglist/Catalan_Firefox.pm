<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Catalan_Firefox
</name>

<description>
   <am>Catalan localisation of Firefox</am>
   <ca>Localització de Firefox en Català</ca>
   <cs>Catalan localisation of Firefox</cs>
   <de>Katalanische Lokalisierung von Firefox</de>
   <el>Catalan localisation of Firefox</el>
   <en>Catalan localisation of Firefox</en>
   <es>Catalan localisation of Firefox</es>
   <fi>Catalan localisation of Firefox</fi>
   <fr>Localisation catalane pour Firefox</fr>
   <hi>Catalan localisation of Firefox</hi>
   <hr>Catalan localisation of Firefox</hr>
   <hu>Catalan localisation of Firefox</hu>
   <it>Localizzazione catalana di Firefox</it>
   <ja>Catalan localisation of Firefox</ja>
   <kk>Catalan localisation of Firefox</kk>
   <lt>Catalan localisation of Firefox</lt>
   <nl>Catalan localisation of Firefox</nl>
   <pl>Catalan localisation of Firefox</pl>
   <pt_BR>Catalan localisation of Firefox</pt_BR>
   <pt>Catalan localisation of Firefox</pt>
   <ro>Catalan localisation of Firefox</ro>
   <ru>Catalan localisation of Firefox</ru>
   <sk>Catalan localisation of Firefox</sk>
   <sv>Katalansk lokalisering av Firefox</sv>
   <tr>Catalan localisation of Firefox</tr>
   <uk>Catalan localisation of Firefox</uk>
   <zh_TW>Catalan localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-ca
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-ca
</uninstall_package_names>
</app>
