<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
Mirage
</name>

<description>
   <am>fast and simple image viewer</am>
   <ca>fast and simple image viewer</ca>
   <cs>fast and simple image viewer</cs>
   <de>Schneller und einfacher Bildbetrachter</de>
   <el>fast and simple image viewer</el>
   <en>fast and simple image viewer</en>
   <es>fast and simple image viewer</es>
   <fi>fast and simple image viewer</fi>
   <fr>Visionneuse d'images facile et rapide</fr>
   <hi>fast and simple image viewer</hi>
   <hr>fast and simple image viewer</hr>
   <hu>fast and simple image viewer</hu>
   <it>fast and simple image viewer</it>
   <ja>fast and simple image viewer</ja>
   <kk>fast and simple image viewer</kk>
   <lt>fast and simple image viewer</lt>
   <nl>fast and simple image viewer</nl>
   <pl>fast and simple image viewer</pl>
   <pt_BR>fast and simple image viewer</pt_BR>
   <pt>fast and simple image viewer</pt>
   <ro>fast and simple image viewer</ro>
   <ru>fast and simple image viewer</ru>
   <sk>fast and simple image viewer</sk>
   <sv>snabb och enkel bildvisare</sv>
   <tr>fast and simple image viewer</tr>
   <uk>fast and simple image viewer</uk>
   <zh_TW>fast and simple image viewer</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://screenshots.debian.net/screenshots/000/005/675/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mirage
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mirage
</uninstall_package_names>
</app>
