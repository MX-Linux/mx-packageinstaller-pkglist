<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Danish_Firefox
</name>

<description>
   <am>Danish localisation of Firefox</am>
   <ca>Localització de Firefox en Danès</ca>
   <cs>Danish localisation of Firefox</cs>
   <de>Dänische Lokalisierung von Firefox</de>
   <el>Danish localisation of Firefox</el>
   <en>Danish localisation of Firefox</en>
   <es>Danish localisation of Firefox</es>
   <fi>Danish localisation of Firefox</fi>
   <fr>Localisation danoise pour Firefox</fr>
   <hi>Danish localisation of Firefox</hi>
   <hr>Danish localisation of Firefox</hr>
   <hu>Danish localisation of Firefox</hu>
   <it>Localizzazione danese di Firefox</it>
   <ja>Danish localisation of Firefox</ja>
   <kk>Danish localisation of Firefox</kk>
   <lt>Danish localisation of Firefox</lt>
   <nl>Danish localisation of Firefox</nl>
   <pl>Danish localisation of Firefox</pl>
   <pt_BR>Danish localisation of Firefox</pt_BR>
   <pt>Danish localisation of Firefox</pt>
   <ro>Danish localisation of Firefox</ro>
   <ru>Danish localisation of Firefox</ru>
   <sk>Danish localisation of Firefox</sk>
   <sv>Dansk lokalisering av Firefox</sv>
   <tr>Danish localisation of Firefox</tr>
   <uk>Danish localisation of Firefox</uk>
   <zh_TW>Danish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-da
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-da
</uninstall_package_names>
</app>
