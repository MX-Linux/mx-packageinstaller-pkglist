<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
GB_English_Thunderbird
</name>

<description>
   <am>GB English localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en anglès (UK)</ca>
   <cs>GB English localisation of Thunderbird</cs>
   <de>Englische (GB) Lokalisierung von Thunderbird</de>
   <el>GB English localisation of Thunderbird</el>
   <en>GB English localisation of Thunderbird</en>
   <es>GB English localisation of Thunderbird</es>
   <fi>GB English localisation of Thunderbird</fi>
   <fr>GB English localisation of Thunderbird</fr>
   <hi>GB English localisation of Thunderbird</hi>
   <hr>GB English localisation of Thunderbird</hr>
   <hu>GB English localisation of Thunderbird</hu>
   <it>GB English localisation of Thunderbird</it>
   <ja>GB English localisation of Thunderbird</ja>
   <kk>GB English localisation of Thunderbird</kk>
   <lt>GB English localisation of Thunderbird</lt>
   <nl>GB English localisation of Thunderbird</nl>
   <pl>GB English localisation of Thunderbird</pl>
   <pt_BR>GB English localisation of Thunderbird</pt_BR>
   <pt>GB English localisation of Thunderbird</pt>
   <ro>GB English localisation of Thunderbird</ro>
   <ru>GB English localisation of Thunderbird</ru>
   <sk>GB English localisation of Thunderbird</sk>
   <sv>GB Engelsk lokalisering av Thunderbird</sv>
   <tr>GB English localisation of Thunderbird</tr>
   <uk>GB English localisation of Thunderbird</uk>
   <zh_TW>GB English localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-en-gb
lightning-l10n-en-gb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-en-gb
lightning-l10n-en-gb
</uninstall_package_names>
</app>
