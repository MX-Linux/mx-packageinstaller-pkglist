<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>
Firefox
</name>

<description>
   <am>Latest Firefox</am>
   <ca>Darrer Firefox</ca>
   <cs>Latest Firefox</cs>
   <de>Neuester Firefox</de>
   <el>Latest Firefox</el>
   <en>Latest Firefox</en>
   <es>Latest Firefox</es>
   <fi>Latest Firefox</fi>
   <fr>La dernière version de Firefox</fr>
   <hi>Latest Firefox</hi>
   <hr>Latest Firefox</hr>
   <hu>Latest Firefox</hu>
   <it>Latest Firefox</it>
   <ja>Latest Firefox</ja>
   <kk>Latest Firefox</kk>
   <lt>Latest Firefox</lt>
   <nl>Latest Firefox</nl>
   <pl>Latest Firefox</pl>
   <pt_BR>Latest Firefox</pt_BR>
   <pt>Latest Firefox</pt>
   <ro>Latest Firefox</ro>
   <ru>Latest Firefox</ru>
   <sk>Latest Firefox</sk>
   <sv>Senaste Firefox</sv>
   <tr>Latest Firefox</tr>
   <uk>Latest Firefox</uk>
   <zh_TW>Latest Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/721/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox
</uninstall_package_names>
</app>
