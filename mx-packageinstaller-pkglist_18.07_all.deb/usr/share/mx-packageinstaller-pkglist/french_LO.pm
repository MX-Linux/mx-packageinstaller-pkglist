<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
French_Libreoffice
</name>

<description>
   <am>French Language Meta-Package for LibreOffice</am>
   <ca>Meta paquet per LibreOffice en llengua francesa</ca>
   <cs>French Language Meta-Package for LibreOffice</cs>
   <de>Französisches Meta-Paket für LibreOffice</de>
   <el>French Language Meta-Package for LibreOffice</el>
   <en>French Language Meta-Package for LibreOffice</en>
   <es>French Language Meta-Package for LibreOffice</es>
   <fi>French Language Meta-Package for LibreOffice</fi>
   <fr>French Language Meta-Package for LibreOffice</fr>
   <hi>French Language Meta-Package for LibreOffice</hi>
   <hr>French Language Meta-Package for LibreOffice</hr>
   <hu>French Language Meta-Package for LibreOffice</hu>
   <it>French Language Meta-Package for LibreOffice</it>
   <ja>French Language Meta-Package for LibreOffice</ja>
   <kk>French Language Meta-Package for LibreOffice</kk>
   <lt>French Language Meta-Package for LibreOffice</lt>
   <nl>French Language Meta-Package for LibreOffice</nl>
   <pl>French Language Meta-Package for LibreOffice</pl>
   <pt_BR>French Language Meta-Package for LibreOffice</pt_BR>
   <pt>French Language Meta-Package for LibreOffice</pt>
   <ro>French Language Meta-Package for LibreOffice</ro>
   <ru>French Language Meta-Package for LibreOffice</ru>
   <sk>French Language Meta-Package for LibreOffice</sk>
   <sv>Franskt Språk Meta-Paket för LibreOffice</sv>
   <tr>French Language Meta-Package for LibreOffice</tr>
   <uk>French Language Meta-Package for LibreOffice</uk>
   <zh_TW>French Language Meta-Package for LibreOffice</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw
libreoffice-impress
libreoffice-math
libreoffice-writer
libreoffice-l10n-fr
libreoffice-help-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw
libreoffice-impress
libreoffice-math
libreoffice-writer
libreoffice-l10n-fr
libreoffice-help-fr
</uninstall_package_names>
</app>
