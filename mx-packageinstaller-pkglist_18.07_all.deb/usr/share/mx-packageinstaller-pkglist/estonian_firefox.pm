<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Estonian_Firefox
</name>

<description>
   <am>Estonian localisation of Firefox</am>
   <ca>Localització de Firefox en Estonià</ca>
   <cs>Estonian localisation of Firefox</cs>
   <de>Estnische Lokalisierung von Firefox</de>
   <el>Estonian localisation of Firefox</el>
   <en>Estonian localisation of Firefox</en>
   <es>Estonian localisation of Firefox</es>
   <fi>Estonian localisation of Firefox</fi>
   <fr>Estonian localisation of Firefox</fr>
   <hi>Estonian localisation of Firefox</hi>
   <hr>Estonian localisation of Firefox</hr>
   <hu>Estonian localisation of Firefox</hu>
   <it>Estonian localisation of Firefox</it>
   <ja>Estonian localisation of Firefox</ja>
   <kk>Estonian localisation of Firefox</kk>
   <lt>Estonian localisation of Firefox</lt>
   <nl>Estonian localisation of Firefox</nl>
   <pl>Estonian localisation of Firefox</pl>
   <pt_BR>Estonian localisation of Firefox</pt_BR>
   <pt>Estonian localisation of Firefox</pt>
   <ro>Estonian localisation of Firefox</ro>
   <ru>Estonian localisation of Firefox</ru>
   <sk>Estonian localisation of Firefox</sk>
   <sv>Estnisk lokalisering av Firefox</sv>
   <tr>Estonian localisation of Firefox</tr>
   <uk>Estonian localisation of Firefox</uk>
   <zh_TW>Estonian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-et
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-et
</uninstall_package_names>
</app>
