<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Turkish_Firefox
</name>

<description>
   <am>Turkish localisation of Firefox</am>
   <ca>Localització de Firefox en Turc</ca>
   <cs>Turkish localisation of Firefox</cs>
   <de>Türkische Lokalisierung von Firefox</de>
   <el>Turkish localisation of Firefox</el>
   <en>Turkish localisation of Firefox</en>
   <es>Turkish localisation of Firefox</es>
   <fi>Turkish localisation of Firefox</fi>
   <fr>Turkish localisation of Firefox</fr>
   <hi>Turkish localisation of Firefox</hi>
   <hr>Turkish localisation of Firefox</hr>
   <hu>Turkish localisation of Firefox</hu>
   <it>Turkish localisation of Firefox</it>
   <ja>Turkish localisation of Firefox</ja>
   <kk>Turkish localisation of Firefox</kk>
   <lt>Turkish localisation of Firefox</lt>
   <nl>Turkish localisation of Firefox</nl>
   <pl>Turkish localisation of Firefox</pl>
   <pt_BR>Turkish localisation of Firefox</pt_BR>
   <pt>Turkish localisation of Firefox</pt>
   <ro>Turkish localisation of Firefox</ro>
   <ru>Turkish localisation of Firefox</ru>
   <sk>Turkish localisation of Firefox</sk>
   <sv>Turkisk lokalisering av Firefox</sv>
   <tr>Turkish localisation of Firefox</tr>
   <uk>Turkish localisation of Firefox</uk>
   <zh_TW>Turkish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-tr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-tr
</uninstall_package_names>
</app>
