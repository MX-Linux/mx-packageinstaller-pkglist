<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Japanese_Firefox
</name>

<description>
   <am>Japanese localisation of Firefox</am>
   <ca>Localització de Firefox en Japonès</ca>
   <cs>Japanese localisation of Firefox</cs>
   <de>Japanische Lokalisierung von Firefox</de>
   <el>Japanese localisation of Firefox</el>
   <en>Japanese localisation of Firefox</en>
   <es>Japanese localisation of Firefox</es>
   <fi>Japanese localisation of Firefox</fi>
   <fr>Japanese localisation of Firefox</fr>
   <hi>Japanese localisation of Firefox</hi>
   <hr>Japanese localisation of Firefox</hr>
   <hu>Japanese localisation of Firefox</hu>
   <it>Japanese localisation of Firefox</it>
   <ja>Japanese localisation of Firefox</ja>
   <kk>Japanese localisation of Firefox</kk>
   <lt>Japanese localisation of Firefox</lt>
   <nl>Japanese localisation of Firefox</nl>
   <pl>Japanese localisation of Firefox</pl>
   <pt_BR>Japanese localisation of Firefox</pt_BR>
   <pt>Japanese localisation of Firefox</pt>
   <ro>Japanese localisation of Firefox</ro>
   <ru>Japanese localisation of Firefox</ru>
   <sk>Japanese localisation of Firefox</sk>
   <sv>Japansk lokalisering av Firefox</sv>
   <tr>Japanese localisation of Firefox</tr>
   <uk>Japanese localisation of Firefox</uk>
   <zh_TW>Japanese localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-ja
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-ja
</uninstall_package_names>
</app>
