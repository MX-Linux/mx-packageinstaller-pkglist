<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Icelandic_Firefox
</name>

<description>
   <am>Icelandic localisation of Firefox</am>
   <ca>Localització de Firefox en Islandès</ca>
   <cs>Icelandic localisation of Firefox</cs>
   <de>Isländische Lokalisierung von Firefox</de>
   <el>Icelandic localisation of Firefox</el>
   <en>Icelandic localisation of Firefox</en>
   <es>Icelandic localisation of Firefox</es>
   <fi>Icelandic localisation of Firefox</fi>
   <fr>Icelandic localisation of Firefox</fr>
   <hi>Icelandic localisation of Firefox</hi>
   <hr>Icelandic localisation of Firefox</hr>
   <hu>Icelandic localisation of Firefox</hu>
   <it>Icelandic localisation of Firefox</it>
   <ja>Icelandic localisation of Firefox</ja>
   <kk>Icelandic localisation of Firefox</kk>
   <lt>Icelandic localisation of Firefox</lt>
   <nl>Icelandic localisation of Firefox</nl>
   <pl>Icelandic localisation of Firefox</pl>
   <pt_BR>Icelandic localisation of Firefox</pt_BR>
   <pt>Icelandic localisation of Firefox</pt>
   <ro>Icelandic localisation of Firefox</ro>
   <ru>Icelandic localisation of Firefox</ru>
   <sk>Icelandic localisation of Firefox</sk>
   <sv>Isländsk lokalisering av Firefox </sv>
   <tr>Icelandic localisation of Firefox</tr>
   <uk>Icelandic localisation of Firefox</uk>
   <zh_TW>Icelandic localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-is
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-is
</uninstall_package_names>
</app>
