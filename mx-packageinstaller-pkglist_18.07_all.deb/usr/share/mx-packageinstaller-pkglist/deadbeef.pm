<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>
DeaDBeeF
</name>

<description>
   <am>simple audio player</am>
   <ca>simple audio player</ca>
   <cs>simple audio player</cs>
   <de>Einfacher Audio-Player</de>
   <el>simple audio player</el>
   <en>simple audio player</en>
   <es>simple audio player</es>
   <fi>simple audio player</fi>
   <fr>lecteur audio basique</fr>
   <hi>simple audio player</hi>
   <hr>simple audio player</hr>
   <hu>simple audio player</hu>
   <it>Lettore di tracce audio semplice</it>
   <ja>simple audio player</ja>
   <kk>simple audio player</kk>
   <lt>simple audio player</lt>
   <nl>simple audio player</nl>
   <pl>simple audio player</pl>
   <pt_BR>simple audio player</pt_BR>
   <pt>simple audio player</pt>
   <ro>simple audio player</ro>
   <ru>simple audio player</ru>
   <sk>simple audio player</sk>
   <sv>enkel ljudspelare</sv>
   <tr>simple audio player</tr>
   <uk>simple audio player</uk>
   <zh_TW>simple audio player</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://deadbeef.sourceforge.net/screenshots/0.6/06.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
deadbeef
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
deadbeef
</uninstall_package_names>
</app>
