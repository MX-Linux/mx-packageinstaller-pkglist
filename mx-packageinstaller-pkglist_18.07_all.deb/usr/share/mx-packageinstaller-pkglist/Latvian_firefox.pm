<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Latvian_Firefox
</name>

<description>
   <am>Latvian localisation of Firefox</am>
   <ca>Localització de Firefox en Latvi</ca>
   <cs>Latvian localisation of Firefox</cs>
   <de>Lettische Lokalisierung von Firefox</de>
   <el>Latvian localisation of Firefox</el>
   <en>Latvian localisation of Firefox</en>
   <es>Latvian localisation of Firefox</es>
   <fi>Latvian localisation of Firefox</fi>
   <fr>Latvian localisation of Firefox</fr>
   <hi>Latvian localisation of Firefox</hi>
   <hr>Latvian localisation of Firefox</hr>
   <hu>Latvian localisation of Firefox</hu>
   <it>Latvian localisation of Firefox</it>
   <ja>Latvian localisation of Firefox</ja>
   <kk>Latvian localisation of Firefox</kk>
   <lt>Latvian localisation of Firefox</lt>
   <nl>Latvian localisation of Firefox</nl>
   <pl>Latvian localisation of Firefox</pl>
   <pt_BR>Latvian localisation of Firefox</pt_BR>
   <pt>Latvian localisation of Firefox</pt>
   <ro>Latvian localisation of Firefox</ro>
   <ru>Latvian localisation of Firefox</ru>
   <sk>Latvian localisation of Firefox</sk>
   <sv>Lettländsk lokalisering av Firefox</sv>
   <tr>Latvian localisation of Firefox</tr>
   <uk>Latvian localisation of Firefox</uk>
   <zh_TW>Latvian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-lv
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-lv
</uninstall_package_names>
</app>
