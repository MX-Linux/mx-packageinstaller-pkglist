<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Farsi_Firefox
</name>

<description>
   <am>Farsi localisation of Firefox</am>
   <ca>Localització de Firefox en Farsi</ca>
   <cs>Farsi localisation of Firefox</cs>
   <de>Farsi-Lokalisierung von Firefox</de>
   <el>Farsi localisation of Firefox</el>
   <en>Farsi localisation of Firefox</en>
   <es>Farsi localisation of Firefox</es>
   <fi>Farsi localisation of Firefox</fi>
   <fr>Farsi localisation of Firefox</fr>
   <hi>Farsi localisation of Firefox</hi>
   <hr>Farsi localisation of Firefox</hr>
   <hu>Farsi localisation of Firefox</hu>
   <it>Farsi localisation of Firefox</it>
   <ja>Farsi localisation of Firefox</ja>
   <kk>Farsi localisation of Firefox</kk>
   <lt>Farsi localisation of Firefox</lt>
   <nl>Farsi localisation of Firefox</nl>
   <pl>Farsi localisation of Firefox</pl>
   <pt_BR>Farsi localisation of Firefox</pt_BR>
   <pt>Farsi localisation of Firefox</pt>
   <ro>Farsi localisation of Firefox</ro>
   <ru>Farsi localisation of Firefox</ru>
   <sk>Farsi localisation of Firefox</sk>
   <sv>Farsi lokalisering av Firefox</sv>
   <tr>Farsi localisation of Firefox</tr>
   <uk>Farsi localisation of Firefox</uk>
   <zh_TW>Farsi localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-fa
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-fa
</uninstall_package_names>
</app>
