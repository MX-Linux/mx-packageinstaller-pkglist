<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
GIMP Full
</name>

<description>
   <am>advanced picture editor- installs GIMP, help and plugins</am>
   <ca>advanced picture editor- installs GIMP, help and plugins</ca>
   <cs>advanced picture editor- installs GIMP, help and plugins</cs>
   <de>Erweiterter Bildeditor - installiert GIMP, Hilfe und Plugins</de>
   <el>advanced picture editor- installs GIMP, help and plugins</el>
   <en>advanced picture editor- installs GIMP, help and plugins</en>
   <es>advanced picture editor- installs GIMP, help and plugins</es>
   <fi>advanced picture editor- installs GIMP, help and plugins</fi>
   <fr>advanced picture editor- installs GIMP, help and plugins</fr>
   <hi>advanced picture editor- installs GIMP, help and plugins</hi>
   <hr>advanced picture editor- installs GIMP, help and plugins</hr>
   <hu>advanced picture editor- installs GIMP, help and plugins</hu>
   <it>advanced picture editor- installs GIMP, help and plugins</it>
   <ja>advanced picture editor- installs GIMP, help and plugins</ja>
   <kk>advanced picture editor- installs GIMP, help and plugins</kk>
   <lt>advanced picture editor- installs GIMP, help and plugins</lt>
   <nl>advanced picture editor- installs GIMP, help and plugins</nl>
   <pl>advanced picture editor- installs GIMP, help and plugins</pl>
   <pt_BR>advanced picture editor- installs GIMP, help and plugins</pt_BR>
   <pt>advanced picture editor- installs GIMP, help and plugins</pt>
   <ro>advanced picture editor- installs GIMP, help and plugins</ro>
   <ru>advanced picture editor- installs GIMP, help and plugins</ru>
   <sk>advanced picture editor- installs GIMP, help and plugins</sk>
   <sv>avancerad bildredigerare - installerar GIMP, hjälp och plugins</sv>
   <tr>advanced picture editor- installs GIMP, help and plugins</tr>
   <uk>advanced picture editor- installs GIMP, help and plugins</uk>
   <zh_TW>advanced picture editor- installs GIMP, help and plugins</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/005/024/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gimp
gimp-data
gimp-data-extras
gimp-cbmplugs
gimp-dcraw
gimp-dds
gimp-gap
gimp-gluas
gimp-gmic
gimp-lensfun
gimp-texturize
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gimp
gimp-data
gimp-data-extras
gimp-cbmplugs
gimp-dcraw
gimp-dds
gimp-gap
gimp-gluas
gimp-gmic
gimp-lensfun
gimp-texturize
</uninstall_package_names>
</app>
