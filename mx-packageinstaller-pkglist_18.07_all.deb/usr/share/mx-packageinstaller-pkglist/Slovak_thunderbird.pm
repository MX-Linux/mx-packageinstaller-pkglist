<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Slovak_Thunderbird
</name>

<description>
   <am>Slovak localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Eslovac</ca>
   <cs>Slovak localisation of Thunderbird</cs>
   <de>Slowakische Lokalisierung von Thunderbird</de>
   <el>Slovak localisation of Thunderbird</el>
   <en>Slovak localisation of Thunderbird</en>
   <es>Slovak localisation of Thunderbird</es>
   <fi>Slovak localisation of Thunderbird</fi>
   <fr>Slovak localisation of Thunderbird</fr>
   <hi>Slovak localisation of Thunderbird</hi>
   <hr>Slovak localisation of Thunderbird</hr>
   <hu>Slovak localisation of Thunderbird</hu>
   <it>Slovak localisation of Thunderbird</it>
   <ja>Slovak localisation of Thunderbird</ja>
   <kk>Slovak localisation of Thunderbird</kk>
   <lt>Slovak localisation of Thunderbird</lt>
   <nl>Slovak localisation of Thunderbird</nl>
   <pl>Slovak localisation of Thunderbird</pl>
   <pt_BR>Slovak localisation of Thunderbird</pt_BR>
   <pt>Slovak localisation of Thunderbird</pt>
   <ro>Slovak localisation of Thunderbird</ro>
   <ru>Slovak localisation of Thunderbird</ru>
   <sk>Slovak localisation of Thunderbird</sk>
   <sv>Slovakisk lokalisering av Thunderbird</sv>
   <tr>Slovak localisation of Thunderbird</tr>
   <uk>Slovak localisation of Thunderbird</uk>
   <zh_TW>Slovak localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-sk
lightning-l10n-sk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-sk
lightning-l10n-sk
</uninstall_package_names>
</app>
