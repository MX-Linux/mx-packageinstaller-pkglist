<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Okular
</name>

<description>
   <am>a universal document viewer -WARNING- pulls in elements of KDE</am>
   <ca>a universal document viewer -WARNING- pulls in elements of KDE</ca>
   <cs>a universal document viewer -WARNING- pulls in elements of KDE</cs>
   <de>Ein universeller Dokumentbetrachter -WARNUNG- zieht Elemente von KDE ein</de>
   <el>a universal document viewer -WARNING- pulls in elements of KDE</el>
   <en>a universal document viewer -WARNING- pulls in elements of KDE</en>
   <es>a universal document viewer -WARNING- pulls in elements of KDE</es>
   <fi>a universal document viewer -WARNING- pulls in elements of KDE</fi>
   <fr>a universal document viewer -WARNING- pulls in elements of KDE</fr>
   <hi>a universal document viewer -WARNING- pulls in elements of KDE</hi>
   <hr>a universal document viewer -WARNING- pulls in elements of KDE</hr>
   <hu>a universal document viewer -WARNING- pulls in elements of KDE</hu>
   <it>a universal document viewer -WARNING- pulls in elements of KDE</it>
   <ja>a universal document viewer -WARNING- pulls in elements of KDE</ja>
   <kk>a universal document viewer -WARNING- pulls in elements of KDE</kk>
   <lt>a universal document viewer -WARNING- pulls in elements of KDE</lt>
   <nl>a universal document viewer -WARNING- pulls in elements of KDE</nl>
   <pl>a universal document viewer -WARNING- pulls in elements of KDE</pl>
   <pt_BR>a universal document viewer -WARNING- pulls in elements of KDE</pt_BR>
   <pt>a universal document viewer -WARNING- pulls in elements of KDE</pt>
   <ro>a universal document viewer -WARNING- pulls in elements of KDE</ro>
   <ru>a universal document viewer -WARNING- pulls in elements of KDE</ru>
   <sk>a universal document viewer -WARNING- pulls in elements of KDE</sk>
   <sv>en universiell dokumentläsare -Varning- drar in delar av KDE</sv>
   <tr>a universal document viewer -WARNING- pulls in elements of KDE</tr>
   <uk>a universal document viewer -WARNING- pulls in elements of KDE</uk>
   <zh_TW>a universal document viewer -WARNING- pulls in elements of KDE</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/644/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
okular
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
okular
</uninstall_package_names>
</app>
