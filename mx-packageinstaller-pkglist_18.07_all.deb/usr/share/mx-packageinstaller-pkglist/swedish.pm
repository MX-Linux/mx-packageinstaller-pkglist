<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Swedish
</name>

<description>
   <am>Swedish Language Meta-Package</am>
   <ca>Meta-paquet de llengua Sueca</ca>
   <cs>Swedish Language Meta-Package</cs>
   <de>Schwedisches Sprach-Meta-Paket</de>
   <el>Swedish Language Meta-Package</el>
   <en>Swedish Language Meta-Package</en>
   <es>Swedish Language Meta-Package</es>
   <fi>Swedish Language Meta-Package</fi>
   <fr>Swedish Language Meta-Package</fr>
   <hi>Swedish Language Meta-Package</hi>
   <hr>Swedish Language Meta-Package</hr>
   <hu>Swedish Language Meta-Package</hu>
   <it>Swedish Language Meta-Package</it>
   <ja>Swedish Language Meta-Package</ja>
   <kk>Swedish Language Meta-Package</kk>
   <lt>Swedish Language Meta-Package</lt>
   <nl>Swedish Language Meta-Package</nl>
   <pl>Swedish Language Meta-Package</pl>
   <pt_BR>Swedish Language Meta-Package</pt_BR>
   <pt>Swedish Language Meta-Package</pt>
   <ro>Swedish Language Meta-Package</ro>
   <ru>Swedish Language Meta-Package</ru>
   <sk>Swedish Language Meta-Package</sk>
   <sv>Svenskt Språk-Meta-Paket</sv>
   <tr>Swedish Language Meta-Package</tr>
   <uk>Swedish Language Meta-Package</uk>
   <zh_TW>Swedish Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-sv
myspell-sv-se
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-sv
myspell-sv-se
</uninstall_package_names>
</app>
