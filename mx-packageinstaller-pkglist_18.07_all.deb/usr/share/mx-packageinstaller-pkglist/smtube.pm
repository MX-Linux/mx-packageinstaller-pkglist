<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>
SMtube
</name>

<description>
   <am>search and download Youtube videos</am>
   <ca>Cerca i descarrega vídeos de Youtube</ca>
   <cs>search and download Youtube videos</cs>
   <de>YouTube-Videos finden und herunterladen</de>
   <el>search and download Youtube videos</el>
   <en>search and download Youtube videos</en>
   <es>search and download Youtube videos</es>
   <fi>search and download Youtube videos</fi>
   <fr>search and download Youtube videos</fr>
   <hi>search and download Youtube videos</hi>
   <hr>search and download Youtube videos</hr>
   <hu>search and download Youtube videos</hu>
   <it>search and download Youtube videos</it>
   <ja>search and download Youtube videos</ja>
   <kk>search and download Youtube videos</kk>
   <lt>search and download Youtube videos</lt>
   <nl>search and download Youtube videos</nl>
   <pl>search and download Youtube videos</pl>
   <pt_BR>search and download Youtube videos</pt_BR>
   <pt>search and download Youtube videos</pt>
   <ro>search and download Youtube videos</ro>
   <ru>search and download Youtube videos</ru>
   <sk>search and download Youtube videos</sk>
   <sv>sök och ladda ner Youtube videos</sv>
   <tr>search and download Youtube videos</tr>
   <uk>search and download Youtube videos</uk>
   <zh_TW>search and download Youtube videos</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/010/334/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
smtube
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
smtube
</uninstall_package_names>
</app>
