<?xml version="1.0"?>
<app>

<category>
Messaging
</category>

<name>  
1-to-1 Voice
</name>

<description>  
voice chat between two pc's via encrypted mumble
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
1-to-1-voice-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
1-to-1-voice-antix
</uninstall_package_names>
</app>