<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>  
DeaDBeeF
</name>

<description>  
simple audio player
</description>

<installable>
all
</installable>

<screenshot>http://deadbeef.sourceforge.net/screenshots/0.6/06.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
deadbeef
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
deadbeef
</uninstall_package_names>
</app>