<?xml version="1.0"?>
<app>

<category>
Network
</category>

<name>  
Blueman
</name>

<description>  
a GTK+ bluetooth management utility
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/965/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
blueman
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
blueman
</uninstall_package_names>
</app>