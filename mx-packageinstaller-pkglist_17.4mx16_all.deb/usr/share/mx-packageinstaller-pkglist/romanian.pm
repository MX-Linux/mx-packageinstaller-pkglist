<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Romanian
</name>

<description>  
Romanian Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
 aspell-ro
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
 aspell-ro
</uninstall_package_names>
</app>