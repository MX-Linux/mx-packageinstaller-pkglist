<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Hungarian
</name>

<description>  
Hungarian Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
      aspell-hu
      myspell-hu
      manpages-hu 
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
      aspell-hu
      myspell-hu
      manpages-hu 
</uninstall_package_names>
</app>