<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Hungarian_Firefox
</name>

<description>  
Hungarian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-hu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-hu
</uninstall_package_names>
</app>