<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>  
Cairo Dock
</name>

<description>  
3d capable dock w/ plugins
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/145/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
cairo-dock
cairo-dock-xfce-integration-plug-in
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
cairo-dock
cairo-dock-xfce-integration-plug-in
</uninstall_package_names>
</app>