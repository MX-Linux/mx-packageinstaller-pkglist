<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
ImageMagick
</name>

<description>  
a software suite to create, edit, and compose bitmap images
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
imagemagick
imagemagick-doc
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
imagemagick
imagemagick-doc
</uninstall_package_names>
</app>