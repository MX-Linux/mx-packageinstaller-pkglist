<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
4.10 32 bit no-pae
</name>

<description>  
antiX 4.10 kernel, 32 bit no-pae
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.10.1-antix.1-486-smp
linux-headers-4.10.1-antix.1-486-smp
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.10.1-antix.1-486-smp
linux-headers-4.10.1-antix.1-486-smp
</uninstall_package_names>
</app>