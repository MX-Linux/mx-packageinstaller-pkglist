<?xml version="1.0"?>
<app>

<category>
Flash
</category>

<name>  
adobe flash
</name>

<description>  
Official Adobe Flash, including plugins for chromium (pepperflash) and firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
adobe-flashplugin
adobe-flash-properties-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
adobe-flashplugin
adobe-flash-properties-gtk
</uninstall_package_names>
</app>