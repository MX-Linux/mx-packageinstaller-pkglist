<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Greek
</name>

<description>  
Greek Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-el
      myspell-el-gr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-el
      myspell-el-gr
</uninstall_package_names>
</app>