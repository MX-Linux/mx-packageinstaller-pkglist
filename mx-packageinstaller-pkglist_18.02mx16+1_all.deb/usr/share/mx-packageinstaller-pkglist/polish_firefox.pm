<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Polish_Firefox
</name>

<description>  
Polish localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-pl
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-pl
</uninstall_package_names>
</app>