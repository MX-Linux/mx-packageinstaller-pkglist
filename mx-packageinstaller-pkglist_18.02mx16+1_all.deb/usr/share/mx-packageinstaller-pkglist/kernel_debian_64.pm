<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
Debian 64 bit
</name>

<description>  
Fallback Debian 3.16 64bit linux kernel
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-3.16.0-5-amd64
linux-headers-3.16.0-5-amd64
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-3.16.0-5-amd64
linux-headers-3.16.0-5-amd64
</uninstall_package_names>
</app>
