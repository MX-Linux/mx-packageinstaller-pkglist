<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>  
Secondary
</name>

<description>  
Secondary. Includes: calibre, celestia, dia, laby, lightspeed, lybniz, melting, ri-li and stellarium
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
calibre
celestia-gnome
dia-gnome
laby
lightspeed
lybniz
melting
melting-gui
ri-li
stellarium
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
calibre
celestia-gnome
dia-gnome
laby
lightspeed
lybniz
melting
melting-gui
ri-li
stellarium
</uninstall_package_names>
</app>