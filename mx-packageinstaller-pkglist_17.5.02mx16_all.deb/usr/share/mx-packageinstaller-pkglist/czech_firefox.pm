<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Czech_Firefox
</name>

<description>  
Czech localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-cs
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-cs
</uninstall_package_names>
</app>