<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
Debian 32 bit w/pae
</name>

<description>  
Default Debian 3.16 32bit linux kernel w/PAE
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-3.16.0-4-686-pae
linux-headers-3.16.0-4-686-pae
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-3.16.0-4-686-pae
linux-headers-3.16.0-4-686-pae
</uninstall_package_names>
</app>