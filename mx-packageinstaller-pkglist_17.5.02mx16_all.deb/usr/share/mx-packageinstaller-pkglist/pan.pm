<?xml version="1.0"?>
<app>

<category>
Newsreader
</category>

<name>  
Pan
</name>

<description>  
a gnome Usenet newsreader
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/586/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pan
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pan
</uninstall_package_names>
</app>