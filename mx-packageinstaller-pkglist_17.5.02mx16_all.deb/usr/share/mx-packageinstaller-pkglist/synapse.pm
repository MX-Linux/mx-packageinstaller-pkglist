<?xml version="1.0"?>
<app>

<category>
Utility
</category>

<name>  
Synapse
</name>

<description>  
alternate semantic file launcher
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/035/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
synapse
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
synapse
</uninstall_package_names>
</app>