<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
gscan2pdf
</name>

<description>  
A GUI to produce PDFs or DjVus from scanned documents
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gscan2pdf 
djvulibre-bin
gocr 
unpaper
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gscan2pdf 
djvulibre-bin
gocr 
unpaper
</uninstall_package_names>
</app>