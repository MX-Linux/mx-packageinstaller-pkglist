<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Albanisan_Firefox
</name>

<description>  
Albanian localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sq
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sq
</uninstall_package_names>
</app>