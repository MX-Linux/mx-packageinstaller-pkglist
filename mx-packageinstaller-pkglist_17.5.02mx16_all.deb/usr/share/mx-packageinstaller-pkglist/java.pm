<?xml version="1.0"?>
<app>

<category>
Misc
</category>

<name>  
Java
</name>

<description>  
Java 8- installs openjdk-8 and icedtea
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
openjdk-8-jre
openjdk-8-jre-headless
icedtea-8-plugin 
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
openjdk-8-jre
openjdk-8-jre-headless
icedtea-8-plugin
</uninstall_package_names>
</app>