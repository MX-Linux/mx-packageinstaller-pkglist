<?xml version="1.0"?>
<app>

<category>
Misc
</category>

<name>  
KeepassX
</name>

<description>  
KeePassX is a free/open-source password manager/safe
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/308/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
keepassx
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
keepassx
</uninstall_package_names>
</app>