<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Korean_Libreoffice
</name>

<description>  
Korean localisation of LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-ko
	libreoffice-help-ko
        libreoffice-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-ko
	libreoffice-help-ko
        libreoffice-gtk
</uninstall_package_names>
</app>