<?xml version="1.0"?>
<app>

<category>
Screensaver
</category>

<name>
openGL screensavers
</name>

<description>
   <am>extra opengl screensavers</am>
   <ar>extra opengl screensavers</ar>
   <bg>extra opengl screensavers</bg>
   <ca>estalvis de pantalla opengl addicionals</ca>
   <cs>extra opengl screensavers</cs>
   <da>ekstra opengl-pauseskærme</da>
   <de>zusätzliche opengl Bildschirmschoner</de>
   <el>επιπλέον προφύλαξη οθόνης opengl</el>
   <en>extra opengl screensavers</en>
   <es>Salvapantallas opengl extra</es>
   <et>extra opengl screensavers</et>
   <eu>extra opengl screensavers</eu>
   <fa>extra opengl screensavers</fa>
   <fi>extra opengl screensavers</fi>
   <fr>écrans de veille opengl supplémentaires</fr>
   <he_IL>extra opengl screensavers</he_IL>
   <hi>extra opengl screensavers</hi>
   <hr>extra opengl screensavers</hr>
   <hu>extra opengl screensavers</hu>
   <id>extra opengl screensavers</id>
   <is>extra opengl screensavers</is>
   <it>screensaver opengl extra</it>
   <ja_JP>extra opengl screensavers</ja_JP>
   <ja>extra opengl screensavers</ja>
   <kk>extra opengl screensavers</kk>
   <ko>extra opengl screensavers</ko>
   <lt>extra opengl screensavers</lt>
   <mk>extra opengl screensavers</mk>
   <mr>extra opengl screensavers</mr>
   <nb>extra opengl screensavers</nb>
   <nl>extra opengl screensavers</nl>
   <pl>dodatkowe wygaszacze ekranu openGL</pl>
   <pt_BR>Proteções de tela opengl adicionais</pt_BR>
   <pt>protetores de ecrã opengl extra</pt>
   <ro>extra opengl screensavers</ro>
   <ru>extra opengl screensavers</ru>
   <sk>extra opengl screensavers</sk>
   <sl>Dodatni opengl ohranjevalniki zaslona</sl>
   <sq>extra opengl screensavers</sq>
   <sr>extra opengl screensavers</sr>
   <sv>extra opengl skärmsläckare</sv>
   <tr>extra opengl screensavers</tr>
   <uk>extra opengl screensavers</uk>
   <zh_CN>extra opengl screensavers</zh_CN>
   <zh_TW>extra opengl screensavers</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xscreensaver-gl
xscreensaver-gl-extra
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xscreensaver-gl
xscreensaver-gl-extra
</uninstall_package_names>
</app>
