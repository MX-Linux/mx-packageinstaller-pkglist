<?xml version="1.0"?>
<app>

<category>
Themes
</category>

<name>
Obsidian-2 Gtk Theme
</name>

<description>
   <am>a dark Gtk Theme</am>
   <ar>a dark Gtk Theme</ar>
   <bg>a dark Gtk Theme</bg>
   <ca>un tema GTK fosc</ca>
   <cs>a dark Gtk Theme</cs>
   <da>et mørkt Gtk-tema</da>
   <de>Ein dunkles Gtk-Thema</de>
   <el>ένα σκοτεινό θέμα Gtk</el>
   <en>a dark Gtk Theme</en>
   <es>Tema GTK oscuro</es>
   <et>a dark Gtk Theme</et>
   <eu>a dark Gtk Theme</eu>
   <fa>a dark Gtk Theme</fa>
   <fi>tumma Gtk ulkoasu</fi>
   <fr>Thème sombre GTK</fr>
   <he_IL>a dark Gtk Theme</he_IL>
   <hi>a dark Gtk Theme</hi>
   <hr>a dark Gtk Theme</hr>
   <hu>a dark Gtk Theme</hu>
   <id>a dark Gtk Theme</id>
   <is>a dark Gtk Theme</is>
   <it>un tema Gtk scuro</it>
   <ja_JP>a dark Gtk Theme</ja_JP>
   <ja>a dark Gtk Theme</ja>
   <kk>a dark Gtk Theme</kk>
   <ko>a dark Gtk Theme</ko>
   <lt>tamsi Gtk tema</lt>
   <mk>a dark Gtk Theme</mk>
   <mr>a dark Gtk Theme</mr>
   <nb>a dark Gtk Theme</nb>
   <nl>een donker Gtk thema</nl>
   <pl>ciemny motyw GTK</pl>
   <pt_BR>Tema escuro para Gtk</pt_BR>
   <pt>Tema escuro para Gtk</pt>
   <ro>a dark Gtk Theme</ro>
   <ru>Тёмная тема GTK</ru>
   <sk>a dark Gtk Theme</sk>
   <sl>Temna Gtk predloga</sl>
   <sq>a dark Gtk Theme</sq>
   <sr>a dark Gtk Theme</sr>
   <sv>ett mörkt Gtk Tema</sv>
   <tr>a dark Gtk Theme</tr>
   <uk>темна Gtk-тема</uk>
   <zh_CN>a dark Gtk Theme</zh_CN>
   <zh_TW>a dark Gtk Theme</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
obsidian-2-gtk-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
obsidian-2-gtk-theme
</uninstall_package_names>
</app>
