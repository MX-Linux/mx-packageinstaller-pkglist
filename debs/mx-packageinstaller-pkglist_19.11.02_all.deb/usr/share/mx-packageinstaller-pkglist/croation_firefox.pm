<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Croatian_Firefox
</name>

<description>
   <am>Croatian localisation of Firefox</am>
   <ar>Croatian localisation of Firefox</ar>
   <bg>Croatian localisation of Firefox</bg>
   <ca>Localització de Firefox en Croata</ca>
   <cs>Croatian localisation of Firefox</cs>
   <da>Kroatisk oversættelse af Firefox</da>
   <de>Kroatische Lokalisierung von Firefox</de>
   <el>Κροατικός εντοπισμός του Firefox</el>
   <en>Croatian localisation of Firefox</en>
   <es>Localización Croata de Firefox</es>
   <et>Croatian localisation of Firefox</et>
   <eu>Croatian localisation of Firefox</eu>
   <fa>Croatian localisation of Firefox</fa>
   <fi>Croatian localisation of Firefox</fi>
   <fr>Localisation croate pour Firefox</fr>
   <he_IL>Croatian localisation of Firefox</he_IL>
   <hi>Croatian localisation of Firefox</hi>
   <hr>Croatian localisation of Firefox</hr>
   <hu>Croatian localisation of Firefox</hu>
   <id>Croatian localisation of Firefox</id>
   <is>Croatian localisation of Firefox</is>
   <it>Localizzazione croata di Firefox</it>
   <ja_JP>Croatian localisation of Firefox</ja_JP>
   <ja>Croatian localisation of Firefox</ja>
   <kk>Croatian localisation of Firefox</kk>
   <ko>Croatian localisation of Firefox</ko>
   <lt>Croatian localisation of Firefox</lt>
   <mk>Croatian localisation of Firefox</mk>
   <mr>Croatian localisation of Firefox</mr>
   <nb>Croatian localisation of Firefox</nb>
   <nl>Kroatische lokalisatie van Firefox</nl>
   <pl>Chorwacka lokalizacja przeglądarki Firefox</pl>
   <pt_BR>Croata Localização para Firefox</pt_BR>
   <pt>Croata Localização para Firefox</pt>
   <ro>Croatian localisation of Firefox</ro>
   <ru>Хорватская локализация Firefox</ru>
   <sk>Croatian localisation of Firefox</sk>
   <sl>Croatian localisation of Firefox</sl>
   <sq>Croatian localisation of Firefox</sq>
   <sr>Croatian localisation of Firefox</sr>
   <sv>Kroatisk lokalisering av Firefox</sv>
   <tr>Croatian localisation of Firefox</tr>
   <uk>Croatian локалізація Firefox</uk>
   <zh_CN>Croatian localisation of Firefox</zh_CN>
   <zh_TW>Croatian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-hr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-hr
</uninstall_package_names>
</app>
