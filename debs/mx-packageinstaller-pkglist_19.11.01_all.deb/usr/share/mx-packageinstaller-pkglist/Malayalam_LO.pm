<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Malayalam_Libreoffice
</name>

<description>
   <am>Malayalam Language Meta-Package for LibreOffice</am>
   <ar>Malayalam Language Meta-Package for LibreOffice</ar>
   <bg>Malayalam Language Meta-Package for LibreOffice</bg>
   <ca>Meta-paquet d'Malayalam per LibreOffice</ca>
   <cs>Malayalam Language Meta-Package for LibreOffice</cs>
   <da>Malayalam sprog-metapakke til LibreOffice</da>
   <de>Malayalam Meta-Paket für LibreOffice</de>
   <el>LibreOffice στα Malayalam</el>
   <en>Malayalam Language Meta-Package for LibreOffice</en>
   <es>Meta-Paquete de Idioma Malayalam para LibreOffice</es>
   <et>Malayalam Language Meta-Package for LibreOffice</et>
   <eu>Malayalam Language Meta-Package for LibreOffice</eu>
   <fa>Malayalam Language Meta-Package for LibreOffice</fa>
   <fi>Malayalam Language Meta-Package for LibreOffice</fi>
   <fr>Méta-paquet langue Malayalam pour LibreOffice</fr>
   <he_IL>Malayalam Language Meta-Package for LibreOffice</he_IL>
   <hi>Malayalam Language Meta-Package for LibreOffice</hi>
   <hr>Malayalam Language Meta-Package for LibreOffice</hr>
   <hu>Malayalam Language Meta-Package for LibreOffice</hu>
   <id>Malayalam Language Meta-Package for LibreOffice</id>
   <is>Malayalam Language Meta-Package for LibreOffice</is>
   <it>Meta-pacchetto della lingua Malayalam per LibreOffice</it>
   <ja_JP>Malayalam Language Meta-Package for LibreOffice</ja_JP>
   <ja>Malayalam Language Meta-Package for LibreOffice</ja>
   <kk>Malayalam Language Meta-Package for LibreOffice</kk>
   <ko>Malayalam Language Meta-Package for LibreOffice</ko>
   <lt>Malayalam Language Meta-Package for LibreOffice</lt>
   <mk>Malayalam Language Meta-Package for LibreOffice</mk>
   <mr>Malayalam Language Meta-Package for LibreOffice</mr>
   <nb>Malayalam Language Meta-Package for LibreOffice</nb>
   <nl>Malayalam Taal Meta-Pakket voor LibreOffice</nl>
   <pl>Malayalam metapakiet językowy dla LibreOffice</pl>
   <pt_BR>Malayalam Meta-Pacote de Idioma para LibreOffice</pt_BR>
   <pt>Malayalam Meta-Pacote de Idioma para LibreOffice</pt>
   <ro>Malayalam Language Meta-Package for LibreOffice</ro>
   <ru>Malayalam Language Meta-Package for LibreOffice</ru>
   <sk>Malayalam Language Meta-Package for LibreOffice</sk>
   <sl>Malayalam Language Meta-Package for LibreOffice</sl>
   <sq>Malayalam Language Meta-Package for LibreOffice</sq>
   <sr>Malayalam Language Meta-Package for LibreOffice</sr>
   <sv>Malayalam Språk Meta-Paket för LibreOffice</sv>
   <tr>Malayalam Language Meta-Package for LibreOffice</tr>
   <uk>Malayalam Language Meta-Package for LibreOffice</uk>
   <zh_CN>Malayalam Language Meta-Package for LibreOffice</zh_CN>
   <zh_TW>Malayalam Language Meta-Package for LibreOffice</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>


<preinstall>

package_list="
libreoffice-l10n-ml
"
lo-installer.sh $package_list

</preinstall>

<install_package_names>

</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-l10n-ml
</uninstall_package_names>
</app>
