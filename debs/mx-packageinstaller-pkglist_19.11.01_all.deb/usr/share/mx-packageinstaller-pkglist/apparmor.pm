<?xml version="1.0"?>
<app>

<category>
Utility
</category>

<name>
apparmor
</name>

<description>
   <am>Userspace components of AppArmor</am>
   <ar>Userspace components of AppArmor</ar>
   <bg>Userspace components of AppArmor</bg>
   <ca>Userspace components of AppArmor</ca>
   <cs>Userspace components of AppArmor</cs>
   <da>Userspace components of AppArmor</da>
   <de>Userspace components of AppArmor</de>
   <el>Userspace components of AppArmor</el>
   <en>Userspace components of AppArmor </en>
   <es>Userspace components of AppArmor</es>
   <et>Userspace components of AppArmor</et>
   <eu>Userspace components of AppArmor</eu>
   <fa>Userspace components of AppArmor</fa>
   <fi>Userspace components of AppArmor</fi>
   <fr>Userspace components of AppArmor</fr>
   <he_IL>Userspace components of AppArmor</he_IL>
   <hi>Userspace components of AppArmor</hi>
   <hr>Userspace components of AppArmor</hr>
   <hu>Userspace components of AppArmor</hu>
   <id>Userspace components of AppArmor</id>
   <is>Userspace components of AppArmor</is>
   <it>Userspace components of AppArmor</it>
   <ja_JP>Userspace components of AppArmor</ja_JP>
   <ja>Userspace components of AppArmor</ja>
   <kk>Userspace components of AppArmor</kk>
   <ko>Userspace components of AppArmor</ko>
   <lt>Userspace components of AppArmor</lt>
   <mk>Userspace components of AppArmor</mk>
   <mr>Userspace components of AppArmor</mr>
   <nb>Userspace components of AppArmor</nb>
   <nl>Userspace components of AppArmor</nl>
   <pl>Userspace components of AppArmor</pl>
   <pt_BR>Userspace components of AppArmor</pt_BR>
   <pt>Userspace components of AppArmor</pt>
   <ro>Userspace components of AppArmor</ro>
   <ru>Userspace components of AppArmor</ru>
   <sk>Userspace components of AppArmor</sk>
   <sl>Userspace components of AppArmor</sl>
   <sq>Userspace components of AppArmor</sq>
   <sr>Userspace components of AppArmor</sr>
   <sv>Userspace components of AppArmor</sv>
   <tr>Userspace components of AppArmor</tr>
   <uk>Userspace components of AppArmor</uk>
   <zh_CN>Userspace components of AppArmor</zh_CN>
   <zh_TW>Userspace components of AppArmor</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
apparmor
apparmor-profiles
apparmor-utils
</install_package_names>


<postinstall>
</postinstall>


<uninstall_package_names>
apparmor
apparmor-profiles
apparmor-utils
</uninstall_package_names>
</app>
