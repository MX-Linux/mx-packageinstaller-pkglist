<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>
Pithos
</name>

<description>
   <am>a native Pandora Radio client</am>
   <ar>a native Pandora Radio client</ar>
   <bg>a native Pandora Radio client</bg>
   <ca>client nadiu de Pandora Radio</ca>
   <cs>a native Pandora Radio client</cs>
   <da>en native Pandora radio-klient</da>
   <de>Ein einheimischer Pandora-Radio-Client</de>
   <el>Pandora Radio</el>
   <en>a native Pandora Radio client</en>
   <es>Cliente de radio de Pandora nativo</es>
   <et>a native Pandora Radio client</et>
   <eu>a native Pandora Radio client</eu>
   <fa>a native Pandora Radio client</fa>
   <fi>a native Pandora Radio client</fi>
   <fr>Client Radio natif Pandora</fr>
   <he_IL>a native Pandora Radio client</he_IL>
   <hi>a native Pandora Radio client</hi>
   <hr>a native Pandora Radio client</hr>
   <hu>a native Pandora Radio client</hu>
   <id>a native Pandora Radio client</id>
   <is>a native Pandora Radio client</is>
   <it>client per la radio web Pandora</it>
   <ja_JP>a native Pandora Radio client</ja_JP>
   <ja>a native Pandora Radio client</ja>
   <kk>a native Pandora Radio client</kk>
   <ko>a native Pandora Radio client</ko>
   <lt>a native Pandora Radio client</lt>
   <mk>a native Pandora Radio client</mk>
   <mr>a native Pandora Radio client</mr>
   <nb>a native Pandora Radio client</nb>
   <nl>een origineel Pandora Radio programma</nl>
   <pl>natywny klient Radio Pandora</pl>
   <pt_BR>Cliente para Pandora Radio (uma emissora americana)</pt_BR>
   <pt>Cliente para Pandora Radio (uma emissora americana)</pt>
   <ro>a native Pandora Radio client</ro>
   <ru>Нативный клиент сервиса потокового аудио Pandora (радио)</ru>
   <sk>a native Pandora Radio client</sk>
   <sl>Odjemalec za Pandora radio</sl>
   <sq>a native Pandora Radio client</sq>
   <sr>a native Pandora Radio client</sr>
   <sv>en naturlig Pandora Radio klient</sv>
   <tr>a native Pandora Radio client</tr>
   <uk>a native Pandora Radio client</uk>
   <zh_CN>a native Pandora Radio client</zh_CN>
   <zh_TW>a native Pandora Radio client</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/199/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pithos
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pithos
</uninstall_package_names>
</app>
