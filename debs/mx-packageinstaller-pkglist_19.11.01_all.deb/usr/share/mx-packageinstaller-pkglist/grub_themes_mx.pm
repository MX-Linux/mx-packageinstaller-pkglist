<?xml version="1.0"?>
<app>

<category>
Themes
</category>

<name>
grub-themes-mx
</name>

<description>
   <am>themes for grub boot menu</am>
   <ar>themes for grub boot menu</ar>
   <bg>themes for grub boot menu</bg>
   <ca>Temes per al menú d'arrencada GRUB</ca>
   <cs>themes for grub boot menu</cs>
   <da>temaer til grub-opstartsmenu</da>
   <de>Oberflächen für das GRUB Bootmenü</de>
   <el>θέματα για το μενού εκκίνησης grub</el>
   <en>themes for grub boot menu</en>
   <es>Temas para el menú de arranque grub</es>
   <et>themes for grub boot menu</et>
   <eu>themes for grub boot menu</eu>
   <fa>themes for grub boot menu</fa>
   <fi>themes for grub boot menu</fi>
   <fr>thèmes pour le menu de démarrage du grub</fr>
   <he_IL>themes for grub boot menu</he_IL>
   <hi>themes for grub boot menu</hi>
   <hr>themes for grub boot menu</hr>
   <hu>themes for grub boot menu</hu>
   <id>themes for grub boot menu</id>
   <is>themes for grub boot menu</is>
   <it>temi per il menu di boot grub</it>
   <ja_JP>themes for grub boot menu</ja_JP>
   <ja>themes for grub boot menu</ja>
   <kk>themes for grub boot menu</kk>
   <ko>themes for grub boot menu</ko>
   <lt>themes for grub boot menu</lt>
   <mk>themes for grub boot menu</mk>
   <mr>themes for grub boot menu</mr>
   <nb>themes for grub boot menu</nb>
   <nl>thema's voor grub boot menu</nl>
   <pl>motywy dla menu rozruchowego grub</pl>
   <pt_BR>Temas para  o menu do grub</pt_BR>
   <pt>Temas para  o menu do grub</pt>
   <ro>themes for grub boot menu</ro>
   <ru>темы для меню загрузки GRUB</ru>
   <sk>themes for grub boot menu</sk>
   <sl>teme za grub zagonski meni</sl>
   <sq>themes for grub boot menu</sq>
   <sr>themes for grub boot menu</sr>
   <sv>theman för grub boot meny</sv>
   <tr>themes for grub boot menu</tr>
   <uk>themes for grub boot menu</uk>
   <zh_CN>themes for grub boot menu</zh_CN>
   <zh_TW>themes for grub boot menu</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
grub-themes-mx
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
grub-themes-mx
</uninstall_package_names>
</app>
