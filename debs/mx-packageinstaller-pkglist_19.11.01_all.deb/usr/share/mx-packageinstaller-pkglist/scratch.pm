<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>
Scratch
</name>

<description>
   <am>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</am>
   <ar>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ar>
   <bg>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</bg>
   <ca>Entorn de programació gràfic Scratch del M.I.T (https://scratch.mit.edu/)</ca>
   <cs>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</cs>
   <da>Scratch grafisk programmeringsmiljø fra M.I.T. https://scratch.mit.edu/</da>
   <de>Scratch Graphical Programming Umgebung von M.I.T. https://scratch.mit.edu/</de>
   <el>Περιβάλλον γραφικού προγραμματισμού Scratch από το M.I.T. https://scratch.mit.edu/</el>
   <en>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</en>
   <es>Entorno de Programación de Scratch Gráfico del M.I.T. https://scratch.mit.edu/</es>
   <et>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</et>
   <eu>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</eu>
   <fa>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</fa>
   <fi>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</fi>
   <fr>Environnement graphique de programmation Scratch de M.I.T. https://scratch.mit.edu/</fr>
   <he_IL>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</he_IL>
   <hi>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</hi>
   <hr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</hr>
   <hu>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</hu>
   <id>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</id>
   <is>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</is>
   <it>Ambiente di programmazione grafica Scratch dal M.I.T. https://scratch.mit.edu/</it>
   <ja_JP>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ja_JP>
   <ja>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ja>
   <kk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</kk>
   <ko>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ko>
   <lt>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</lt>
   <mk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</mk>
   <mr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</mr>
   <nb>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</nb>
   <nl>Scratch Grafische Progammeer Omgeving van M.I.T. https://scratch.mit.edu/</nl>
   <pl>programistyczne środowisko graficzne Scratch od M.I.T. https://scratch.mit.edu/</pl>
   <pt_BR>Ambiente de programação gráfica Scratch do M.I.T. https://scratch.mit.edu/</pt_BR>
   <pt>Ambiente de programação gráfica Scratch do M.I.T. https://scratch.mit.edu/</pt>
   <ro>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</ro>
   <ru>Окружение визуального программирования Scratch https://scratch.mit.edu/</ru>
   <sk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</sk>
   <sl>Scratch grafično okolje za učenje programiranja (M.I.T. https://scratch.mit.edu/)</sl>
   <sq>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</sq>
   <sr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</sr>
   <sv>Scratch Grafisk Programmeringsmiljö från M.I.T. https://scratch.mit.edu/</sv>
   <tr>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</tr>
   <uk>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</uk>
   <zh_CN>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</zh_CN>
   <zh_TW>Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
scratch
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
scratch
</uninstall_package_names>
</app>
