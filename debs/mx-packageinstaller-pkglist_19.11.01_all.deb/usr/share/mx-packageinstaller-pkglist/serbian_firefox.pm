<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Serbian_Firefox
</name>

<description>
   <am>Serbian localisation of Firefox</am>
   <ar>Serbian localisation of Firefox</ar>
   <bg>Serbian localisation of Firefox</bg>
   <ca>Localització de Firefox en Serbi</ca>
   <cs>Serbian localisation of Firefox</cs>
   <da>Serbisk oversættelse af Firefox</da>
   <de>Serbische Lokalisierung von Firefox</de>
   <el>Σερβικός εντοπισμός του Firefox</el>
   <en>Serbian localisation of Firefox</en>
   <es>Localización Serbia de Firefox</es>
   <et>Serbian localisation of Firefox</et>
   <eu>Serbian localisation of Firefox</eu>
   <fa>Serbian localisation of Firefox</fa>
   <fi>Serbian localisation of Firefox</fi>
   <fr>Localisation serbe pour Firefox</fr>
   <he_IL>Serbian localisation of Firefox</he_IL>
   <hi>Serbian localisation of Firefox</hi>
   <hr>Serbian localisation of Firefox</hr>
   <hu>Serbian localisation of Firefox</hu>
   <id>Serbian localisation of Firefox</id>
   <is>Serbian localisation of Firefox</is>
   <it>Localizzazione serba di Firefox</it>
   <ja_JP>Serbian localisation of Firefox</ja_JP>
   <ja>Serbian localisation of Firefox</ja>
   <kk>Serbian localisation of Firefox</kk>
   <ko>Serbian localisation of Firefox</ko>
   <lt>Serbian localisation of Firefox</lt>
   <mk>Serbian localisation of Firefox</mk>
   <mr>Serbian localisation of Firefox</mr>
   <nb>Serbian localisation of Firefox</nb>
   <nl>Servische lokalisatie van Firefox</nl>
   <pl>Serbska lokalizacja przeglądarki Firefox</pl>
   <pt_BR>Sérvio Localização para Firefox</pt_BR>
   <pt>Sérvio Localização para Firefox</pt>
   <ro>Serbian localisation of Firefox</ro>
   <ru>Сербская локализация Firefox</ru>
   <sk>Serbian localisation of Firefox</sk>
   <sl>Serbian localisation of Firefox</sl>
   <sq>Serbian localisation of Firefox</sq>
   <sr>Serbian localisation of Firefox</sr>
   <sv>Serbisk  lokalisering av Firefox</sv>
   <tr>Serbian localisation of Firefox</tr>
   <uk>Serbian localisation of Firefox</uk>
   <zh_CN>Serbian localisation of Firefox</zh_CN>
   <zh_TW>Serbian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sr
</uninstall_package_names>
</app>
