<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Audio
</category>

<name>
MOC
</name>

<description>
   <am>a console audio player designed to be powerful and easy to use</am>
   <ar>a console audio player designed to be powerful and easy to use</ar>
   <bg>a console audio player designed to be powerful and easy to use</bg>
   <bn>a console audio player designed to be powerful and easy to use</bn>
   <ca>reproductor d'àudio dissenyat per a ser potent i fàcil d'usar</ca>
   <cs>a console audio player designed to be powerful and easy to use</cs>
   <da>en konsol-lydafspiller som er designet til at være kraftfuld og let at bruge</da>
   <de>Ein Konsolen-Audio-Player, der leistungsstark und einfach zu bedienen ist.</de>
   <el>ένα κονσόλα ήχου που έχει σχεδιαστεί για να είναι ισχυρό και εύκολο στη χρήση</el>
   <en>a console audio player designed to be powerful and easy to use</en>
   <es>Reproductor de audio para consola de comandos potente y fácil de usar</es>
   <et>a console audio player designed to be powerful and easy to use</et>
   <eu>a console audio player designed to be powerful and easy to use</eu>
   <fa>a console audio player designed to be powerful and easy to use</fa>
   <fil_PH>a console audio player designed to be powerful and easy to use</fil_PH>
   <fi>a console audio player designed to be powerful and easy to use</fi>
   <fr>Un lecteur audio en console puissant et simple d'utilisation</fr>
   <he_IL>a console audio player designed to be powerful and easy to use</he_IL>
   <hi>a console audio player designed to be powerful and easy to use</hi>
   <hr>a console audio player designed to be powerful and easy to use</hr>
   <hu>a console audio player designed to be powerful and easy to use</hu>
   <id>a console audio player designed to be powerful and easy to use</id>
   <is>a console audio player designed to be powerful and easy to use</is>
   <it>un lettore audio da terminale progettato per essere completo e facile da usare</it>
   <ja_JP>a console audio player designed to be powerful and easy to use</ja_JP>
   <ja>a console audio player designed to be powerful and easy to use</ja>
   <kk>a console audio player designed to be powerful and easy to use</kk>
   <ko>a console audio player designed to be powerful and easy to use</ko>
   <lt>a console audio player designed to be powerful and easy to use</lt>
   <mk>a console audio player designed to be powerful and easy to use</mk>
   <mr>a console audio player designed to be powerful and easy to use</mr>
   <nb>a console audio player designed to be powerful and easy to use</nb>
   <nl>een krachtige en gebruiksvriendelijke audiospeler voor de console</nl>
   <pl>konsolowy odtwarzacz audio zaprojektowany tak, aby był potężny i łatwy w użyciu</pl>
   <pt_BR>Reprodutor de áudio em consola/terminal concebido para ser poderoso e fácil de usar</pt_BR>
   <pt>Reprodutor de áudio em consola/terminal concebido para ser poderoso e fácil de usar</pt>
   <ro>a console audio player designed to be powerful and easy to use</ro>
   <ru>Консольный аудиоплеер созданный для простоты использования и богатого функционала</ru>
   <sk>a console audio player designed to be powerful and easy to use</sk>
   <sl>Zvočni predvajalnik v konzoli, ki je enostaven a zmogljiv</sl>
   <sq>a console audio player designed to be powerful and easy to use</sq>
   <sr>a console audio player designed to be powerful and easy to use</sr>
   <sv>en konsol-ljudspelare designad för att vara kraftfull och lättanvänd</sv>
   <tr>a console audio player designed to be powerful and easy to use</tr>
   <uk>консольний програвач аудіо створений що бути потужним та простим у використанні</uk>
   <vi>a console audio player designed to be powerful and easy to use</vi>
   <zh_CN>a console audio player designed to be powerful and easy to use</zh_CN>
   <zh_TW>a console audio player designed to be powerful and easy to use</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/20427/simage/large-48df6b264973a11ecefa1f918660d0ff.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
moc
moc-ffmpeg-plugin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
moc
moc-ffmpeg-plugin
</uninstall_package_names>
</app>
