<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Children
</category>

<name>
Primary
</name>

<description>
   <am>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</am>
   <ar>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ar>
   <bg>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</bg>
   <bn>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</bn>
   <ca>Primària: inclou gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, i marble</ca>
   <cs>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</cs>
   <da>Grundskole. Inkluderer: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype og marble</da>
   <de>Grundschule: Enthält Gcompris, Laby, Ri-Li, Stellarium, Tuxmath, Tuxpaint, Tuxtype und Marmor.</de>
   <el>Πρωταρχικός. Περιλαμβάνει: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype και marble</el>
   <en>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</en>
   <es>Primario. Incluye: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, y marble</es>
   <et>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</et>
   <eu>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</eu>
   <fa>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</fa>
   <fil_PH>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</fil_PH>
   <fi>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</fi>
   <fr>Primaire. Inclus: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, et marble</fr>
   <he_IL>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</he_IL>
   <hi>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</hi>
   <hr>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</hr>
   <hu>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</hu>
   <id>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</id>
   <is>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</is>
   <it>Medie. Include: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, e marble</it>
   <ja_JP>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ja_JP>
   <ja>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ja>
   <kk>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</kk>
   <ko>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ko>
   <lt>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</lt>
   <mk>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</mk>
   <mr>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</mr>
   <nb>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</nb>
   <nl>Basis. Inclusief: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, en marble</nl>
   <pl>Szkoła podstawowa. Zawiera: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype i marble</pl>
   <pt_BR>Ensino fundamental (1º ao 6º ano). Inclui: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, e marble</pt_BR>
   <pt>Ensino básico, 1º e 2º ciclos. Inclui: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, e marble</pt>
   <ro>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</ro>
   <ru>Начальная школа, включает: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype и marble</ru>
   <sk>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</sk>
   <sl>Osnovna šola. Vsebuje: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype in marble</sl>
   <sq>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</sq>
   <sr>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</sr>
   <sv>Primary. Inkluderar: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, och marble</sv>
   <tr>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</tr>
   <uk>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</uk>
   <vi>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</vi>
   <zh_CN>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</zh_CN>
   <zh_TW>Primary. Includes: gcompris, laby, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gcompris-qt
laby
ri-li
stellarium
tuxmath
tuxpaint
tuxtype
marble-qt
marble-plugins
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gcompris-qt
laby
ri-li
stellarium
tuxmath
tuxpaint
tuxtype
marble-qt
marble-plugins
</uninstall_package_names>
</app>
