<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Torrent
</category>

<name>
Deluge
</name>

<description>
   <am>bittorrent client written in Python/PyGTK</am>
   <ar>bittorrent client written in Python/PyGTK</ar>
   <bg>bittorrent client written in Python/PyGTK</bg>
   <bn>bittorrent client written in Python/PyGTK</bn>
   <ca>bittorrent client written in Python/PyGTK</ca>
   <cs>bittorrent client written in Python/PyGTK</cs>
   <da>bittorrent client written in Python/PyGTK</da>
   <de>bittorrent client written in Python/PyGTK</de>
   <el>bittorrent client written in Python/PyGTK</el>
   <en>bittorrent client written in Python/PyGTK</en>
   <es>bittorrent client written in Python/PyGTK</es>
   <et>bittorrent client written in Python/PyGTK</et>
   <eu>bittorrent client written in Python/PyGTK</eu>
   <fa>bittorrent client written in Python/PyGTK</fa>
   <fil_PH>bittorrent client written in Python/PyGTK</fil_PH>
   <fi>bittorrent client written in Python/PyGTK</fi>
   <fr>bittorrent client written in Python/PyGTK</fr>
   <he_IL>bittorrent client written in Python/PyGTK</he_IL>
   <hi>bittorrent client written in Python/PyGTK</hi>
   <hr>bittorrent client written in Python/PyGTK</hr>
   <hu>bittorrent client written in Python/PyGTK</hu>
   <id>bittorrent client written in Python/PyGTK</id>
   <is>bittorrent client written in Python/PyGTK</is>
   <it>client BitTorrent che usa ncurses</it>
   <ja_JP>bittorrent client written in Python/PyGTK</ja_JP>
   <ja>bittorrent client written in Python/PyGTK</ja>
   <kk>bittorrent client written in Python/PyGTK</kk>
   <ko>bittorrent client written in Python/PyGTK</ko>
   <lt>bittorrent client written in Python/PyGTK</lt>
   <mk>bittorrent client written in Python/PyGTK</mk>
   <mr>bittorrent client written in Python/PyGTK</mr>
   <nb>bittorrent client written in Python/PyGTK</nb>
   <nl>bittorrent client written in Python/PyGTK</nl>
   <pl>bittorrent client written in Python/PyGTK</pl>
   <pt_BR>bittorrent client written in Python/PyGTK</pt_BR>
   <pt>bittorrent client written in Python/PyGTK</pt>
   <ro>bittorrent client written in Python/PyGTK</ro>
   <ru>bittorrent client written in Python/PyGTK</ru>
   <sk>bittorrent client written in Python/PyGTK</sk>
   <sl>bittorrent client written in Python/PyGTK</sl>
   <sq>bittorrent client written in Python/PyGTK</sq>
   <sr>bittorrent client written in Python/PyGTK</sr>
   <sv>bittorrent client written in Python/PyGTK</sv>
   <tr>bittorrent client written in Python/PyGTK</tr>
   <uk>bittorrent client written in Python/PyGTK</uk>
   <vi>bittorrent client written in Python/PyGTK</vi>
   <zh_CN>bittorrent client written in Python/PyGTK</zh_CN>
   <zh_TW>bittorrent client written in Python/PyGTK</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/7843/simage/large-9b59ed83a57ba3cd871f3a1e6e3024d0.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
deluge
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
deluge
</uninstall_package_names>
</app>
