<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Icons
</category>

<name>
Numix Circle Icons
</name>

<description>
   <am>numix circular icons</am>
   <ar>numix circular icons</ar>
   <bg>numix circular icons</bg>
   <bn>numix circular icons</bn>
   <ca>Icones circulars numix</ca>
   <cs>numix circular icons</cs>
   <da>numix cirkulære ikoner</da>
   <de>Symbolthema Numix Circle</de>
   <el>εικονίδια numix κυκλικά</el>
   <en>numix circular icons</en>
   <es>Numix iconos circulares</es>
   <et>numix circular icons</et>
   <eu>numix circular icons</eu>
   <fa>numix circular icons</fa>
   <fil_PH>numix circular icons</fil_PH>
   <fi>numix circular icons</fi>
   <fr>icons numix sous forme de cercles</fr>
   <he_IL>numix circular icons</he_IL>
   <hi>numix circular icons</hi>
   <hr>numix circular icons</hr>
   <hu>numix circular icons</hu>
   <id>numix circular icons</id>
   <is>numix circular icons</is>
   <it>numix icone rotonde</it>
   <ja_JP>numix circular icons</ja_JP>
   <ja>numix circular icons</ja>
   <kk>numix circular icons</kk>
   <ko>numix circular icons</ko>
   <lt>numix circular icons</lt>
   <mk>numix circular icons</mk>
   <mr>numix circular icons</mr>
   <nb>numix circular icons</nb>
   <nl>numix cirkelvormige iconen</nl>
   <pl>okrągłe ikony numix</pl>
   <pt_BR>Ícones circulares numix</pt_BR>
   <pt>Ícones circulares numix</pt>
   <ro>numix circular icons</ro>
   <ru>Круглые значки Numix</ru>
   <sk>numix circular icons</sk>
   <sl>Okrogle numix ikone</sl>
   <sq>numix circular icons</sq>
   <sr>numix circular icons</sr>
   <sv>numix cirkelrunda ikoner</sv>
   <tr>numix yuvarlak simgeler</tr>
   <uk>numix circular icons</uk>
   <vi>numix circular icons</vi>
   <zh_CN>numix circular icons</zh_CN>
   <zh_TW>numix circular icons</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
numix-icon-theme-circle
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
numix-icon-theme-circle
</uninstall_package_names>
</app>
