<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Screensaver
</category>

<name>
xscreensaver
</name>

<description>
   <am>the classic screensaver for X servers</am>
   <ar>the classic screensaver for X servers</ar>
   <bg>the classic screensaver for X servers</bg>
   <bn>the classic screensaver for X servers</bn>
   <ca>l'estalvi de pantalla clàssic per a servidors de X</ca>
   <cs>the classic screensaver for X servers</cs>
   <da>den klassiske pauseskærm til X-servere</da>
   <de>klassische Bildschirmschoner für X Server</de>
   <el>κλασική προφύλαξη οθόνης</el>
   <en>the classic screensaver for X servers</en>
   <es>El protector de pantalla clásico para servidores X</es>
   <et>the classic screensaver for X servers</et>
   <eu>the classic screensaver for X servers</eu>
   <fa>the classic screensaver for X servers</fa>
   <fil_PH>the classic screensaver for X servers</fil_PH>
   <fi>the classic screensaver for X servers</fi>
   <fr>Écran de veille classique des serveurs X</fr>
   <he_IL>the classic screensaver for X servers</he_IL>
   <hi>the classic screensaver for X servers</hi>
   <hr>the classic screensaver for X servers</hr>
   <hu>the classic screensaver for X servers</hu>
   <id>the classic screensaver for X servers</id>
   <is>the classic screensaver for X servers</is>
   <it>il classico salvaschermo per server X</it>
   <ja_JP>the classic screensaver for X servers</ja_JP>
   <ja>the classic screensaver for X servers</ja>
   <kk>the classic screensaver for X servers</kk>
   <ko>the classic screensaver for X servers</ko>
   <lt>klasikinė ekrano užsklanda, skirta X serveriams</lt>
   <mk>the classic screensaver for X servers</mk>
   <mr>the classic screensaver for X servers</mr>
   <nb>the classic screensaver for X servers</nb>
   <nl>de klassieke screensaver voor X servers</nl>
   <pl>klasyczny wygaszacz ekranu dla serwerów X</pl>
   <pt_BR>A proteção de tela clássica para servidores X</pt_BR>
   <pt>A protecção de ecrã clássica para servidores X</pt>
   <ro>the classic screensaver for X servers</ro>
   <ru>классические заставки экрана для X сервера</ru>
   <sk>the classic screensaver for X servers</sk>
   <sl>Klasični ohranjevalniki zaslona za X strežnike</sl>
   <sq>the classic screensaver for X servers</sq>
   <sr>the classic screensaver for X servers</sr>
   <sv>klassisk skärmsläckare för X server</sv>
   <tr>the classic screensaver for X servers</tr>
   <uk>the classic screensaver for X servers</uk>
   <vi>the classic screensaver for X servers</vi>
   <zh_CN>the classic screensaver for X servers</zh_CN>
   <zh_TW>the classic screensaver for X servers</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xscreensaver
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xscreensaver
</uninstall_package_names>
</app>
