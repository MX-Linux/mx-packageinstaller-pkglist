<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Games
</category>

<name>
Play on Linux
</name>

<description>
   <am>Play on Linux</am>
   <ar>Play on Linux</ar>
   <bg>Play on Linux</bg>
   <bn>Play on Linux</bn>
   <ca>Play on Linux</ca>
   <cs>Play on Linux</cs>
   <da>Play on Linux</da>
   <de>Ein grafisches Frontend für Wine</de>
   <el>Play on Linux</el>
   <en>Play on Linux</en>
   <es>Play on Linux</es>
   <et>Play on Linux</et>
   <eu>Play on Linux</eu>
   <fa>Play on Linux</fa>
   <fil_PH>Play on Linux</fil_PH>
   <fi>Play on Linux</fi>
   <fr>Play on Linux</fr>
   <he_IL>Play on Linux</he_IL>
   <hi>Play on Linux</hi>
   <hr>Play on Linux</hr>
   <hu>Play on Linux</hu>
   <id>Play on Linux</id>
   <is>Play on Linux</is>
   <it>Play on Linux</it>
   <ja_JP>Play on Linux</ja_JP>
   <ja>Play on Linux</ja>
   <kk>Play on Linux</kk>
   <ko>Play on Linux</ko>
   <lt>Play on Linux</lt>
   <mk>Play on Linux</mk>
   <mr>Play on Linux</mr>
   <nb>Play on Linux</nb>
   <nl>Speel op Linux</nl>
   <pl>umożliwia łatwą instalację i używanie wielu gier i oprogramowania</pl>
   <pt_BR>Instalar programas do Windows em sistemas Linux</pt_BR>
   <pt>Instalar programas do Windows em sistemas Linux</pt>
   <ro>Play on Linux</ro>
   <ru>Надстройка для запуска игр в окружении Wine</ru>
   <sk>Play on Linux</sk>
   <sl>Igraj v Linuxu</sl>
   <sq>Play on Linux</sq>
   <sr>Play on Linux</sr>
   <sv>Play on Linux</sv>
   <tr>Play on Linux</tr>
   <uk>Play on Linux</uk>
   <vi>Play on Linux</vi>
   <zh_CN>Play on Linux</zh_CN>
   <zh_TW>Play on Linux</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/15062/simage/large-ce0adddba47b1796d24f40baaad3daa5.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
wine-staging
winehq-staging
playonlinux
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
playonlinux
</uninstall_package_names>
</app>
