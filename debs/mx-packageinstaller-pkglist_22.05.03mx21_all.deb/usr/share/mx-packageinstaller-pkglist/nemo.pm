<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
FileManagers
</category>

<name>
Nemo
</name>

<description>
   <am>default file manager from the cinnamon desktop</am>
   <ar>default file manager from the cinnamon desktop</ar>
   <bg>default file manager from the cinnamon desktop</bg>
   <bn>default file manager from the cinnamon desktop</bn>
   <ca>default file manager from the cinnamon desktop</ca>
   <cs>default file manager from the cinnamon desktop</cs>
   <da>default file manager from the cinnamon desktop</da>
   <de>default file manager from the cinnamon desktop</de>
   <el>default file manager from the cinnamon desktop</el>
   <en>default file manager from the cinnamon desktop</en>
   <es>default file manager from the cinnamon desktop</es>
   <et>default file manager from the cinnamon desktop</et>
   <eu>default file manager from the cinnamon desktop</eu>
   <fa>default file manager from the cinnamon desktop</fa>
   <fil_PH>default file manager from the cinnamon desktop</fil_PH>
   <fi>default file manager from the cinnamon desktop</fi>
   <fr>default file manager from the cinnamon desktop</fr>
   <he_IL>default file manager from the cinnamon desktop</he_IL>
   <hi>default file manager from the cinnamon desktop</hi>
   <hr>default file manager from the cinnamon desktop</hr>
   <hu>default file manager from the cinnamon desktop</hu>
   <id>default file manager from the cinnamon desktop</id>
   <is>default file manager from the cinnamon desktop</is>
   <it>default file manager from the cinnamon desktop</it>
   <ja_JP>default file manager from the cinnamon desktop</ja_JP>
   <ja>default file manager from the cinnamon desktop</ja>
   <kk>default file manager from the cinnamon desktop</kk>
   <ko>default file manager from the cinnamon desktop</ko>
   <lt>default file manager from the cinnamon desktop</lt>
   <mk>default file manager from the cinnamon desktop</mk>
   <mr>default file manager from the cinnamon desktop</mr>
   <nb>default file manager from the cinnamon desktop</nb>
   <nl>default file manager from the cinnamon desktop</nl>
   <pl>default file manager from the cinnamon desktop</pl>
   <pt_BR>default file manager from the cinnamon desktop</pt_BR>
   <pt>default file manager from the cinnamon desktop</pt>
   <ro>default file manager from the cinnamon desktop</ro>
   <ru>default file manager from the cinnamon desktop</ru>
   <sk>default file manager from the cinnamon desktop</sk>
   <sl>default file manager from the cinnamon desktop</sl>
   <sq>default file manager from the cinnamon desktop</sq>
   <sr>default file manager from the cinnamon desktop</sr>
   <sv>default file manager from the cinnamon desktop</sv>
   <tr>default file manager from the cinnamon desktop</tr>
   <uk>default file manager from the cinnamon desktop</uk>
   <vi>default file manager from the cinnamon desktop</vi>
   <zh_CN>default file manager from the cinnamon desktop</zh_CN>
   <zh_TW>default file manager from the cinnamon desktop</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/10645/simage/large-bb41e0eb935574d89e6e935052e50201.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
nemo
nemo-fileroller
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
nemo
nemo-fileroller
</uninstall_package_names>
</app>
