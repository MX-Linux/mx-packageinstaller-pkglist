<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Email
</category>

<name>
Evolution
</name>

<description>
   <am>groupware suite with mail client and organizer</am>
   <ar>groupware suite with mail client and organizer</ar>
   <bg>groupware suite with mail client and organizer</bg>
   <bn>groupware suite with mail client and organizer</bn>
   <ca>groupware suite with mail client and organizer</ca>
   <cs>groupware suite with mail client and organizer</cs>
   <da>groupware suite with mail client and organizer</da>
   <de>groupware suite with mail client and organizer</de>
   <el>groupware suite with mail client and organizer</el>
   <en>groupware suite with mail client and organizer</en>
   <es>groupware suite with mail client and organizer</es>
   <et>groupware suite with mail client and organizer</et>
   <eu>groupware suite with mail client and organizer</eu>
   <fa>groupware suite with mail client and organizer</fa>
   <fil_PH>groupware suite with mail client and organizer</fil_PH>
   <fi>groupware suite with mail client and organizer</fi>
   <fr>groupware suite with mail client and organizer</fr>
   <he_IL>groupware suite with mail client and organizer</he_IL>
   <hi>groupware suite with mail client and organizer</hi>
   <hr>groupware suite with mail client and organizer</hr>
   <hu>groupware suite with mail client and organizer</hu>
   <id>groupware suite with mail client and organizer</id>
   <is>groupware suite with mail client and organizer</is>
   <it>groupware suite with mail client and organizer</it>
   <ja>groupware suite with mail client and organizer</ja>
   <kk>groupware suite with mail client and organizer</kk>
   <ko>groupware suite with mail client and organizer</ko>
   <lt>groupware suite with mail client and organizer</lt>
   <mk>groupware suite with mail client and organizer</mk>
   <mr>groupware suite with mail client and organizer</mr>
   <nb>groupware suite with mail client and organizer</nb>
   <nl>groupware suite with mail client and organizer</nl>
   <pl>groupware suite with mail client and organizer</pl>
   <pt_BR>groupware suite with mail client and organizer</pt_BR>
   <pt>groupware suite with mail client and organizer</pt>
   <ro>groupware suite with mail client and organizer</ro>
   <ru>groupware suite with mail client and organizer</ru>
   <sk>groupware suite with mail client and organizer</sk>
   <sl>groupware suite with mail client and organizer</sl>
   <sq>groupware suite with mail client and organizer</sq>
   <sr>groupware suite with mail client and organizer</sr>
   <sv>groupware suite with mail client and organizer</sv>
   <tr>groupware suite with mail client and organizer</tr>
   <uk>groupware suite with mail client and organizer</uk>
   <vi>groupware suite with mail client and organizer</vi>
   <zh_CN>groupware suite with mail client and organizer</zh_CN>
   <zh_TW>groupware suite with mail client and organizer</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/9432/simage/large-1fa2c4d65469a2a7de0823f3c7306c1c.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
evolution
evolution-plugins
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
evolution
evolution-plugins
</uninstall_package_names>
</app>
