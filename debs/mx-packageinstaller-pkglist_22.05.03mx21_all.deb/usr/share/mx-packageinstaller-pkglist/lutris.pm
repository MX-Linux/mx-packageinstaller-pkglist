<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Games
</category>

<name>
Lutris
</name>

<description>
   <am>Game Installer Wrapper Suite</am>
   <ar>Game Installer Wrapper Suite</ar>
   <bg>Game Installer Wrapper Suite</bg>
   <bn>Game Installer Wrapper Suite</bn>
   <ca>Game Installer Wrapper Suite</ca>
   <cs>Game Installer Wrapper Suite</cs>
   <da>Game Installer Wrapper Suite</da>
   <de>Game Installer Wrapper Suite</de>
   <el>Game Installer Wrapper Suite</el>
   <en>Game Installer Wrapper Suite</en>
   <es>Game Installer Wrapper Suite</es>
   <et>Game Installer Wrapper Suite</et>
   <eu>Game Installer Wrapper Suite</eu>
   <fa>Game Installer Wrapper Suite</fa>
   <fil_PH>Game Installer Wrapper Suite</fil_PH>
   <fi>Game Installer Wrapper Suite</fi>
   <fr>Game Installer Wrapper Suite</fr>
   <he_IL>Game Installer Wrapper Suite</he_IL>
   <hi>Game Installer Wrapper Suite</hi>
   <hr>Game Installer Wrapper Suite</hr>
   <hu>Game Installer Wrapper Suite</hu>
   <id>Game Installer Wrapper Suite</id>
   <is>Game Installer Wrapper Suite</is>
   <it>Game Installer Wrapper Suite</it>
   <ja_JP>Game Installer Wrapper Suite</ja_JP>
   <ja>Game Installer Wrapper Suite</ja>
   <kk>Game Installer Wrapper Suite</kk>
   <ko>Game Installer Wrapper Suite</ko>
   <lt>Game Installer Wrapper Suite</lt>
   <mk>Game Installer Wrapper Suite</mk>
   <mr>Game Installer Wrapper Suite</mr>
   <nb>Game Installer Wrapper Suite</nb>
   <nl>Game Installer Wrapper Suite</nl>
   <pl>Game Installer Wrapper Suite</pl>
   <pt_BR>Game Installer Wrapper Suite</pt_BR>
   <pt>Game Installer Wrapper Suite</pt>
   <ro>Game Installer Wrapper Suite</ro>
   <ru>Game Installer Wrapper Suite</ru>
   <sk>Game Installer Wrapper Suite</sk>
   <sl>Game Installer Wrapper Suite</sl>
   <sq>Game Installer Wrapper Suite</sq>
   <sr>Game Installer Wrapper Suite</sr>
   <sv>Game Installer Wrapper Suite</sv>
   <tr>Game Installer Wrapper Suite</tr>
   <uk>Game Installer Wrapper Suite</uk>
   <vi>Game Installer Wrapper Suite</vi>
   <zh_CN>Game Installer Wrapper Suite</zh_CN>
   <zh_TW>Game Installer Wrapper Suite</zh_TW>
</description>

<installable>
32,64
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/19728/simage/large-0d5cb97b12386e46b5766f169776ddd6.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
lutris
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
lutris
</uninstall_package_names>
</app>
