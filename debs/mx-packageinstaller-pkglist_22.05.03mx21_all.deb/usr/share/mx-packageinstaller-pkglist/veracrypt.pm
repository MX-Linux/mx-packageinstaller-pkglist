<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Utility
</category>

<name>
Veracrypt
</name>

<description>
Veracrypt
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
veracrypt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
veracrypt
</uninstall_package_names>
</app>
