<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Graphics
</category>

<name>
Krita
</name>

<description>
   <am>Krita is a creative application for raster images</am>
   <ar>Krita is a creative application for raster images</ar>
   <bg>Krita is a creative application for raster images</bg>
   <bn>Krita is a creative application for raster images</bn>
   <ca>Krita is a creative application for raster images</ca>
   <cs>Krita is a creative application for raster images</cs>
   <da>Krita is a creative application for raster images</da>
   <de>Krita is a creative application for raster images</de>
   <el>Krita is a creative application for raster images</el>
   <en>Krita is a creative application for raster images</en>
   <es>Krita is a creative application for raster images</es>
   <et>Krita is a creative application for raster images</et>
   <eu>Krita is a creative application for raster images</eu>
   <fa>Krita is a creative application for raster images</fa>
   <fil_PH>Krita is a creative application for raster images</fil_PH>
   <fi>Krita is a creative application for raster images</fi>
   <fr>Krita is a creative application for raster images</fr>
   <he_IL>Krita is a creative application for raster images</he_IL>
   <hi>Krita is a creative application for raster images</hi>
   <hr>Krita is a creative application for raster images</hr>
   <hu>Krita is a creative application for raster images</hu>
   <id>Krita is a creative application for raster images</id>
   <is>Krita is a creative application for raster images</is>
   <it>Krita is a creative application for raster images</it>
   <ja_JP>Krita is a creative application for raster images</ja_JP>
   <ja>Krita is a creative application for raster images</ja>
   <kk>Krita is a creative application for raster images</kk>
   <ko>Krita is a creative application for raster images</ko>
   <lt>Krita is a creative application for raster images</lt>
   <mk>Krita is a creative application for raster images</mk>
   <mr>Krita is a creative application for raster images</mr>
   <nb>Krita is a creative application for raster images</nb>
   <nl>Krita is a creative application for raster images</nl>
   <pl>Krita is a creative application for raster images</pl>
   <pt_BR>Krita is a creative application for raster images</pt_BR>
   <pt>Krita is a creative application for raster images</pt>
   <ro>Krita is a creative application for raster images</ro>
   <ru>Krita is a creative application for raster images</ru>
   <sk>Krita is a creative application for raster images</sk>
   <sl>Krita is a creative application for raster images</sl>
   <sq>Krita is a creative application for raster images</sq>
   <sr>Krita is a creative application for raster images</sr>
   <sv>Krita is a creative application for raster images</sv>
   <tr>Krita is a creative application for raster images</tr>
   <uk>Krita is a creative application for raster images</uk>
   <vi>Krita is a creative application for raster images</vi>
   <zh_CN>Krita is a creative application for raster images</zh_CN>
   <zh_TW>Krita is a creative application for raster images</zh_TW>
</description>

<installable>
32,64
</installable>

<screenshot>https://screenshots.debian.net/shrine/screenshot/17088/simage/large-c659c2cd481e3a889007e93872d7d990.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
krita 
krita-gmic 
krita-data 
krita-l10n 
python3-sip
python3-pyqt5
qml-module-qtmultimedia
</install_package_names>
<postinstall>

</postinstall>


<uninstall_package_names>
krita
krita-l10n
krita-gmic
krita-data
</uninstall_package_names>
</app>
