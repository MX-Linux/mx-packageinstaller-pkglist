<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Wallpapers
</category>

<name>
MX 16 Wallpapers
</name>

<description>
   <am>backgrounds originally supplied with MX 16</am>
   <ar>backgrounds originally supplied with MX 16</ar>
   <bg>backgrounds originally supplied with MX 16</bg>
   <bn>backgrounds originally supplied with MX 16</bn>
   <ca>Fons de pantalla subministrats d'origen amb MX16</ca>
   <cs>backgrounds originally supplied with MX 16</cs>
   <da>baggrunde fra MX 16</da>
   <de>Bildschirmhintergründe, die ursprünglich mit MX 16 geliefert wurden</de>
   <el>επιφάνεια εργασίας που παρέχεται αρχικά με MX 16</el>
   <en>backgrounds originally supplied with MX 16</en>
   <es>Fondos de escritorio originalmente suministrados con MX 16</es>
   <et>backgrounds originally supplied with MX 16</et>
   <eu>backgrounds originally supplied with MX 16</eu>
   <fa>backgrounds originally supplied with MX 16</fa>
   <fil_PH>backgrounds originally supplied with MX 16</fil_PH>
   <fi>backgrounds originally supplied with MX 16</fi>
   <fr>Fonds d'écran MX 16</fr>
   <he_IL>backgrounds originally supplied with MX 16</he_IL>
   <hi>backgrounds originally supplied with MX 16</hi>
   <hr>backgrounds originally supplied with MX 16</hr>
   <hu>backgrounds originally supplied with MX 16</hu>
   <id>backgrounds originally supplied with MX 16</id>
   <is>backgrounds originally supplied with MX 16</is>
   <it>sfondi originariamente forniti con MX 16</it>
   <ja_JP>backgrounds originally supplied with MX 16</ja_JP>
   <ja>backgrounds originally supplied with MX 16</ja>
   <kk>backgrounds originally supplied with MX 16</kk>
   <ko>backgrounds originally supplied with MX 16</ko>
   <lt>backgrounds originally supplied with MX 16</lt>
   <mk>backgrounds originally supplied with MX 16</mk>
   <mr>backgrounds originally supplied with MX 16</mr>
   <nb>backgrounds originally supplied with MX 16</nb>
   <nl>achtergronden oorspronkelijk geleverd met MX 16</nl>
   <pl>tła oryginalnie dostarczone z MX 16</pl>
   <pt_BR>Imagens de fundo originalmente incluídas no MX 16</pt_BR>
   <pt>Imagens de fundo originalmente incluídas no MX 16</pt>
   <ro>backgrounds originally supplied with MX 16</ro>
   <ru>Обои использованные для дистрибутива MX 16</ru>
   <sk>backgrounds originally supplied with MX 16</sk>
   <sl>Izvirna ozadja za MX 16</sl>
   <sq>backgrounds originally supplied with MX 16</sq>
   <sr>backgrounds originally supplied with MX 16</sr>
   <sv>wallpapers ursprungligen medföljande MX 16</sv>
   <tr>backgrounds originally supplied with MX 16</tr>
   <uk>оригінальні шпалери для MX 16</uk>
   <vi>backgrounds originally supplied with MX 16</vi>
   <zh_CN>backgrounds originally supplied with MX 16</zh_CN>
   <zh_TW>backgrounds originally supplied with MX 16</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mx16-artwork
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mx16-artwork
</uninstall_package_names>
</app>
