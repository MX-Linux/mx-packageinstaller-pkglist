<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
FileManagers
</category>

<name>
Sunflower
</name>

<description>
   <am> Small and highly customizable twin-panel file manager</am>
   <ar> Small and highly customizable twin-panel file manager</ar>
   <bg> Small and highly customizable twin-panel file manager</bg>
   <bn> Small and highly customizable twin-panel file manager</bn>
   <ca> Small and highly customizable twin-panel file manager</ca>
   <cs> Small and highly customizable twin-panel file manager</cs>
   <da> Small and highly customizable twin-panel file manager</da>
   <de> Small and highly customizable twin-panel file manager</de>
   <el> Small and highly customizable twin-panel file manager</el>
   <en> Small and highly customizable twin-panel file manager</en>
   <es> Small and highly customizable twin-panel file manager</es>
   <et> Small and highly customizable twin-panel file manager</et>
   <eu> Small and highly customizable twin-panel file manager</eu>
   <fa> Small and highly customizable twin-panel file manager</fa>
   <fil_PH> Small and highly customizable twin-panel file manager</fil_PH>
   <fi> Small and highly customizable twin-panel file manager</fi>
   <fr> Small and highly customizable twin-panel file manager</fr>
   <he_IL> Small and highly customizable twin-panel file manager</he_IL>
   <hi> Small and highly customizable twin-panel file manager</hi>
   <hr> Small and highly customizable twin-panel file manager</hr>
   <hu> Small and highly customizable twin-panel file manager</hu>
   <id> Small and highly customizable twin-panel file manager</id>
   <is> Small and highly customizable twin-panel file manager</is>
   <it> Small and highly customizable twin-panel file manager</it>
   <ja_JP> Small and highly customizable twin-panel file manager</ja_JP>
   <ja> Small and highly customizable twin-panel file manager</ja>
   <kk> Small and highly customizable twin-panel file manager</kk>
   <ko> Small and highly customizable twin-panel file manager</ko>
   <lt> Small and highly customizable twin-panel file manager</lt>
   <mk> Small and highly customizable twin-panel file manager</mk>
   <mr> Small and highly customizable twin-panel file manager</mr>
   <nb> Small and highly customizable twin-panel file manager</nb>
   <nl> Small and highly customizable twin-panel file manager</nl>
   <pl> Small and highly customizable twin-panel file manager</pl>
   <pt_BR> Small and highly customizable twin-panel file manager</pt_BR>
   <pt> Small and highly customizable twin-panel file manager</pt>
   <ro> Small and highly customizable twin-panel file manager</ro>
   <ru> Small and highly customizable twin-panel file manager</ru>
   <sk> Small and highly customizable twin-panel file manager</sk>
   <sl> Small and highly customizable twin-panel file manager</sl>
   <sq> Small and highly customizable twin-panel file manager</sq>
   <sr> Small and highly customizable twin-panel file manager</sr>
   <sv> Small and highly customizable twin-panel file manager</sv>
   <tr> Small and highly customizable twin-panel file manager</tr>
   <uk> Small and highly customizable twin-panel file manager</uk>
   <vi> Small and highly customizable twin-panel file manager</vi>
   <zh_CN> Small and highly customizable twin-panel file manager</zh_CN>
   <zh_TW> Small and highly customizable twin-panel file manager</zh_TW>
</description>

<installable>
32,64
</installable>

<screenshot>https://sunflower-fm.org/site/gallery/images/5f9b38108c926a6730000f57c81372a8.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
sunflower
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
sunflower
</uninstall_package_names>
</app>
