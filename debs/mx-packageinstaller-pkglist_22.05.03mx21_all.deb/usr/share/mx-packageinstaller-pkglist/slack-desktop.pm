<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Messaging
</category>

<name>
Slack Desktop Client
</name>

<description>
   <am>Slack Desktop Client</am>
   <ar>Slack Desktop Client</ar>
   <bg>Slack Desktop Client</bg>
   <bn>Slack Desktop Client</bn>
   <ca>Slack Desktop Client</ca>
   <cs>Slack Desktop Client</cs>
   <da>Slack Desktop Client</da>
   <de>Slack Desktop Client</de>
   <el>Slack Desktop Client</el>
   <en>Slack Desktop Client</en>
   <es>Slack Desktop Client</es>
   <et>Slack Desktop Client</et>
   <eu>Slack Desktop Client</eu>
   <fa>Slack Desktop Client</fa>
   <fil_PH>Slack Desktop Client</fil_PH>
   <fi>Slack Desktop Client</fi>
   <fr>Slack Desktop Client</fr>
   <he_IL>Slack Desktop Client</he_IL>
   <hi>Slack Desktop Client</hi>
   <hr>Slack Desktop Client</hr>
   <hu>Slack Desktop Client</hu>
   <id>Slack Desktop Client</id>
   <is>Slack Desktop Client</is>
   <it>Slack Desktop Client</it>
   <ja_JP>Slack Desktop Client</ja_JP>
   <ja>Slack Desktop Client</ja>
   <kk>Slack Desktop Client</kk>
   <ko>Slack Desktop Client</ko>
   <lt>Slack Desktop Client</lt>
   <mk>Slack Desktop Client</mk>
   <mr>Slack Desktop Client</mr>
   <nb>Slack Desktop Client</nb>
   <nl>Slack Desktop Client</nl>
   <pl>Slack Desktop Client</pl>
   <pt_BR>Slack Desktop Client</pt_BR>
   <pt>Slack Desktop Client</pt>
   <ro>Slack Desktop Client</ro>
   <ru>Slack Desktop Client</ru>
   <sk>Slack Desktop Client</sk>
   <sl>Slack Desktop Client</sl>
   <sq>Slack Desktop Client</sq>
   <sr>Slack Desktop Client</sr>
   <sv>Slack Desktop Client</sv>
   <tr>Slack Desktop Client</tr>
   <uk>Slack Desktop Client</uk>
   <vi>Slack Desktop Client</vi>
   <zh_CN>Slack Desktop Client</zh_CN>
   <zh_TW>Slack Desktop Client</zh_TW>
</description>

<installable>
64
</installable>

<screenshot></screenshot>

<preinstall>
/usr/share/mx-packageinstaller-pkglist/get-slack.sh
</preinstall>

<install_package_names>

</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
slack-desktop
</uninstall_package_names>

<postuninstall>

</postuninstall>
</app>
