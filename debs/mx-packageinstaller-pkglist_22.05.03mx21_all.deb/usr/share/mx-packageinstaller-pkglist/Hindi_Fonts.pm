<?xml version="1.0" encoding="UTF-8"?>
<app>

<category>
Language
</category>

<name>
Hindi Fonts फोंट नहीं
</name>

<description>
   <am>Hindi fonts</am>
   <ar>Hindi fonts</ar>
   <bg>Hindi fonts</bg>
   <bn>Hindi fonts</bn>
   <ca>Hindi fonts</ca>
   <cs>Hindi fonts</cs>
   <da>Hindi fonts</da>
   <de>Hindi fonts</de>
   <el>Hindi fonts</el>
   <en>Hindi fonts</en>
   <es>Hindi fonts</es>
   <et>Hindi fonts</et>
   <eu>Hindi fonts</eu>
   <fa>Hindi fonts</fa>
   <fil_PH>Hindi fonts</fil_PH>
   <fi>Hindi fonts</fi>
   <fr>Hindi fonts</fr>
   <he_IL>Hindi fonts</he_IL>
   <hi>फोंट नहीं</hi>
   <hr>Hindi fonts</hr>
   <hu>Hindi fonts</hu>
   <id>Hindi fonts</id>
   <is>Hindi fonts</is>
   <it>Hindi fonts</it>
   <ja_JP>Hindi fonts</ja_JP>
   <ja>Hindi fonts</ja>
   <kk>Hindi fonts</kk>
   <ko>Hindi fonts</ko>
   <lt>Hindi fonts</lt>
   <mk>Hindi fonts</mk>
   <mr>Hindi fonts</mr>
   <nb>Hindi fonts</nb>
   <nl>Hindi fonts</nl>
   <pl>Hindi fonts</pl>
   <pt_BR>Hindi fonts</pt_BR>
   <pt>Hindi fonts</pt>
   <ro>Hindi fonts</ro>
   <ru>Hindi fonts</ru>
   <sk>Hindi fonts</sk>
   <sl>Hindi fonts</sl>
   <sq>Hindi fonts</sq>
   <sr>Hindi fonts</sr>
   <sv>Hindi fonts</sv>
   <tr>Hindi fonts</tr>
   <uk>Hindi fonts</uk>
   <vi>Hindi fonts</vi>
   <zh_CN>Hindi fonts</zh_CN>
   <zh_TW>Hindi fonts</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>


<preinstall>

</preinstall>

<install_package_names>
fonts-indic
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
fonts-indic
</uninstall_package_names>
</app>
