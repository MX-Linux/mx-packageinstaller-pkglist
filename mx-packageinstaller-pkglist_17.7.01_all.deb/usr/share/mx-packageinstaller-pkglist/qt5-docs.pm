<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>  
QT5 Documention
</name>

<description>  
Documentation files for Qt-5 and QtCreator IDE
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qtcreator-doc
qt5-doc
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qt5-doc
qtcreator-doc
</uninstall_package_names>
</app>
