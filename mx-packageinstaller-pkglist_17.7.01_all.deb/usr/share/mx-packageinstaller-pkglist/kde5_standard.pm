<?xml version="1.0"?>
<app>

<category>
WindowManager
</category>

<name>  
WindowManager-kde5_standard
</name>

<description>  
KDE5-standard
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>
echo "---- in preprocessing ----"
echo "---- preprocessing done----"
</preinstall>

<install_package_names>
kde-standard
virtuoso-minimal
</install_package_names>

<postinstall>

</postinstall>

<uninstall_package_names>
kde-standard
virtuoso-minimal
</uninstall_package_names>

</app>
