<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>  
SuperTuxKart
</name>

<description>  
Mario kart style racing, run again for updates
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/727/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>

</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
supertuxkart
supertuxkart-data
</uninstall_package_names>
</app>