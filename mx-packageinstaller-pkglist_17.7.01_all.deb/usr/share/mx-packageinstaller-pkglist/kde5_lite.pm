<?xml version="1.0"?>
<app>

<category>
WindowManager
</category>

<name>  
WindowManager-kde5_lite
</name>

<description>  
KDE5-lite
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>
echo "---- in preprocessing ----"
echo "---- preprocessing done----"
</preinstall>

<install_package_names>
kde-plasma-desktop
</install_package_names>

<postinstall>

</postinstall>

<uninstall_package_names>
kde-plasma-desktop
</uninstall_package_names>

</app>
