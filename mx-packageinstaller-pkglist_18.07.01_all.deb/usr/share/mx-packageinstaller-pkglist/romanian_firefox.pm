<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Romanian_Firfox
</name>

<description>
   <am>Romanian localisation of Firefox</am>
   <ca>Localització de Firefox en Romanès</ca>
   <cs>Romanian localisation of Firefox</cs>
   <de>Rumänische Lokalisierung von Firefox</de>
   <el>Romanian localisation of Firefox</el>
   <en>Romanian localisation of Firefox</en>
   <es>Romanian localisation of Firefox</es>
   <fi>Romanian localisation of Firefox</fi>
   <fr>Romanian localisation of Firefox</fr>
   <hi>Romanian localisation of Firefox</hi>
   <hr>Romanian localisation of Firefox</hr>
   <hu>Romanian localisation of Firefox</hu>
   <it>Romanian localisation of Firefox</it>
   <ja>Romanian localisation of Firefox</ja>
   <kk>Romanian localisation of Firefox</kk>
   <lt>Romanian localisation of Firefox</lt>
   <nl>Romanian localisation of Firefox</nl>
   <pl>Romanian localisation of Firefox</pl>
   <pt_BR>Romanian localisation of Firefox</pt_BR>
   <pt>Romanian localisation of Firefox</pt>
   <ro>Romanian localisation of Firefox</ro>
   <ru>Romanian localisation of Firefox</ru>
   <sk>Romanian localisation of Firefox</sk>
   <sv>Rumänsk lokalisering av Firefox</sv>
   <tr>Romanian localisation of Firefox</tr>
   <uk>Romanian localisation of Firefox</uk>
   <zh_TW>Romanian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-ro
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-ro
</uninstall_package_names>
</app>
