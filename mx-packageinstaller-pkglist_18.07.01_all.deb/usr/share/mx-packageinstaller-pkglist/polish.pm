<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Polish
</name>

<description>
   <am>Polish Language Meta-Package</am>
   <ca>Polish Language Meta-Package</ca>
   <cs>Polish Language Meta-Package</cs>
   <de>Polnisches Sprach-Meta-Paket</de>
   <el>Polish Language Meta-Package</el>
   <en>Polish Language Meta-Package</en>
   <es>Polish Language Meta-Package</es>
   <fi>Polish Language Meta-Package</fi>
   <fr>Polish Language Meta-Package</fr>
   <hi>Polish Language Meta-Package</hi>
   <hr>Polish Language Meta-Package</hr>
   <hu>Polish Language Meta-Package</hu>
   <it>Polish Language Meta-Package</it>
   <ja>Polish Language Meta-Package</ja>
   <kk>Polish Language Meta-Package</kk>
   <lt>Polish Language Meta-Package</lt>
   <nl>Polish Language Meta-Package</nl>
   <pl>Polish Language Meta-Package</pl>
   <pt_BR>Polish Language Meta-Package</pt_BR>
   <pt>Polish Language Meta-Package</pt>
   <ro>Polish Language Meta-Package</ro>
   <ru>Polish Language Meta-Package</ru>
   <sk>Polish Language Meta-Package</sk>
   <sv>Polskt Språk-Meta-Paket</sv>
   <tr>Polish Language Meta-Package</tr>
   <uk>Polish Language Meta-Package</uk>
   <zh_TW>Polish Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-pl
manpages-pl
myspell-pl
ipolish
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-pl
manpages-pl
myspell-pl
ipolish
</uninstall_package_names>
</app>
