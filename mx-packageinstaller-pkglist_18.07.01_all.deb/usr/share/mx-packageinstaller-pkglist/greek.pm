<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Greek
</name>

<description>
   <am>Greek Language Meta-Package</am>
   <ca>Greek Language Meta-Package</ca>
   <cs>Greek Language Meta-Package</cs>
   <de>Griechisches Sprach-Meta-Paket</de>
   <el>Greek Language Meta-Package</el>
   <en>Greek Language Meta-Package</en>
   <es>Greek Language Meta-Package</es>
   <fi>Greek Language Meta-Package</fi>
   <fr>Greek Language Meta-Package</fr>
   <hi>Greek Language Meta-Package</hi>
   <hr>Greek Language Meta-Package</hr>
   <hu>Greek Language Meta-Package</hu>
   <it>Greek Language Meta-Package</it>
   <ja>Greek Language Meta-Package</ja>
   <kk>Greek Language Meta-Package</kk>
   <lt>Greek Language Meta-Package</lt>
   <nl>Greek Language Meta-Package</nl>
   <pl>Greek Language Meta-Package</pl>
   <pt_BR>Greek Language Meta-Package</pt_BR>
   <pt>Greek Language Meta-Package</pt>
   <ro>Greek Language Meta-Package</ro>
   <ru>Greek Language Meta-Package</ru>
   <sk>Greek Language Meta-Package</sk>
   <sv>Grekiskt Språk Meta-Paket</sv>
   <tr>Greek Language Meta-Package</tr>
   <uk>Greek Language Meta-Package</uk>
   <zh_TW>Greek Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-el
myspell-el-gr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-el
myspell-el-gr
</uninstall_package_names>
</app>
