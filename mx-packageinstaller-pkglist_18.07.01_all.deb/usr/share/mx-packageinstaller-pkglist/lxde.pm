<?xml version="1.0"?>
<app>

<category>
Desktop Environments
</category>

<name>
LXDE
</name>

<description>
   <am>basic install of LXDE</am>
   <ca>basic install of LXDE</ca>
   <cs>basic install of LXDE</cs>
   <de>Grundinstallation von LXDE</de>
   <el>basic install of LXDE</el>
   <en>basic install of LXDE</en>
   <es>basic install of LXDE</es>
   <fi>basic install of LXDE</fi>
   <fr>installation de base du bureau LXDE</fr>
   <hi>basic install of LXDE</hi>
   <hr>basic install of LXDE</hr>
   <hu>basic install of LXDE</hu>
   <it>basic install of LXDE</it>
   <ja>basic install of LXDE</ja>
   <kk>basic install of LXDE</kk>
   <lt>basic install of LXDE</lt>
   <nl>basic install of LXDE</nl>
   <pl>basic install of LXDE</pl>
   <pt_BR>basic install of LXDE</pt_BR>
   <pt>basic install of LXDE</pt>
   <ro>basic install of LXDE</ro>
   <ru>basic install of LXDE</ru>
   <sk>basic install of LXDE</sk>
   <sv>enkel installation av LXDE</sv>
   <tr>basic install of LXDE</tr>
   <uk>basic install of LXDE</uk>
   <zh_TW>basic install of LXDE</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/519/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
lxde
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
lxde
lxappearance-obconf
lxsession-edit
lxterminal
lxde-core
lxde-icon-theme
lxinput
lxrandr
lxlauncher
lxtask
update-notifier
lxmusic
lxpanel
</uninstall_package_names>
</app>
