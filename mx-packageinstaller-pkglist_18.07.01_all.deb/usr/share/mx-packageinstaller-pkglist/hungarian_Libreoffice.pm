<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Hungarian_Libreoffice
</name>

<description>
   <am>Hungarian LibreOffice Language Meta-Package</am>
   <ca>Hungarian LibreOffice Language Meta-Package</ca>
   <cs>Hungarian LibreOffice Language Meta-Package</cs>
   <de>Ungarisches LibreOffice Meta-Paket</de>
   <el>Hungarian LibreOffice Language Meta-Package</el>
   <en>Hungarian LibreOffice Language Meta-Package</en>
   <es>Hungarian LibreOffice Language Meta-Package</es>
   <fi>Hungarian LibreOffice Language Meta-Package</fi>
   <fr>Hungarian LibreOffice Language Meta-Package</fr>
   <hi>Hungarian LibreOffice Language Meta-Package</hi>
   <hr>Hungarian LibreOffice Language Meta-Package</hr>
   <hu>Hungarian LibreOffice Language Meta-Package</hu>
   <it>Hungarian LibreOffice Language Meta-Package</it>
   <ja>Hungarian LibreOffice Language Meta-Package</ja>
   <kk>Hungarian LibreOffice Language Meta-Package</kk>
   <lt>Hungarian LibreOffice Language Meta-Package</lt>
   <nl>Hungarian LibreOffice Language Meta-Package</nl>
   <pl>Hungarian LibreOffice Language Meta-Package</pl>
   <pt_BR>Hungarian LibreOffice Language Meta-Package</pt_BR>
   <pt>Hungarian LibreOffice Language Meta-Package</pt>
   <ro>Hungarian LibreOffice Language Meta-Package</ro>
   <ru>Hungarian LibreOffice Language Meta-Package</ru>
   <sk>Hungarian LibreOffice Language Meta-Package</sk>
   <sv>Ungerskt LibreOffice Språk Meta-Paket </sv>
   <tr>Hungarian LibreOffice Language Meta-Package</tr>
   <uk>Hungarian LibreOffice Language Meta-Package</uk>
   <zh_TW>Hungarian LibreOffice Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw
libreoffice-impress
libreoffice-math
libreoffice-writer
libreoffice-l10n-hu
libreoffice-help-hu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw
libreoffice-impress
libreoffice-math
libreoffice-writer
libreoffice-l10n-hu
libreoffice-help-hu
</uninstall_package_names>
</app>
