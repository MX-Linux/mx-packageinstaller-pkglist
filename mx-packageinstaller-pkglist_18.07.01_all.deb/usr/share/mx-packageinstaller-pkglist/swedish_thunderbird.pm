<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Swedish_Thunderbird
</name>

<description>
   <am>Swedish localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Suec</ca>
   <cs>Swedish localisation of Thunderbird</cs>
   <de>Schwedische Lokalisierung von Thunderbird</de>
   <el>Swedish localisation of Thunderbird</el>
   <en>Swedish localisation of Thunderbird</en>
   <es>Swedish localisation of Thunderbird</es>
   <fi>Swedish localisation of Thunderbird</fi>
   <fr>Swedish localisation of Thunderbird</fr>
   <hi>Swedish localisation of Thunderbird</hi>
   <hr>Swedish localisation of Thunderbird</hr>
   <hu>Swedish localisation of Thunderbird</hu>
   <it>Swedish localisation of Thunderbird</it>
   <ja>Swedish localisation of Thunderbird</ja>
   <kk>Swedish localisation of Thunderbird</kk>
   <lt>Swedish localisation of Thunderbird</lt>
   <nl>Swedish localisation of Thunderbird</nl>
   <pl>Swedish localisation of Thunderbird</pl>
   <pt_BR>Swedish localisation of Thunderbird</pt_BR>
   <pt>Swedish localisation of Thunderbird</pt>
   <ro>Swedish localisation of Thunderbird</ro>
   <ru>Swedish localisation of Thunderbird</ru>
   <sk>Swedish localisation of Thunderbird</sk>
   <sv>Svensk lokalisering av Thunderbird</sv>
   <tr>Swedish localisation of Thunderbird</tr>
   <uk>Swedish localisation of Thunderbird</uk>
   <zh_TW>Swedish localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-sv-se
lightning-l10n-sv-se
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-sv-se
lightning-l10n-sv-se
</uninstall_package_names>
</app>
