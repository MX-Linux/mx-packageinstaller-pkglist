<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
ImageMagick
</name>

<description>
   <am>a software suite to create, edit, and compose bitmap images</am>
   <ca>a software suite to create, edit, and compose bitmap images</ca>
   <cs>a software suite to create, edit, and compose bitmap images</cs>
   <de>Eine Software-Suite zum Erstellen, Bearbeiten und Komponieren von Bitmap-Bildern</de>
   <el>a software suite to create, edit, and compose bitmap images</el>
   <en>a software suite to create, edit, and compose bitmap images</en>
   <es>a software suite to create, edit, and compose bitmap images</es>
   <fi>a software suite to create, edit, and compose bitmap images</fi>
   <fr>a software suite to create, edit, and compose bitmap images</fr>
   <hi>a software suite to create, edit, and compose bitmap images</hi>
   <hr>a software suite to create, edit, and compose bitmap images</hr>
   <hu>a software suite to create, edit, and compose bitmap images</hu>
   <it>a software suite to create, edit, and compose bitmap images</it>
   <ja>a software suite to create, edit, and compose bitmap images</ja>
   <kk>a software suite to create, edit, and compose bitmap images</kk>
   <lt>a software suite to create, edit, and compose bitmap images</lt>
   <nl>a software suite to create, edit, and compose bitmap images</nl>
   <pl>a software suite to create, edit, and compose bitmap images</pl>
   <pt_BR>a software suite to create, edit, and compose bitmap images</pt_BR>
   <pt>a software suite to create, edit, and compose bitmap images</pt>
   <ro>a software suite to create, edit, and compose bitmap images</ro>
   <ru>a software suite to create, edit, and compose bitmap images</ru>
   <sk>a software suite to create, edit, and compose bitmap images</sk>
   <sv>en mjukvarusvit för att skapa, redigera, och komponera bitmapbilder</sv>
   <tr>a software suite to create, edit, and compose bitmap images</tr>
   <uk>a software suite to create, edit, and compose bitmap images</uk>
   <zh_TW>a software suite to create, edit, and compose bitmap images</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
imagemagick
imagemagick-doc
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
imagemagick
imagemagick-doc
</uninstall_package_names>
</app>
