<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Hungarian_Thunderbird
</name>

<description>
   <am>Hungarian localisation of Thunderbird</am>
   <ca>Hungarian localisation of Thunderbird</ca>
   <cs>Hungarian localisation of Thunderbird</cs>
   <de>Ungarische Lokalisierung von Thunderbird</de>
   <el>Hungarian localisation of Thunderbird</el>
   <en>Hungarian localisation of Thunderbird</en>
   <es>Hungarian localisation of Thunderbird</es>
   <fi>Hungarian localisation of Thunderbird</fi>
   <fr>Hungarian localisation of Thunderbird</fr>
   <hi>Hungarian localisation of Thunderbird</hi>
   <hr>Hungarian localisation of Thunderbird</hr>
   <hu>Hungarian localisation of Thunderbird</hu>
   <it>Hungarian localisation of Thunderbird</it>
   <ja>Hungarian localisation of Thunderbird</ja>
   <kk>Hungarian localisation of Thunderbird</kk>
   <lt>Hungarian localisation of Thunderbird</lt>
   <nl>Hungarian localisation of Thunderbird</nl>
   <pl>Hungarian localisation of Thunderbird</pl>
   <pt_BR>Hungarian localisation of Thunderbird</pt_BR>
   <pt>Hungarian localisation of Thunderbird</pt>
   <ro>Hungarian localisation of Thunderbird</ro>
   <ru>Hungarian localisation of Thunderbird</ru>
   <sk>Hungarian localisation of Thunderbird</sk>
   <sv>Ungersk lokalisering av Thunderbird</sv>
   <tr>Hungarian localisation of Thunderbird</tr>
   <uk>Hungarian localisation of Thunderbird</uk>
   <zh_TW>Hungarian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-hu
lightning-l10n-hu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-hu
lightning-l10n-hu
</uninstall_package_names>
</app>
