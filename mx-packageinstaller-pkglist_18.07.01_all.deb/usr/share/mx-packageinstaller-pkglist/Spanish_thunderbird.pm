<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Spanish_Thunderbird
</name>

<description>
   <am>Spanish localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Castellà</ca>
   <cs>Spanish localisation of Thunderbird</cs>
   <de>Spanische Lokalisierung von Thunderbird</de>
   <el>Spanish localisation of Thunderbird</el>
   <en>Spanish localisation of Thunderbird</en>
   <es>Spanish localisation of Thunderbird</es>
   <fi>Spanish localisation of Thunderbird</fi>
   <fr>Spanish localisation of Thunderbird</fr>
   <hi>Spanish localisation of Thunderbird</hi>
   <hr>Spanish localisation of Thunderbird</hr>
   <hu>Spanish localisation of Thunderbird</hu>
   <it>Spanish localisation of Thunderbird</it>
   <ja>Spanish localisation of Thunderbird</ja>
   <kk>Spanish localisation of Thunderbird</kk>
   <lt>Spanish localisation of Thunderbird</lt>
   <nl>Spanish localisation of Thunderbird</nl>
   <pl>Spanish localisation of Thunderbird</pl>
   <pt_BR>Spanish localisation of Thunderbird</pt_BR>
   <pt>Spanish localisation of Thunderbird</pt>
   <ro>Spanish localisation of Thunderbird</ro>
   <ru>Spanish localisation of Thunderbird</ru>
   <sk>Spanish localisation of Thunderbird</sk>
   <sv>Spansk lokalisering av Thunderbird </sv>
   <tr>Spanish localisation of Thunderbird</tr>
   <uk>Spanish localisation of Thunderbird</uk>
   <zh_TW>Spanish localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-es-es
lightning-l10n-es-es
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-es-es
lightning-l10n-es-es
</uninstall_package_names>
</app>
