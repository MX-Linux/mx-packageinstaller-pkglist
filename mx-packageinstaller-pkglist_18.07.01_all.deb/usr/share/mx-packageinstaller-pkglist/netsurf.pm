<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>
Netsurf
</name>

<description>
   <am>Latest Netsurf Browser</am>
   <ca>Latest Netsurf Browser</ca>
   <cs>Latest Netsurf Browser</cs>
   <de>Aktueller Netsurf-Browser</de>
   <el>Latest Netsurf Browser</el>
   <en>Latest Netsurf Browser</en>
   <es>Latest Netsurf Browser</es>
   <fi>Latest Netsurf Browser</fi>
   <fr>La dernière version du navigateur Netsurf</fr>
   <hi>Latest Netsurf Browser</hi>
   <hr>Latest Netsurf Browser</hr>
   <hu>Latest Netsurf Browser</hu>
   <it>Latest Netsurf Browser</it>
   <ja>Latest Netsurf Browser</ja>
   <kk>Latest Netsurf Browser</kk>
   <lt>Latest Netsurf Browser</lt>
   <nl>Latest Netsurf Browser</nl>
   <pl>Latest Netsurf Browser</pl>
   <pt_BR>Latest Netsurf Browser</pt_BR>
   <pt>Latest Netsurf Browser</pt>
   <ro>Latest Netsurf Browser</ro>
   <ru>Latest Netsurf Browser</ru>
   <sk>Latest Netsurf Browser</sk>
   <sv>Senaste Netsurf Webbläsare</sv>
   <tr>Latest Netsurf Browser</tr>
   <uk>Latest Netsurf Browser</uk>
   <zh_TW>Latest Netsurf Browser</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
netsurf
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
netsurf
</uninstall_package_names>
</app>
