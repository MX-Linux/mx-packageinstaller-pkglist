<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Belarusian_Thunderbird
</name>

<description>
   <am>Belarusian localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Belarus</ca>
   <cs>Belarusian localisation of Thunderbird</cs>
   <de>Weißrussische Lokalisierung von Thunderbird</de>
   <el>Belarusian localisation of Thunderbird</el>
   <en>Belarusian localisation of Thunderbird</en>
   <es>Belarusian localisation of Thunderbird</es>
   <fi>Belarusian localisation of Thunderbird</fi>
   <fr>Localisation biélorusse pour Thunderbird</fr>
   <hi>Belarusian localisation of Thunderbird</hi>
   <hr>Bjeloruska lokalizacija Thunderbirda</hr>
   <hu>Belarusian localisation of Thunderbird</hu>
   <it>Localizzazione bielorussa di Thunderbird</it>
   <ja>Belarusian localisation of Thunderbird</ja>
   <kk>Belarusian localisation of Thunderbird</kk>
   <lt>Belarusian localisation of Thunderbird</lt>
   <nl>Belarusian localisation of Thunderbird</nl>
   <pl>Belarusian localisation of Thunderbird</pl>
   <pt_BR>Belarusian localisation of Thunderbird</pt_BR>
   <pt>Belarusian localisation of Thunderbird</pt>
   <ro>Belarusian localisation of Thunderbird</ro>
   <ru>Belarusian localisation of Thunderbird</ru>
   <sk>Belarusian localisation of Thunderbird</sk>
   <sv>Belarus lokalisering av Thunderbird</sv>
   <tr>Belarusian localisation of Thunderbird</tr>
   <uk>Belarusian localisation of Thunderbird</uk>
   <zh_TW>Belarusian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-be
lightning-l10n-be
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-be
lightning-l10n-be
</uninstall_package_names>
</app>
