<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Lithuanian_Firefox
</name>

<description>
   <am>Lithuanian localisation of Firefox</am>
   <ca>Localització de Firefox en Lituà</ca>
   <cs>Lithuanian localisation of Firefox</cs>
   <de>Litauische Lokalisierung von Firefox</de>
   <el>Lithuanian localisation of Firefox</el>
   <en>Lithuanian localisation of Firefox</en>
   <es>Lithuanian localisation of Firefox</es>
   <fi>Lithuanian localisation of Firefox</fi>
   <fr>Lithuanian localisation of Firefox</fr>
   <hi>Lithuanian localisation of Firefox</hi>
   <hr>Lithuanian localisation of Firefox</hr>
   <hu>Lithuanian localisation of Firefox</hu>
   <it>Lithuanian localisation of Firefox</it>
   <ja>Lithuanian localisation of Firefox</ja>
   <kk>Lithuanian localisation of Firefox</kk>
   <lt>Lithuanian localisation of Firefox</lt>
   <nl>Lithuanian localisation of Firefox</nl>
   <pl>Lithuanian localisation of Firefox</pl>
   <pt_BR>Lithuanian localisation of Firefox</pt_BR>
   <pt>Lithuanian localisation of Firefox</pt>
   <ro>Lithuanian localisation of Firefox</ro>
   <ru>Lithuanian localisation of Firefox</ru>
   <sk>Lithuanian localisation of Firefox</sk>
   <sv>Litauisk lokalisering av Firefox</sv>
   <tr>Lithuanian localisation of Firefox</tr>
   <uk>Lithuanian localisation of Firefox</uk>
   <zh_TW>Lithuanian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-lt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-lt
</uninstall_package_names>
</app>
