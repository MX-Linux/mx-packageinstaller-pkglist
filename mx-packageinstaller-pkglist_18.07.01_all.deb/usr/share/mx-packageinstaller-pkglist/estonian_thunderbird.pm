<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Estonian_Thunderbird
</name>

<description>
   <am>Estonian localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Estonià</ca>
   <cs>Estonian localisation of Thunderbird</cs>
   <de>Estnische Lokalisierung von Thunderbird</de>
   <el>Estonian localisation of Thunderbird</el>
   <en>Estonian localisation of Thunderbird</en>
   <es>Estonian localisation of Thunderbird</es>
   <fi>Estonian localisation of Thunderbird</fi>
   <fr>Estonian localisation of Thunderbird</fr>
   <hi>Estonian localisation of Thunderbird</hi>
   <hr>Estonian localisation of Thunderbird</hr>
   <hu>Estonian localisation of Thunderbird</hu>
   <it>Estonian localisation of Thunderbird</it>
   <ja>Estonian localisation of Thunderbird</ja>
   <kk>Estonian localisation of Thunderbird</kk>
   <lt>Estonian localisation of Thunderbird</lt>
   <nl>Estonian localisation of Thunderbird</nl>
   <pl>Estonian localisation of Thunderbird</pl>
   <pt_BR>Estonian localisation of Thunderbird</pt_BR>
   <pt>Estonian localisation of Thunderbird</pt>
   <ro>Estonian localisation of Thunderbird</ro>
   <ru>Estonian localisation of Thunderbird</ru>
   <sk>Estonian localisation of Thunderbird</sk>
   <sv>Estnisk lokalisering av Thunderbird</sv>
   <tr>Estonian localisation of Thunderbird</tr>
   <uk>Estonian localisation of Thunderbird</uk>
   <zh_TW>Estonian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-et
lightning-l10n-et
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-et
lightning-l10n-et
</uninstall_package_names>
</app>
