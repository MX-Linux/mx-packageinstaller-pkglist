<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Portugese(PT)
</name>

<description>
   <am>Portugese(PT) Language Meta-Package</am>
   <ca>Meta-paquet de llengua per Portuguès (PT)</ca>
   <cs>Portugese(PT) Language Meta-Package</cs>
   <de>Portugiesisches (PT) Sprach-Meta-Paket</de>
   <el>Portugese(PT) Language Meta-Package</el>
   <en>Portugese(PT) Language Meta-Package</en>
   <es>Portugese(PT) Language Meta-Package</es>
   <fi>Portugese(PT) Language Meta-Package</fi>
   <fr>Portugese(PT) Language Meta-Package</fr>
   <hi>Portugese(PT) Language Meta-Package</hi>
   <hr>Portugese(PT) Language Meta-Package</hr>
   <hu>Portugese(PT) Language Meta-Package</hu>
   <it>Portugese(PT) Language Meta-Package</it>
   <ja>Portugese(PT) Language Meta-Package</ja>
   <kk>Portugese(PT) Language Meta-Package</kk>
   <lt>Portugese(PT) Language Meta-Package</lt>
   <nl>Portugese(PT) Language Meta-Package</nl>
   <pl>Portugese(PT) Language Meta-Package</pl>
   <pt_BR>Portugese(PT) Language Meta-Package</pt_BR>
   <pt>Portugese(PT) Language Meta-Package</pt>
   <ro>Portugese(PT) Language Meta-Package</ro>
   <ru>Portugese(PT) Language Meta-Package</ru>
   <sk>Portugese(PT) Language Meta-Package</sk>
   <sv>Portugisiskt(PT) Språk Meta-Paket </sv>
   <tr>Portugese(PT) Language Meta-Package</tr>
   <uk>Portugese(PT) Language Meta-Package</uk>
   <zh_TW>Portugese(PT) Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-pt-pt
myspell-pt-pt
manpages-pt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-pt-pt
myspell-pt-pt
manpages-pt
</uninstall_package_names>
</app>
