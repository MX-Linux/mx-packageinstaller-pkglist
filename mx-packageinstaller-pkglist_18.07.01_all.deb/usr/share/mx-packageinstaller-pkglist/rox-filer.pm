<?xml version="1.0"?>
<app>

<category>
FileManagers
</category>

<name>
ROXFiler
</name>

<description>
   <am>a fast and powerful graphical file manager</am>
   <ca>a fast and powerful graphical file manager</ca>
   <cs>a fast and powerful graphical file manager</cs>
   <de>Ein schneller und leistungsfähiger grafischer Dateimanager</de>
   <el>a fast and powerful graphical file manager</el>
   <en>a fast and powerful graphical file manager</en>
   <es>a fast and powerful graphical file manager</es>
   <fi>a fast and powerful graphical file manager</fi>
   <fr>a fast and powerful graphical file manager</fr>
   <hi>a fast and powerful graphical file manager</hi>
   <hr>a fast and powerful graphical file manager</hr>
   <hu>a fast and powerful graphical file manager</hu>
   <it>a fast and powerful graphical file manager</it>
   <ja>a fast and powerful graphical file manager</ja>
   <kk>a fast and powerful graphical file manager</kk>
   <lt>a fast and powerful graphical file manager</lt>
   <nl>a fast and powerful graphical file manager</nl>
   <pl>a fast and powerful graphical file manager</pl>
   <pt_BR>a fast and powerful graphical file manager</pt_BR>
   <pt>a fast and powerful graphical file manager</pt>
   <ro>a fast and powerful graphical file manager</ro>
   <ru>a fast and powerful graphical file manager</ru>
   <sk>a fast and powerful graphical file manager</sk>
   <sv>en snabb och kraftfull grafisk filhanterare</sv>
   <tr>a fast and powerful graphical file manager</tr>
   <uk>a fast and powerful graphical file manager</uk>
   <zh_TW>a fast and powerful graphical file manager</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/606/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
rox-filer
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
rox-filer
</uninstall_package_names>
</app>
