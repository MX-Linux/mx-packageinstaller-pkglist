<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
Shotwell
</name>

<description>
   <am>digital photo organizer</am>
   <ca>Organitzador de fotos digitals</ca>
   <cs>digital photo organizer</cs>
   <de>Digitaler Fotoveranstalter</de>
   <el>digital photo organizer</el>
   <en>digital photo organizer</en>
   <es>digital photo organizer</es>
   <fi>digital photo organizer</fi>
   <fr>digital photo organizer</fr>
   <hi>digital photo organizer</hi>
   <hr>digital photo organizer</hr>
   <hu>digital photo organizer</hu>
   <it>digital photo organizer</it>
   <ja>digital photo organizer</ja>
   <kk>digital photo organizer</kk>
   <lt>digital photo organizer</lt>
   <nl>digital photo organizer</nl>
   <pl>digital photo organizer</pl>
   <pt_BR>digital photo organizer</pt_BR>
   <pt>digital photo organizer</pt>
   <ro>digital photo organizer</ro>
   <ru>digital photo organizer</ru>
   <sk>digital photo organizer</sk>
   <sv>digital foto-organiserare</sv>
   <tr>digital photo organizer</tr>
   <uk>digital photo organizer</uk>
   <zh_TW>digital photo organizer</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/008/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
shotwell
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
shotwell
</uninstall_package_names>
</app>
