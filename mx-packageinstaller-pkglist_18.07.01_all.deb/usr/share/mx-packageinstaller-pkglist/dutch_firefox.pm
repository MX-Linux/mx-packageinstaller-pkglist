<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Dutch_Firefox
</name>

<description>
   <am>Dutch localisation of Firefox</am>
   <ca>Localització de Firefox en Holandès</ca>
   <cs>Dutch localisation of Firefox</cs>
   <de>Niederländische Lokalisierung von Firefox</de>
   <el>Dutch localisation of Firefox</el>
   <en>Dutch localisation of Firefox</en>
   <es>Dutch localisation of Firefox</es>
   <fi>Dutch localisation of Firefox</fi>
   <fr>Localisation néerlandaise pour Firefox</fr>
   <hi>Dutch localisation of Firefox</hi>
   <hr>Dutch localisation of Firefox</hr>
   <hu>Dutch localisation of Firefox</hu>
   <it>Localizzazione olandese di Firefox</it>
   <ja>Dutch localisation of Firefox</ja>
   <kk>Dutch localisation of Firefox</kk>
   <lt>Dutch localisation of Firefox</lt>
   <nl>Dutch localisation of Firefox</nl>
   <pl>Dutch localisation of Firefox</pl>
   <pt_BR>Dutch localisation of Firefox</pt_BR>
   <pt>Dutch localisation of Firefox</pt>
   <ro>Dutch localisation of Firefox</ro>
   <ru>Dutch localisation of Firefox</ru>
   <sk>Dutch localisation of Firefox</sk>
   <sv>Holländsk lokalisering av Firefox</sv>
   <tr>Dutch localisation of Firefox</tr>
   <uk>Dutch localisation of Firefox</uk>
   <zh_TW>Dutch localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-nl
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-nl
</uninstall_package_names>
</app>
