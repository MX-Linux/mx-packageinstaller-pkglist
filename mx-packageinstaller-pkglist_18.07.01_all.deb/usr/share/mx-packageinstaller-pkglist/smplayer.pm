<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>
SMplayer
</name>

<description>
   <am>themable gui frontend to MPlayer with other interesting features</am>
   <ca>themable gui frontend to MPlayer with other interesting features</ca>
   <cs>themable gui frontend to MPlayer with other interesting features</cs>
   <de>Themen-anpassbares GUI-Frontend zu MPlayer mit weiteren interessanten Funktionen</de>
   <el>themable gui frontend to MPlayer with other interesting features</el>
   <en>themable gui frontend to MPlayer with other interesting features</en>
   <es>themable gui frontend to MPlayer with other interesting features</es>
   <fi>themable gui frontend to MPlayer with other interesting features</fi>
   <fr>themable gui frontend to MPlayer with other interesting features</fr>
   <hi>themable gui frontend to MPlayer with other interesting features</hi>
   <hr>themable gui frontend to MPlayer with other interesting features</hr>
   <hu>themable gui frontend to MPlayer with other interesting features</hu>
   <it>themable gui frontend to MPlayer with other interesting features</it>
   <ja>themable gui frontend to MPlayer with other interesting features</ja>
   <kk>themable gui frontend to MPlayer with other interesting features</kk>
   <lt>themable gui frontend to MPlayer with other interesting features</lt>
   <nl>themable gui frontend to MPlayer with other interesting features</nl>
   <pl>themable gui frontend to MPlayer with other interesting features</pl>
   <pt_BR>themable gui frontend to MPlayer with other interesting features</pt_BR>
   <pt>themable gui frontend to MPlayer with other interesting features</pt>
   <ro>themable gui frontend to MPlayer with other interesting features</ro>
   <ru>themable gui frontend to MPlayer with other interesting features</ru>
   <sk>themable gui frontend to MPlayer with other interesting features</sk>
   <sv>temabar grafisk front-end till MPlayer med andra intressanta möjligheter</sv>
   <tr>themable gui frontend to MPlayer with other interesting features</tr>
   <uk>themable gui frontend to MPlayer with other interesting features</uk>
   <zh_TW>themable gui frontend to MPlayer with other interesting features</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/414/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
smplayer
smplayer-themes
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
smplayer
smplayer-themes
</uninstall_package_names>
</app>
