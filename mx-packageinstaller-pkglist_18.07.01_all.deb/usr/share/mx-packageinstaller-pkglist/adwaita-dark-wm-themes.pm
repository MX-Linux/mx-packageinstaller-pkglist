<?xml version="1.0"?>
<app>

<category>
Themes
</category>

<name>
Adwaita Dark WM Themes
</name>

<description>
   <am>Window Manager Themes to match the Obsidian-2 Gtk Theme</am>
   <ca>Temes de gestor de finestres per combinar amb el tema Obsidian-2</ca>
   <cs>Window Manager Themes to match the Obsidian-2 Gtk Theme</cs>
   <de>Window Manager Themen passend zum Obsidian-2 Gtk Thema</de>
   <el>Window Manager Themes to match the Obsidian-2 Gtk Theme</el>
   <en>Window Manager Themes to match the Obsidian-2 Gtk Theme</en>
   <es>Window Manager Themes to match the Obsidian-2 Gtk Theme</es>
   <fi>Window Manager Themes to match the Obsidian-2 Gtk Theme</fi>
   <fr>Window Manager Themes to match the Obsidian-2 Gtk Theme</fr>
   <hi>Window Manager Themes to match the Obsidian-2 Gtk Theme</hi>
   <hr>Window Manager Themes to match the Obsidian-2 Gtk Theme</hr>
   <hu>Window Manager Themes to match the Obsidian-2 Gtk Theme</hu>
   <it>Temi per Window Manager da associare al tema Gtk Obsidian-2</it>
   <ja>Window Manager Themes to match the Obsidian-2 Gtk Theme</ja>
   <kk>Window Manager Themes to match the Obsidian-2 Gtk Theme</kk>
   <lt>Window Manager Themes to match the Obsidian-2 Gtk Theme</lt>
   <nl>Window Manager Themes to match the Obsidian-2 Gtk Theme</nl>
   <pl>Window Manager Themes to match the Obsidian-2 Gtk Theme</pl>
   <pt_BR>Window Manager Themes to match the Obsidian-2 Gtk Theme</pt_BR>
   <pt>Window Manager Themes to match the Obsidian-2 Gtk Theme</pt>
   <ro>Window Manager Themes to match the Obsidian-2 Gtk Theme</ro>
   <ru>Window Manager Themes to match the Obsidian-2 Gtk Theme</ru>
   <sk>Window Manager Themes to match the Obsidian-2 Gtk Theme</sk>
   <sv>Fönsterhanterare-teman som matchar Obsidian-2 Gtk temat</sv>
   <tr>Window Manager Themes to match the Obsidian-2 Gtk Theme</tr>
   <uk>Window Manager Themes to match the Obsidian-2 Gtk Theme</uk>
   <zh_TW>Window Manager Themes to match the Obsidian-2 Gtk Theme</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
adwaita-dark-squared-xfce-wm-theme
adwaita-dark-xfce-wm-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
adwaita-dark-squared-xfce-wm-theme
adwaita-dark-xfce-wm-theme
</uninstall_package_names>
</app>
