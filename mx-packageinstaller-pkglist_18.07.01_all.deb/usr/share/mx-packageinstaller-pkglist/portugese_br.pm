<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Portugese(BR)
</name>

<description>
   <am>Portugese(BR) Language Meta-Package</am>
   <ca>Meta-paquet de llengua en Portuguès (BR)</ca>
   <cs>Portugese(BR) Language Meta-Package</cs>
   <de>Portugiesisches (BR) Sprach-Meta-Paket</de>
   <el>Portugese(BR) Language Meta-Package</el>
   <en>Portugese(BR) Language Meta-Package</en>
   <es>Portugese(BR) Language Meta-Package</es>
   <fi>Portugese(BR) Language Meta-Package</fi>
   <fr>Portugese(BR) Language Meta-Package</fr>
   <hi>Portugese(BR) Language Meta-Package</hi>
   <hr>Portugese(BR) Language Meta-Package</hr>
   <hu>Portugese(BR) Language Meta-Package</hu>
   <it>Portugese(BR) Language Meta-Package</it>
   <ja>Portugese(BR) Language Meta-Package</ja>
   <kk>Portugese(BR) Language Meta-Package</kk>
   <lt>Portugese(BR) Language Meta-Package</lt>
   <nl>Portugese(BR) Language Meta-Package</nl>
   <pl>Portugese(BR) Language Meta-Package</pl>
   <pt_BR>Portugese(BR) Language Meta-Package</pt_BR>
   <pt>Portugese(BR) Language Meta-Package</pt>
   <ro>Portugese(BR) Language Meta-Package</ro>
   <ru>Portugese(BR) Language Meta-Package</ru>
   <sk>Portugese(BR) Language Meta-Package</sk>
   <sv>Portugisiskt(BR) Språk Meta-Paket</sv>
   <tr>Portugese(BR) Language Meta-Package</tr>
   <uk>Portugese(BR) Language Meta-Package</uk>
   <zh_TW>Portugese(BR) Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-pt-br
myspell-pt-br
manpages-pt
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-pt-br
myspell-pt-br
manpages-pt
</uninstall_package_names>
</app>
