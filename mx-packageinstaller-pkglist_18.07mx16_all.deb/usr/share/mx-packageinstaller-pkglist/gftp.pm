<?xml version="1.0"?>
<app>

<category>
FTP
</category>

<name>  
gftp
</name>

<description>  
a multithreaded FTP client
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/705/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gftp-gtk
gftp-text
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gftp-gtk
gftp-text
</uninstall_package_names>
</app>