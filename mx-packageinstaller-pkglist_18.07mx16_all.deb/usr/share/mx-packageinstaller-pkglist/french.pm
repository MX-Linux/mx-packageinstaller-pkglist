<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
French
</name>

<description>  
French Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-fr
myspell-fr
manpages-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-fr
myspell-fr
manpages-fr
</uninstall_package_names>
</app>