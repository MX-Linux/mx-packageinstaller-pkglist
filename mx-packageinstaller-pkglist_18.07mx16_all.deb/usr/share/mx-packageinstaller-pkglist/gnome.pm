<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>  
Gnome 
</name>

<description>  
minimal install of gnome shell
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/010/781/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gdm3
gnome-session
gnome-control-center
gnome-themes
gnome-panel
gnome-shell-extensions
nautilus
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gdm3
gnome-session
gnome-control-center
gnome-themes
gnome-panel
gnome-shell-extensions
</uninstall_package_names>
</app>