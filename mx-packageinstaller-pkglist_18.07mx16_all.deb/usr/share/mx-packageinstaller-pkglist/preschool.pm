<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>  
Preschool
</name>

<description>  
Pre-School. Includes: gamine, gcompris and tuxpaint
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gamine
gcompris
gcompris-sound-en
tuxpaint
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gamine 
gcompris
gcompris-sound-en
tuxpaint
</uninstall_package_names>
</app>