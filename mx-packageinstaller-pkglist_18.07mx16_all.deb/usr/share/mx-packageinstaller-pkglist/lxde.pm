<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>  
LXDE
</name>

<description>  
basic install of LXDE
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/519/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
lxde
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
lxde
lxappearance-obconf
lxsession-edit
lxterminal
lxde-core
lxde-icon-theme
lxinput
lxrandr
lxlauncher
lxtask
update-notifier
lxmusic
lxpanel
</uninstall_package_names>
</app>