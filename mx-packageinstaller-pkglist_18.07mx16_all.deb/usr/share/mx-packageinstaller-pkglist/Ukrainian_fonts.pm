<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Ukrainian_Fonts
</name>

<description>  
Ukrainian fonts packages
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xfonts-cronyx-100dpi
	xfonts-cronyx-75dpi
	xfonts-cronyx-isocyr-100dpi
	xfonts-cronyx-isocyr-75dpi
	xfonts-cronyx-isocyr-misc
	xfonts-cronyx-koi8r-100dpi
	xfonts-cronyx-koi8r-75dpi
	xfonts-cronyx-koi8r-misc
	xfonts-cronyx-misc
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xfonts-cronyx-100dpi
	xfonts-cronyx-75dpi
	xfonts-cronyx-isocyr-100dpi
	xfonts-cronyx-isocyr-75dpi
	xfonts-cronyx-isocyr-misc
	xfonts-cronyx-koi8r-100dpi
	xfonts-cronyx-koi8r-75dpi
	xfonts-cronyx-koi8r-misc
	xfonts-cronyx-misc
</uninstall_package_names>
</app>