<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
GB_English_Firefox
</name>

<description>
   <am>GB English localisation of Firefox</am>
   <ca>Localització de Firefox en anglès (UK)</ca>
   <cs>GB English localisation of Firefox</cs>
   <de>Englische (GB) Lokalisierung von Firefox</de>
   <el>GB English localisation of Firefox</el>
   <en>GB English localisation of Firefox</en>
   <es>GB English localisation of Firefox</es>
   <fi>GB English localisation of Firefox</fi>
   <fr>GB English localisation of Firefox</fr>
   <hi>GB English localisation of Firefox</hi>
   <hr>GB English localisation of Firefox</hr>
   <hu>GB English localisation of Firefox</hu>
   <it>GB English localisation of Firefox</it>
   <ja>GB English localisation of Firefox</ja>
   <kk>GB English localisation of Firefox</kk>
   <lt>GB English localisation of Firefox</lt>
   <nl>GB English localisation of Firefox</nl>
   <pl>GB English localisation of Firefox</pl>
   <pt_BR>GB English localisation of Firefox</pt_BR>
   <pt>GB English localisation of Firefox</pt>
   <ro>GB English localisation of Firefox</ro>
   <ru>GB English localisation of Firefox</ru>
   <sk>GB English localisation of Firefox</sk>
   <sv>GB Engelsk lokalisering av Firefox</sv>
   <tr>GB English localisation of Firefox</tr>
   <uk>GB English localisation of Firefox</uk>
   <zh_TW>GB English localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-en-gb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-en-gb
</uninstall_package_names>
</app>
