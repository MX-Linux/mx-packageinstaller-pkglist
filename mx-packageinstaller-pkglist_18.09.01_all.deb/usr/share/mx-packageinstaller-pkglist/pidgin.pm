<?xml version="1.0"?>
<app>

<category>
Messaging
</category>

<name>
Pidgin
</name>

<description>
   <am>an easy to use and free chat client</am>
   <ca>an easy to use and free chat client</ca>
   <cs>an easy to use and free chat client</cs>
   <de>Ein einfach zu bedienender und kostenloser Chat-Client</de>
   <el>an easy to use and free chat client</el>
   <en>an easy to use and free chat client</en>
   <es>an easy to use and free chat client</es>
   <fi>an easy to use and free chat client</fi>
   <fr>an easy to use and free chat client</fr>
   <hi>an easy to use and free chat client</hi>
   <hr>an easy to use and free chat client</hr>
   <hu>an easy to use and free chat client</hu>
   <it>an easy to use and free chat client</it>
   <ja>an easy to use and free chat client</ja>
   <kk>an easy to use and free chat client</kk>
   <lt>an easy to use and free chat client</lt>
   <nl>an easy to use and free chat client</nl>
   <pl>an easy to use and free chat client</pl>
   <pt_BR>an easy to use and free chat client</pt_BR>
   <pt>an easy to use and free chat client</pt>
   <ro>an easy to use and free chat client</ro>
   <ru>an easy to use and free chat client</ru>
   <sk>an easy to use and free chat client</sk>
   <sv>en lättanvänd och fri chattklient</sv>
   <tr>an easy to use and free chat client</tr>
   <uk>an easy to use and free chat client</uk>
   <zh_TW>an easy to use and free chat client</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/009/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pidgin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pidgin
</uninstall_package_names>
</app>
