<?xml version="1.0"?>
<app>

<category>
Wallpapers
</category>

<name>
MX 15 Wallpapers
</name>

<description>
   <am>backgrounds originally supplied with MX 15</am>
   <ca>backgrounds originally supplied with MX 15</ca>
   <cs>backgrounds originally supplied with MX 15</cs>
   <de>Bildschirmhintergründe, die ursprünglich mit MX 15 geliefert wurden</de>
   <el>backgrounds originally supplied with MX 15</el>
   <en>backgrounds originally supplied with MX 15</en>
   <es>backgrounds originally supplied with MX 15</es>
   <fi>backgrounds originally supplied with MX 15</fi>
   <fr>Fonds d'écran MX 15</fr>
   <hi>backgrounds originally supplied with MX 15</hi>
   <hr>backgrounds originally supplied with MX 15</hr>
   <hu>backgrounds originally supplied with MX 15</hu>
   <it>backgrounds originally supplied with MX 15</it>
   <ja>backgrounds originally supplied with MX 15</ja>
   <kk>backgrounds originally supplied with MX 15</kk>
   <lt>backgrounds originally supplied with MX 15</lt>
   <nl>backgrounds originally supplied with MX 15</nl>
   <pl>backgrounds originally supplied with MX 15</pl>
   <pt_BR>backgrounds originally supplied with MX 15</pt_BR>
   <pt>backgrounds originally supplied with MX 15</pt>
   <ro>backgrounds originally supplied with MX 15</ro>
   <ru>backgrounds originally supplied with MX 15</ru>
   <sk>backgrounds originally supplied with MX 15</sk>
   <sv>wallpapers ursprungligen medföljande MX 15</sv>
   <tr>backgrounds originally supplied with MX 15</tr>
   <uk>backgrounds originally supplied with MX 15</uk>
   <zh_TW>backgrounds originally supplied with MX 15</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mx15-artwork
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mx15-artwork
</uninstall_package_names>
</app>
