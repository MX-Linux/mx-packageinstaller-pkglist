<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Albanian_Firefox
</name>

<description>
   <am>Albanian localisation of Firefox</am>
   <ca>Localització de Firefox en Albanès</ca>
   <cs>Albanian localisation of Firefox</cs>
   <de>Albanische Lokalisierung von Firefox</de>
   <el>Albanian localisation of Firefox</el>
   <en>Albanian localisation of Firefox</en>
   <es>Albanian localisation of Firefox</es>
   <fi>Albanian localisation of Firefox</fi>
   <fr>Localisation albanaise pour Firefox</fr>
   <hi>Albanian localisation of Firefox</hi>
   <hr>Albanska lokalizacija Firefoxa</hr>
   <hu>Albanian localisation of Firefox</hu>
   <it>Localizzazione albanese di Firefox</it>
   <ja>Albanian localisation of Firefox</ja>
   <kk>Albanian localisation of Firefox</kk>
   <lt>Albanian localisation of Firefox</lt>
   <nl>Albanese lokalisatie van Firefox</nl>
   <pl>Albanian localisation of Firefox</pl>
   <pt_BR>Albanian localisation of Firefox</pt_BR>
   <pt>Albanian localisation of Firefox</pt>
   <ro>Albanian localisation of Firefox</ro>
   <ru>Albanian localisation of Firefox</ru>
   <sk>Albanian localisation of Firefox</sk>
   <sv>Albansk lokalisering av Firefox</sv>
   <tr>Albanian localisation of Firefox</tr>
   <uk>Albanian localisation of Firefox</uk>
   <zh_TW>Albanian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sq
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sq
</uninstall_package_names>
</app>
