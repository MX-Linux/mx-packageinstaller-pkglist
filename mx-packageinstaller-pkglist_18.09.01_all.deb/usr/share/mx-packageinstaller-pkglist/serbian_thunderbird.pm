<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Serbian_Thunderbird
</name>

<description>
   <am>Serbian localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Serbi</ca>
   <cs>Serbian localisation of Thunderbird</cs>
   <de>Serbische Lokalisierung von Thunderbird</de>
   <el>Serbian localisation of Thunderbird</el>
   <en>Serbian localisation of Thunderbird</en>
   <es>Serbian localisation of Thunderbird</es>
   <fi>Serbian localisation of Thunderbird</fi>
   <fr>Serbian localisation of Thunderbird</fr>
   <hi>Serbian localisation of Thunderbird</hi>
   <hr>Serbian localisation of Thunderbird</hr>
   <hu>Serbian localisation of Thunderbird</hu>
   <it>Serbian localisation of Thunderbird</it>
   <ja>Serbian localisation of Thunderbird</ja>
   <kk>Serbian localisation of Thunderbird</kk>
   <lt>Serbian localisation of Thunderbird</lt>
   <nl>Serbian localisation of Thunderbird</nl>
   <pl>Serbian localisation of Thunderbird</pl>
   <pt_BR>Serbian localisation of Thunderbird</pt_BR>
   <pt>Serbian localisation of Thunderbird</pt>
   <ro>Serbian localisation of Thunderbird</ro>
   <ru>Serbian localisation of Thunderbird</ru>
   <sk>Serbian localisation of Thunderbird</sk>
   <sv>Serbisk lokalisering av Thunderbird </sv>
   <tr>Serbian localisation of Thunderbird</tr>
   <uk>Serbian localisation of Thunderbird</uk>
   <zh_TW>Serbian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-sr
lightning-l10n-sr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-sr
lightning-l10n-sr
</uninstall_package_names>
</app>
