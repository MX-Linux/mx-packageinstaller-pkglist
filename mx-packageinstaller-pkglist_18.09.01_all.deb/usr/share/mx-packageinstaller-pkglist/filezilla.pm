<?xml version="1.0"?>
<app>

<category>
FTP
</category>

<name>
Filezilla
</name>

<description>
   <am>a full-featured FTP client with an easy-to-use GUI</am>
   <ca>a full-featured FTP client with an easy-to-use GUI</ca>
   <cs>a full-featured FTP client with an easy-to-use GUI</cs>
   <de>Ein voll ausgestatter FTP-Client mit benutzerfreundliche Oberfläche</de>
   <el>a full-featured FTP client with an easy-to-use GUI</el>
   <en>a full-featured FTP client with an easy-to-use GUI</en>
   <es>a full-featured FTP client with an easy-to-use GUI</es>
   <fi>a full-featured FTP client with an easy-to-use GUI</fi>
   <fr>a full-featured FTP client with an easy-to-use GUI</fr>
   <hi>a full-featured FTP client with an easy-to-use GUI</hi>
   <hr>a full-featured FTP client with an easy-to-use GUI</hr>
   <hu>a full-featured FTP client with an easy-to-use GUI</hu>
   <it>a full-featured FTP client with an easy-to-use GUI</it>
   <ja>a full-featured FTP client with an easy-to-use GUI</ja>
   <kk>a full-featured FTP client with an easy-to-use GUI</kk>
   <lt>a full-featured FTP client with an easy-to-use GUI</lt>
   <nl>a full-featured FTP client with an easy-to-use GUI</nl>
   <pl>a full-featured FTP client with an easy-to-use GUI</pl>
   <pt_BR>a full-featured FTP client with an easy-to-use GUI</pt_BR>
   <pt>a full-featured FTP client with an easy-to-use GUI</pt>
   <ro>a full-featured FTP client with an easy-to-use GUI</ro>
   <ru>a full-featured FTP client with an easy-to-use GUI</ru>
   <sk>a full-featured FTP client with an easy-to-use GUI</sk>
   <sv>en fullutrustad FTP klient med lättanvänt grafiskt gränssnitt</sv>
   <tr>a full-featured FTP client with an easy-to-use GUI</tr>
   <uk>a full-featured FTP client with an easy-to-use GUI</uk>
   <zh_TW>a full-featured FTP client with an easy-to-use GUI</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/296/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
filezilla
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
filezilla
</uninstall_package_names>
</app>
