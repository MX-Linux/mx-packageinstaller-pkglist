<?xml version="1.0"?>
<app>

<category>
Misc
</category>

<name>
Java
</name>

<description>
   <am>Java 8- installs openjdk-8 and icedtea</am>
   <ca>Java 8- installs openjdk-8 and icedtea</ca>
   <cs>Java 8- installs openjdk-8 and icedtea</cs>
   <de>Java 8: Openjdk-8 und Icedtea wird installiert</de>
   <el>Java 8- installs openjdk-8 and icedtea</el>
   <en>Java 8- installs openjdk-8 and icedtea</en>
   <es>Java 8- installs openjdk-8 and icedtea</es>
   <fi>Java 8- installs openjdk-8 and icedtea</fi>
   <fr>Java 8- installation de openjdk-8 et icedtea</fr>
   <hi>Java 8- installs openjdk-8 and icedtea</hi>
   <hr>Java 8- installs openjdk-8 and icedtea</hr>
   <hu>Java 8- installs openjdk-8 and icedtea</hu>
   <it>Java 8- installs openjdk-8 and icedtea</it>
   <ja>Java 8- installs openjdk-8 and icedtea</ja>
   <kk>Java 8- installs openjdk-8 and icedtea</kk>
   <lt>Java 8- installs openjdk-8 and icedtea</lt>
   <nl>Java 8- installs openjdk-8 and icedtea</nl>
   <pl>Java 8- installs openjdk-8 and icedtea</pl>
   <pt_BR>Java 8- installs openjdk-8 and icedtea</pt_BR>
   <pt>Java 8- installs openjdk-8 and icedtea</pt>
   <ro>Java 8- installs openjdk-8 and icedtea</ro>
   <ru>Java 8- installs openjdk-8 and icedtea</ru>
   <sk>Java 8- installs openjdk-8 and icedtea</sk>
   <sv>Java 8- installerar openjdk-8 och icedtea</sv>
   <tr>Java 8- installs openjdk-8 and icedtea</tr>
   <uk>Java 8- installs openjdk-8 and icedtea</uk>
   <zh_TW>Java 8- installs openjdk-8 and icedtea</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
openjdk-8-jre
openjdk-8-jre-headless
icedtea-8-plugin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
openjdk-8-jre
openjdk-8-jre-headless
icedtea-8-plugin
</uninstall_package_names>
</app>
