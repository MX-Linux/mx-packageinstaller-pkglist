<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
Scribus
</name>

<description>
   <am>a desktop page layout program</am>
   <ca>Programa de disseny de pàgines d'escriptori</ca>
   <cs>a desktop page layout program</cs>
   <de>Ein Desktop-Seitenlayout-Programm</de>
   <el>a desktop page layout program</el>
   <en>a desktop page layout program</en>
   <es>a desktop page layout program</es>
   <fi>a desktop page layout program</fi>
   <fr>a desktop page layout program</fr>
   <hi>a desktop page layout program</hi>
   <hr>a desktop page layout program</hr>
   <hu>a desktop page layout program</hu>
   <it>a desktop page layout program</it>
   <ja>a desktop page layout program</ja>
   <kk>a desktop page layout program</kk>
   <lt>a desktop page layout program</lt>
   <nl>a desktop page layout program</nl>
   <pl>a desktop page layout program</pl>
   <pt_BR>a desktop page layout program</pt_BR>
   <pt>a desktop page layout program</pt>
   <ro>a desktop page layout program</ro>
   <ru>a desktop page layout program</ru>
   <sk>a desktop page layout program</sk>
   <sv>ett skrivbords sidlayout-program</sv>
   <tr>a desktop page layout program</tr>
   <uk>a desktop page layout program</uk>
   <zh_TW>a desktop page layout program</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/005/761/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
scribus
scribus-template
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
scribus
scribus-template
</uninstall_package_names>
</app>
