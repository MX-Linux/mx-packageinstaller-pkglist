<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Icelandic_Thunderbird
</name>

<description>
   <am>Icelandic localisation of Thunderbird</am>
   <ca>Icelandic localisation of Thunderbird</ca>
   <cs>Icelandic localisation of Thunderbird</cs>
   <de>Isländische Lokalisierung von Thunderbird</de>
   <el>Icelandic localisation of Thunderbird</el>
   <en>Icelandic localisation of Thunderbird</en>
   <es>Icelandic localisation of Thunderbird</es>
   <fi>Icelandic localisation of Thunderbird</fi>
   <fr>Icelandic localisation of Thunderbird</fr>
   <hi>Icelandic localisation of Thunderbird</hi>
   <hr>Icelandic localisation of Thunderbird</hr>
   <hu>Icelandic localisation of Thunderbird</hu>
   <it>Icelandic localisation of Thunderbird</it>
   <ja>Icelandic localisation of Thunderbird</ja>
   <kk>Icelandic localisation of Thunderbird</kk>
   <lt>Icelandic localisation of Thunderbird</lt>
   <nl>Icelandic localisation of Thunderbird</nl>
   <pl>Icelandic localisation of Thunderbird</pl>
   <pt_BR>Icelandic localisation of Thunderbird</pt_BR>
   <pt>Icelandic localisation of Thunderbird</pt>
   <ro>Icelandic localisation of Thunderbird</ro>
   <ru>Icelandic localisation of Thunderbird</ru>
   <sk>Icelandic localisation of Thunderbird</sk>
   <sv>Isländsk  lokalisering av Thunderbird </sv>
   <tr>Icelandic localisation of Thunderbird</tr>
   <uk>Icelandic localisation of Thunderbird</uk>
   <zh_TW>Icelandic localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-is
lightning-l10n-is
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-is
lightning-l10n-is
</uninstall_package_names>
</app>
