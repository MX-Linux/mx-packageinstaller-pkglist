<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Croatian_Firefox
</name>

<description>
   <am>Croatian localisation of Firefox</am>
   <ca>Localització de Firefox en Croata</ca>
   <cs>Croatian localisation of Firefox</cs>
   <de>Kroatische Lokalisierung von Firefox</de>
   <el>Croatian localisation of Firefox</el>
   <en>Croatian localisation of Firefox</en>
   <es>Croatian localisation of Firefox</es>
   <fi>Croatian localisation of Firefox</fi>
   <fr>Localisation croate pour Firefox</fr>
   <hi>Croatian localisation of Firefox</hi>
   <hr>Croatian localisation of Firefox</hr>
   <hu>Croatian localisation of Firefox</hu>
   <it>Localizzazione croata di Firefox</it>
   <ja>Croatian localisation of Firefox</ja>
   <kk>Croatian localisation of Firefox</kk>
   <lt>Croatian localisation of Firefox</lt>
   <nl>Croatian localisation of Firefox</nl>
   <pl>Croatian localisation of Firefox</pl>
   <pt_BR>Croatian localisation of Firefox</pt_BR>
   <pt>Croatian localisation of Firefox</pt>
   <ro>Croatian localisation of Firefox</ro>
   <ru>Croatian localisation of Firefox</ru>
   <sk>Croatian localisation of Firefox</sk>
   <sv>Kroatisk lokalisering av Firefox</sv>
   <tr>Croatian localisation of Firefox</tr>
   <uk>Croatian localisation of Firefox</uk>
   <zh_TW>Croatian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-hr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-hr
</uninstall_package_names>
</app>
