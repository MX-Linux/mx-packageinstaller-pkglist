<?xml version="1.0"?>
<app>

<category>
FTP
</category>

<name>
gftp
</name>

<description>
   <am>a multithreaded FTP client</am>
   <ca>a multithreaded FTP client</ca>
   <cs>a multithreaded FTP client</cs>
   <de>Ein Multithreading-FTP-Client</de>
   <el>a multithreaded FTP client</el>
   <en>a multithreaded FTP client</en>
   <es>a multithreaded FTP client</es>
   <fi>a multithreaded FTP client</fi>
   <fr>a multithreaded FTP client</fr>
   <hi>a multithreaded FTP client</hi>
   <hr>a multithreaded FTP client</hr>
   <hu>a multithreaded FTP client</hu>
   <it>a multithreaded FTP client</it>
   <ja>a multithreaded FTP client</ja>
   <kk>a multithreaded FTP client</kk>
   <lt>a multithreaded FTP client</lt>
   <nl>a multithreaded FTP client</nl>
   <pl>a multithreaded FTP client</pl>
   <pt_BR>a multithreaded FTP client</pt_BR>
   <pt>a multithreaded FTP client</pt>
   <ro>a multithreaded FTP client</ro>
   <ru>a multithreaded FTP client</ru>
   <sk>a multithreaded FTP client</sk>
   <sv>en multitråds FTP-klient</sv>
   <tr>a multithreaded FTP client</tr>
   <uk>a multithreaded FTP client</uk>
   <zh_TW>a multithreaded FTP client</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/705/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gftp-gtk
gftp-text
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gftp-gtk
gftp-text
</uninstall_package_names>
</app>
