<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>
mplayer
</name>

<description>
   <am>a powerful multimedia player and much more</am>
   <ca>a powerful multimedia player and much more</ca>
   <cs>a powerful multimedia player and much more</cs>
   <de>Ein leistungsstarker Multimedia-Player und vieles mehr</de>
   <el>a powerful multimedia player and much more</el>
   <en>a powerful multimedia player and much more</en>
   <es>a powerful multimedia player and much more</es>
   <fi>a powerful multimedia player and much more</fi>
   <fr>a powerful multimedia player and much more</fr>
   <hi>a powerful multimedia player and much more</hi>
   <hr>a powerful multimedia player and much more</hr>
   <hu>a powerful multimedia player and much more</hu>
   <it>a powerful multimedia player and much more</it>
   <ja>a powerful multimedia player and much more</ja>
   <kk>a powerful multimedia player and much more</kk>
   <lt>a powerful multimedia player and much more</lt>
   <nl>a powerful multimedia player and much more</nl>
   <pl>a powerful multimedia player and much more</pl>
   <pt_BR>a powerful multimedia player and much more</pt_BR>
   <pt>a powerful multimedia player and much more</pt>
   <ro>a powerful multimedia player and much more</ro>
   <ru>a powerful multimedia player and much more</ru>
   <sk>a powerful multimedia player and much more</sk>
   <sv>en kraftfull multimediaspelare och mycket mer</sv>
   <tr>a powerful multimedia player and much more</tr>
   <uk>a powerful multimedia player and much more</uk>
   <zh_TW>a powerful multimedia player and much more</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/158/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mplayer
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mplayer
</uninstall_package_names>
</app>
