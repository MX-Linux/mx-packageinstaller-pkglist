<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Norwegian_Firefox
</name>

<description>
   <am>Norwegian localisation of Firefox</am>
   <ca>Localització de Firefox en Noruec</ca>
   <cs>Norwegian localisation of Firefox</cs>
   <de>Norwegische Lokalisierung von Firefox</de>
   <el>Norwegian localisation of Firefox</el>
   <en>Norwegian localisation of Firefox</en>
   <es>Norwegian localisation of Firefox</es>
   <fi>Norwegian localisation of Firefox</fi>
   <fr>Norwegian localisation of Firefox</fr>
   <hi>Norwegian localisation of Firefox</hi>
   <hr>Norwegian localisation of Firefox</hr>
   <hu>Norwegian localisation of Firefox</hu>
   <it>Norwegian localisation of Firefox</it>
   <ja>Norwegian localisation of Firefox</ja>
   <kk>Norwegian localisation of Firefox</kk>
   <lt>Norwegian localisation of Firefox</lt>
   <nl>Norwegian localisation of Firefox</nl>
   <pl>Norwegian localisation of Firefox</pl>
   <pt_BR>Norwegian localisation of Firefox</pt_BR>
   <pt>Norwegian localisation of Firefox</pt>
   <ro>Norwegian localisation of Firefox</ro>
   <ru>Norwegian localisation of Firefox</ru>
   <sk>Norwegian localisation of Firefox</sk>
   <sv>Norsk lokalisering av Firefox </sv>
   <tr>Norwegian localisation of Firefox</tr>
   <uk>Norwegian localisation of Firefox</uk>
   <zh_TW>Norwegian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-nb-no
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-nb-no
</uninstall_package_names>
</app>
