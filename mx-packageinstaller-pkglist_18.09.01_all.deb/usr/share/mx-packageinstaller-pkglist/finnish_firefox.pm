<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Finnish_Firefox
</name>

<description>
   <am>Finnish localisation of Firefox</am>
   <ca>Localització de Firefox en Finès</ca>
   <cs>Finnish localisation of Firefox</cs>
   <de>Finnische Lokalisierung von Firefox</de>
   <el>Finnish localisation of Firefox</el>
   <en>Finnish localisation of Firefox</en>
   <es>Finnish localisation of Firefox</es>
   <fi>Finnish localisation of Firefox</fi>
   <fr>Finnish localisation of Firefox</fr>
   <hi>Finnish localisation of Firefox</hi>
   <hr>Finnish localisation of Firefox</hr>
   <hu>Finnish localisation of Firefox</hu>
   <it>Finnish localisation of Firefox</it>
   <ja>Finnish localisation of Firefox</ja>
   <kk>Finnish localisation of Firefox</kk>
   <lt>Finnish localisation of Firefox</lt>
   <nl>Finnish localisation of Firefox</nl>
   <pl>Finnish localisation of Firefox</pl>
   <pt_BR>Finnish localisation of Firefox</pt_BR>
   <pt>Finnish localisation of Firefox</pt>
   <ro>Finnish localisation of Firefox</ro>
   <ru>Finnish localisation of Firefox</ru>
   <sk>Finnish localisation of Firefox</sk>
   <sv>Finsk lokalisering av Firefox</sv>
   <tr>Finnish localisation of Firefox</tr>
   <uk>Finnish localisation of Firefox</uk>
   <zh_TW>Finnish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-fi
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-fi
</uninstall_package_names>
</app>
