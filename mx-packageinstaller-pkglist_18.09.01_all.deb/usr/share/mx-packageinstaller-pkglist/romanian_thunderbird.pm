<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Romanian_Thunderbird
</name>

<description>
   <am>Romanian localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Romanès</ca>
   <cs>Romanian localisation of Thunderbird</cs>
   <de>Rumänische Lokalisierung von Thunderbird</de>
   <el>Romanian localisation of Thunderbird</el>
   <en>Romanian localisation of Thunderbird</en>
   <es>Romanian localisation of Thunderbird</es>
   <fi>Romanian localisation of Thunderbird</fi>
   <fr>Romanian localisation of Thunderbird</fr>
   <hi>Romanian localisation of Thunderbird</hi>
   <hr>Romanian localisation of Thunderbird</hr>
   <hu>Romanian localisation of Thunderbird</hu>
   <it>Romanian localisation of Thunderbird</it>
   <ja>Romanian localisation of Thunderbird</ja>
   <kk>Romanian localisation of Thunderbird</kk>
   <lt>Romanian localisation of Thunderbird</lt>
   <nl>Romanian localisation of Thunderbird</nl>
   <pl>Romanian localisation of Thunderbird</pl>
   <pt_BR>Romanian localisation of Thunderbird</pt_BR>
   <pt>Romanian localisation of Thunderbird</pt>
   <ro>Romanian localisation of Thunderbird</ro>
   <ru>Romanian localisation of Thunderbird</ru>
   <sk>Romanian localisation of Thunderbird</sk>
   <sv>Rumänsk lokalisering av Thunderbird </sv>
   <tr>Romanian localisation of Thunderbird</tr>
   <uk>Romanian localisation of Thunderbird</uk>
   <zh_TW>Romanian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-ro
lightning-l10n-ro
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-ro
lightning-l10n-ro
</uninstall_package_names>
</app>
