<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Calibre
</name>

<description>
   <am>an e-book library management application</am>
   <ca>an e-book library management application</ca>
   <cs>an e-book library management application</cs>
   <de>Eine E-Book-Bibliotheksverwaltung</de>
   <el>an e-book library management application</el>
   <en>an e-book library management application</en>
   <es>an e-book library management application</es>
   <fi>an e-book library management application</fi>
   <fr>une application pour organiser sa bibliothèque e-book</fr>
   <hi>an e-book library management application</hi>
   <hr>an e-book library management application</hr>
   <hu>an e-book library management application</hu>
   <it>Applicazione per la gestione di librerie e-book</it>
   <ja>an e-book library management application</ja>
   <kk>an e-book library management application</kk>
   <lt>an e-book library management application</lt>
   <nl>an e-book library management application</nl>
   <pl>an e-book library management application</pl>
   <pt_BR>an e-book library management application</pt_BR>
   <pt>an e-book library management application</pt>
   <ro>an e-book library management application</ro>
   <ru>an e-book library management application</ru>
   <sk>an e-book library management application</sk>
   <sv>en hanteringsapp för e-boksbibliotek</sv>
   <tr>an e-book library management application</tr>
   <uk>an e-book library management application</uk>
   <zh_TW>an e-book library management application</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/971/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
calibre
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
calibre
</uninstall_package_names>
</app>
