<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Ukrainian_Firefox
</name>

<description>
   <am>Ukrainian localisation of Firefox</am>
   <ca>Localització de Firefox en Ucrainès</ca>
   <cs>Ukrainian localisation of Firefox</cs>
   <de>Ukrainische Lokalisierung von Firefox</de>
   <el>Ukrainian localisation of Firefox</el>
   <en>Ukrainian localisation of Firefox</en>
   <es>Ukrainian localisation of Firefox</es>
   <fi>Ukrainian localisation of Firefox</fi>
   <fr>Ukrainian localisation of Firefox</fr>
   <hi>Ukrainian localisation of Firefox</hi>
   <hr>Ukrainian localisation of Firefox</hr>
   <hu>Ukrainian localisation of Firefox</hu>
   <it>Ukrainian localisation of Firefox</it>
   <ja>Ukrainian localisation of Firefox</ja>
   <kk>Ukrainian localisation of Firefox</kk>
   <lt>Ukrainian localisation of Firefox</lt>
   <nl>Ukrainian localisation of Firefox</nl>
   <pl>Ukrainian localisation of Firefox</pl>
   <pt_BR>Ukrainian localisation of Firefox</pt_BR>
   <pt>Ukrainian localisation of Firefox</pt>
   <ro>Ukrainian localisation of Firefox</ro>
   <ru>Ukrainian localisation of Firefox</ru>
   <sk>Ukrainian localisation of Firefox</sk>
   <sv>Ukrainsk lokalisering av Firefox</sv>
   <tr>Ukrainian localisation of Firefox</tr>
   <uk>Ukrainian localisation of Firefox</uk>
   <zh_TW>Ukrainian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-uk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-uk
</uninstall_package_names>
</app>
