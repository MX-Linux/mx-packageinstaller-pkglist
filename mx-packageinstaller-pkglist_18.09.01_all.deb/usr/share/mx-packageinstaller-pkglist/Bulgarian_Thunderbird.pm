<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Bulgarian_Thunderbird
</name>

<description>
   <am>Bulgarian localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Búlgar</ca>
   <cs>Bulgarian localisation of Thunderbird</cs>
   <de>Bulgarische Lokalisierung von Thunderbird</de>
   <el>Bulgarian localisation of Thunderbird</el>
   <en>Bulgarian localisation of Thunderbird</en>
   <es>Bulgarian localisation of Thunderbird</es>
   <fi>Bulgarian localisation of Thunderbird</fi>
   <fr>Localisation bulgare pour Thunderbird</fr>
   <hi>Bulgarian localisation of Thunderbird</hi>
   <hr>Bulgarian localisation of Thunderbird</hr>
   <hu>Bulgarian localisation of Thunderbird</hu>
   <it>Localizzazione bulgara di Thunderbird</it>
   <ja>Bulgarian localisation of Thunderbird</ja>
   <kk>Bulgarian localisation of Thunderbird</kk>
   <lt>Bulgarian localisation of Thunderbird</lt>
   <nl>Bulgarian localisation of Thunderbird</nl>
   <pl>Bulgarian localisation of Thunderbird</pl>
   <pt_BR>Bulgarian localisation of Thunderbird</pt_BR>
   <pt>Bulgarian localisation of Thunderbird</pt>
   <ro>Bulgarian localisation of Thunderbird</ro>
   <ru>Bulgarian localisation of Thunderbird</ru>
   <sk>Bulgarian localisation of Thunderbird</sk>
   <sv>Bulgarisk lokalisering av  Thunderbird</sv>
   <tr>Bulgarian localisation of Thunderbird</tr>
   <uk>Bulgarian localisation of Thunderbird</uk>
   <zh_TW>Bulgarian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-bg
lightning-l10n-bg
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-bg
lightning-l10n-bg
</uninstall_package_names>
</app>
