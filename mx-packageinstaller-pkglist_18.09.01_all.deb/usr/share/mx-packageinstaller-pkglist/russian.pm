<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Russian
</name>

<description>
   <am>Russian Language Meta-Package</am>
   <ca>Meta-paquet de llengua per a Rus</ca>
   <cs>Russian Language Meta-Package</cs>
   <de>Russisches Sprach-Meta-Paket</de>
   <el>Russian Language Meta-Package</el>
   <en>Russian Language Meta-Package</en>
   <es>Russian Language Meta-Package</es>
   <fi>Russian Language Meta-Package</fi>
   <fr>Russian Language Meta-Package</fr>
   <hi>Russian Language Meta-Package</hi>
   <hr>Russian Language Meta-Package</hr>
   <hu>Russian Language Meta-Package</hu>
   <it>Russian Language Meta-Package</it>
   <ja>Russian Language Meta-Package</ja>
   <kk>Russian Language Meta-Package</kk>
   <lt>Russian Language Meta-Package</lt>
   <nl>Russian Language Meta-Package</nl>
   <pl>Russian Language Meta-Package</pl>
   <pt_BR>Russian Language Meta-Package</pt_BR>
   <pt>Russian Language Meta-Package</pt>
   <ro>Russian Language Meta-Package</ro>
   <ru>Russian Language Meta-Package</ru>
   <sk>Russian Language Meta-Package</sk>
   <sv>Ryskt Språk-Meta-Paket </sv>
   <tr>Russian Language Meta-Package</tr>
   <uk>Russian Language Meta-Package</uk>
   <zh_TW>Russian Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-ru
console-cyrillic
myspell-ru
irussian
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-ru
console-cyrillic
myspell-ru
irussian
</uninstall_package_names>
</app>
