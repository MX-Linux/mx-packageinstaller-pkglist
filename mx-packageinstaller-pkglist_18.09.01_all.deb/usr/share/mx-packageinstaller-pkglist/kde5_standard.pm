<?xml version="1.0"?>
<app>

<category>
Desktop Environments
</category>

<name>
KDE5 Standard
</name>

<description>
   <am>Installs kde-standard, kde-plasma-desktop</am>
   <ca>Installs kde-standard, kde-plasma-desktop</ca>
   <cs>Installs kde-standard, kde-plasma-desktop</cs>
   <de>Installiert KDE-standard, KDE-plasma-desktop</de>
   <el>Installs kde-standard, kde-plasma-desktop</el>
   <en>Installs kde-standard, kde-plasma-desktop</en>
   <es>Installs kde-standard, kde-plasma-desktop</es>
   <fi>Installs kde-standard, kde-plasma-desktop</fi>
   <fr>Installation de kde-standard, kde-plasma-desktop</fr>
   <hi>Installs kde-standard, kde-plasma-desktop</hi>
   <hr>Installs kde-standard, kde-plasma-desktop</hr>
   <hu>Installs kde-standard, kde-plasma-desktop</hu>
   <it>Installs kde-standard, kde-plasma-desktop</it>
   <ja>Installs kde-standard, kde-plasma-desktop</ja>
   <kk>Installs kde-standard, kde-plasma-desktop</kk>
   <lt>Installs kde-standard, kde-plasma-desktop</lt>
   <nl>Installs kde-standard, kde-plasma-desktop</nl>
   <pl>Installs kde-standard, kde-plasma-desktop</pl>
   <pt_BR>Installs kde-standard, kde-plasma-desktop</pt_BR>
   <pt>Installs kde-standard, kde-plasma-desktop</pt>
   <ro>Installs kde-standard, kde-plasma-desktop</ro>
   <ru>Installs kde-standard, kde-plasma-desktop</ru>
   <sk>Installs kde-standard, kde-plasma-desktop</sk>
   <sv>Installerar kde-standard, kde-plasma-desktop</sv>
   <tr>Installs kde-standard, kde-plasma-desktop</tr>
   <uk>Installs kde-standard, kde-plasma-desktop</uk>
   <zh_TW>Installs kde-standard, kde-plasma-desktop</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
kde-standard
kde-plasma-desktop
</install_package_names>

<postinstall>

</postinstall>

<uninstall_package_names>
kde-standard
kde-standard
</uninstall_package_names>

</app>
