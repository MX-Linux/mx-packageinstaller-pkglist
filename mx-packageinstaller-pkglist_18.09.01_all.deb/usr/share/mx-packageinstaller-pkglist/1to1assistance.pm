<?xml version="1.0"?>
<app>

<category>
Remote Access
</category>

<name>
1-to-1 Assistance
</name>

<description>
   <am>Remote access help app from antiX</am>
   <ca>Eina d'ajuda d'accés remot d'antiX</ca>
   <cs>Remote access help app from antiX</cs>
   <de>Fernwartungsanwendung von antiX</de>
   <el>Remote access help app from antiX</el>
   <en>Remote access help app from antiX</en>
   <es>Remote access help app from antiX</es>
   <fi>Remote access help app from antiX</fi>
   <fr>Application d'aide pour l'accès à distance d'antiX</fr>
   <hi>Remote access help app from antiX</hi>
   <hr>Remote access help app from antiX</hr>
   <hu>Remote access help app from antiX</hu>
   <it>App da antiX, che permette un accesso remoto</it>
   <ja>Remote access help app from antiX</ja>
   <kk>Remote access help app from antiX</kk>
   <lt>Remote access help app from antiX</lt>
   <nl>Afstand toegankelijke hulp app van antiX</nl>
   <pl>Remote access help app from antiX</pl>
   <pt_BR>Remote access help app from antiX</pt_BR>
   <pt>Remote access help app from antiX</pt>
   <ro>Remote access help app from antiX</ro>
   <ru>Remote access help app from antiX</ru>
   <sk>Remote access help app from antiX</sk>
   <sv>Hjälp-app för fjärråtkomst från antiX</sv>
   <tr>Remote access help app from antiX</tr>
   <uk>Remote access help app from antiX</uk>
   <zh_TW>Remote access help app from antiX</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
1-to-1-assistance-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
1-to-1-assistance-antix
</uninstall_package_names>
</app>
