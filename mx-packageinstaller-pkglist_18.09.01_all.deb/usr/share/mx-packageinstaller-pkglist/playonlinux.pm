<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>
Play on Linux
</name>

<description>
   <am>Play on Linux</am>
   <ca>Play on Linux</ca>
   <cs>Play on Linux</cs>
   <de>Ein grafisches Frontend für Wine</de>
   <el>Play on Linux</el>
   <en>Play on Linux</en>
   <es>Play on Linux</es>
   <fi>Play on Linux</fi>
   <fr>Play on Linux</fr>
   <hi>Play on Linux</hi>
   <hr>Play on Linux</hr>
   <hu>Play on Linux</hu>
   <it>Play on Linux</it>
   <ja>Play on Linux</ja>
   <kk>Play on Linux</kk>
   <lt>Play on Linux</lt>
   <nl>Play on Linux</nl>
   <pl>Play on Linux</pl>
   <pt_BR>Play on Linux</pt_BR>
   <pt>Play on Linux</pt>
   <ro>Play on Linux</ro>
   <ru>Play on Linux</ru>
   <sk>Play on Linux</sk>
   <sv>Play on Linux</sv>
   <tr>Play on Linux</tr>
   <uk>Play on Linux</uk>
   <zh_TW>Play on Linux</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/063/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
wine-staging
wine-staging-compat
playonlinux
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
wine-staging
wine-staging-compat
playonlinux
</uninstall_package_names>
</app>
