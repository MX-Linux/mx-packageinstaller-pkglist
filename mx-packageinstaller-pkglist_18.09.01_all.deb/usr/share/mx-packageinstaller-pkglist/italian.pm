<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Italian
</name>

<description>
   <am>Italian Language Meta-Package</am>
   <ca>Italian Language Meta-Package</ca>
   <cs>Italian Language Meta-Package</cs>
   <de>Italienisches Sprach-Meta-Paket</de>
   <el>Italian Language Meta-Package</el>
   <en>Italian Language Meta-Package</en>
   <es>Italian Language Meta-Package</es>
   <fi>Italian Language Meta-Package</fi>
   <fr>Italian Language Meta-Package</fr>
   <hi>Italian Language Meta-Package</hi>
   <hr>Italian Language Meta-Package</hr>
   <hu>Italian Language Meta-Package</hu>
   <it>Meta-pacchetto della lingua italiana</it>
   <ja>Italian Language Meta-Package</ja>
   <kk>Italian Language Meta-Package</kk>
   <lt>Italian Language Meta-Package</lt>
   <nl>Italian Language Meta-Package</nl>
   <pl>Italian Language Meta-Package</pl>
   <pt_BR>Italian Language Meta-Package</pt_BR>
   <pt>Italian Language Meta-Package</pt>
   <ro>Italian Language Meta-Package</ro>
   <ru>Italian Language Meta-Package</ru>
   <sk>Italian Language Meta-Package</sk>
   <sv>Italienskt Språk-Meta-Paket </sv>
   <tr>Italian Language Meta-Package</tr>
   <uk>Italian Language Meta-Package</uk>
   <zh_TW>Italian Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-it
myspell-it
manpages-it
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-it
myspell-it
manpages-it
</uninstall_package_names>
</app>
