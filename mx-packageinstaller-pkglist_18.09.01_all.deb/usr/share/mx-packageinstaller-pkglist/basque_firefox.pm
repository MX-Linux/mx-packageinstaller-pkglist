<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Basque_Firefox
</name>

<description>
   <am>Basque localisation of Firefox</am>
   <ca>Localització de Firefox en Euskara</ca>
   <cs>Basque localisation of Firefox</cs>
   <de>Baskische Lokalisierung von Firefox</de>
   <el>Basque localisation of Firefox</el>
   <en>Basque localisation of Firefox</en>
   <es>Basque localisation of Firefox</es>
   <fi>Basque localisation of Firefox</fi>
   <fr>Localisation basque pour Firefox</fr>
   <hi>Basque localisation of Firefox</hi>
   <hr>Baskijska lokalizacija Firefoxa</hr>
   <hu>Basque localisation of Firefox</hu>
   <it>Localizzazione basca di Firefox</it>
   <ja>Basque localisation of Firefox</ja>
   <kk>Basque localisation of Firefox</kk>
   <lt>Basque localisation of Firefox</lt>
   <nl>Baskische lokalisatie van Firefox</nl>
   <pl>Basque localisation of Firefox</pl>
   <pt_BR>Basque localisation of Firefox</pt_BR>
   <pt>Basque localisation of Firefox</pt>
   <ro>Basque localisation of Firefox</ro>
   <ru>Basque localisation of Firefox</ru>
   <sk>Basque localisation of Firefox</sk>
   <sv>Baskisk lokalisering av Firefox</sv>
   <tr>Basque localisation of Firefox</tr>
   <uk>Basque localisation of Firefox</uk>
   <zh_TW>Basque localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-eu
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-eu
</uninstall_package_names>
</app>
