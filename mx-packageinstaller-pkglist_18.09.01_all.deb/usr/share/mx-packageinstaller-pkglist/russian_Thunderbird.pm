<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Russian_Thunderbird
</name>

<description>
   <am>Russian localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Rus</ca>
   <cs>Russian localisation of Thunderbird</cs>
   <de>Russische Lokalisierung von Thunderbird</de>
   <el>Russian localisation of Thunderbird</el>
   <en>Russian localisation of Thunderbird</en>
   <es>Russian localisation of Thunderbird</es>
   <fi>Russian localisation of Thunderbird</fi>
   <fr>Russian localisation of Thunderbird</fr>
   <hi>Russian localisation of Thunderbird</hi>
   <hr>Russian localisation of Thunderbird</hr>
   <hu>Russian localisation of Thunderbird</hu>
   <it>Russian localisation of Thunderbird</it>
   <ja>Russian localisation of Thunderbird</ja>
   <kk>Russian localisation of Thunderbird</kk>
   <lt>Russian localisation of Thunderbird</lt>
   <nl>Russian localisation of Thunderbird</nl>
   <pl>Russian localisation of Thunderbird</pl>
   <pt_BR>Russian localisation of Thunderbird</pt_BR>
   <pt>Russian localisation of Thunderbird</pt>
   <ro>Russian localisation of Thunderbird</ro>
   <ru>Russian localisation of Thunderbird</ru>
   <sk>Russian localisation of Thunderbird</sk>
   <sv>Rysk  lokalisering av Thunderbird</sv>
   <tr>Russian localisation of Thunderbird</tr>
   <uk>Russian localisation of Thunderbird</uk>
   <zh_TW>Russian localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-ru
lightning-l10n-ru
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-ru
lightning-l10n-ru
</uninstall_package_names>
</app>
