<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>
gThumb
</name>

<description>
   <am>advanced image viewer and browser</am>
   <ca>advanced image viewer and browser</ca>
   <cs>advanced image viewer and browser</cs>
   <de>Erweiterter Bildbetrachter und Browser</de>
   <el>advanced image viewer and browser</el>
   <en>advanced image viewer and browser</en>
   <es>advanced image viewer and browser</es>
   <fi>advanced image viewer and browser</fi>
   <fr>advanced image viewer and browser</fr>
   <hi>advanced image viewer and browser</hi>
   <hr>advanced image viewer and browser</hr>
   <hu>advanced image viewer and browser</hu>
   <it>advanced image viewer and browser</it>
   <ja>advanced image viewer and browser</ja>
   <kk>advanced image viewer and browser</kk>
   <lt>advanced image viewer and browser</lt>
   <nl>advanced image viewer and browser</nl>
   <pl>advanced image viewer and browser</pl>
   <pt_BR>advanced image viewer and browser</pt_BR>
   <pt>advanced image viewer and browser</pt>
   <ro>advanced image viewer and browser</ro>
   <ru>advanced image viewer and browser</ru>
   <sk>advanced image viewer and browser</sk>
   <sv>avancerad bildbetraktare och läsare</sv>
   <tr>advanced image viewer and browser</tr>
   <uk>advanced image viewer and browser</uk>
   <zh_TW>advanced image viewer and browser</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/461/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gthumb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gthumb
</uninstall_package_names>
</app>
