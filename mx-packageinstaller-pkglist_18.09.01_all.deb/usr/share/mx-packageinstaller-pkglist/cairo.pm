<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>
Cairo Dock
</name>

<description>
   <am>3d capable dock w/ plugins</am>
   <ca>Prestatge amb capacitat 3D amb connectors</ca>
   <cs>3d capable dock w/ plugins</cs>
   <de>3d-fähiges Dock mit Plugins</de>
   <el>3d capable dock w/ plugins</el>
   <en>3d capable dock w/ plugins</en>
   <es>3d capable dock w/ plugins</es>
   <fi>3d capable dock w/ plugins</fi>
   <fr>3d capable dock w/ plugins</fr>
   <hi>3d capable dock w/ plugins</hi>
   <hr>3d capable dock w/ plugins</hr>
   <hu>3d capable dock w/ plugins</hu>
   <it>3d capable dock w/ plugins</it>
   <ja>3d capable dock w/ plugins</ja>
   <kk>3d capable dock w/ plugins</kk>
   <lt>3d capable dock w/ plugins</lt>
   <nl>3d capable dock w/ plugins</nl>
   <pl>3d capable dock w/ plugins</pl>
   <pt_BR>3d capable dock w/ plugins</pt_BR>
   <pt>3d capable dock w/ plugins</pt>
   <ro>3d capable dock w/ plugins</ro>
   <ru>3d capable dock w/ plugins</ru>
   <sk>3d capable dock w/ plugins</sk>
   <sv>3D kapabel docka med plugins</sv>
   <tr>3d capable dock w/ plugins</tr>
   <uk>3d capable dock w/ plugins</uk>
   <zh_TW>3d capable dock w/ plugins</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/145/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
cairo-dock
cairo-dock-xfce-integration-plug-in
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
cairo-dock
cairo-dock-xfce-integration-plug-in
</uninstall_package_names>
</app>
