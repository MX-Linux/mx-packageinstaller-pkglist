<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>
Docky
</name>

<description>
   <am>Elegant, Clean, Powerful Dock</am>
   <ca>Elegant, Clean, Powerful Dock</ca>
   <cs>Elegant, Clean, Powerful Dock</cs>
   <de>Elegantes, sauberes, leistungsstarkes Dock</de>
   <el>Elegant, Clean, Powerful Dock</el>
   <en>Elegant, Clean, Powerful Dock</en>
   <es>Elegant, Clean, Powerful Dock</es>
   <fi>Elegant, Clean, Powerful Dock</fi>
   <fr>Un Dock solide, clair, et élégant</fr>
   <hi>Elegant, Clean, Powerful Dock</hi>
   <hr>Elegant, Clean, Powerful Dock</hr>
   <hu>Elegant, Clean, Powerful Dock</hu>
   <it>Barra dock elegante, pulita, potente</it>
   <ja>Elegant, Clean, Powerful Dock</ja>
   <kk>Elegant, Clean, Powerful Dock</kk>
   <lt>Elegant, Clean, Powerful Dock</lt>
   <nl>Elegant, Clean, Powerful Dock</nl>
   <pl>Elegant, Clean, Powerful Dock</pl>
   <pt_BR>Elegant, Clean, Powerful Dock</pt_BR>
   <pt>Elegant, Clean, Powerful Dock</pt>
   <ro>Elegant, Clean, Powerful Dock</ro>
   <ru>Elegant, Clean, Powerful Dock</ru>
   <sk>Elegant, Clean, Powerful Dock</sk>
   <sv>Elegant, Ren, Kraftfull Docka</sv>
   <tr>Elegant, Clean, Powerful Dock</tr>
   <uk>Elegant, Clean, Powerful Dock</uk>
   <zh_TW>Elegant, Clean, Powerful Dock</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/689/thumb.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
docky
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
docky
</uninstall_package_names>
</app>
