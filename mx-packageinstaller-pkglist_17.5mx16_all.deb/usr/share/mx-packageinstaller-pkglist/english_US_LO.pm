<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
US_English_Libreoffice
</name>

<description>  
US English Help for LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-help-en-us
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-help-en-us
</uninstall_package_names>
</app>