<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>  
Scratch
</name>

<description>  
Scratch Graphical Programming envirnoment from M.I.T. https://scratch.mit.edu/
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
scratch
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
scratch
</uninstall_package_names>
</app>