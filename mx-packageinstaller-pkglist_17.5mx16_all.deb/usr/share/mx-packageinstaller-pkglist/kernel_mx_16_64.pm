<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
MX16 Default
</name>

<description>  
Default Kernel MX-16 64 bit
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.7.0-0.bpo.1-amd64-unsigned
linux-headers-4.7.0-0.bpo.1-amd64
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.7.0-0.bpo.1-amd64-unsigned
linux-headers-4.7.0-0.bpo.1-amd64
</uninstall_package_names>
</app>