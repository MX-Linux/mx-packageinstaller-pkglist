<?xml version="1.0"?>
<app>

<category>
Newsreader
</category>

<name>  
Newsbeuter
</name>

<description>  
a text mode rss feed reader with podcast support
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/063/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
newsbeuter
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
newsbeuter
</uninstall_package_names>
</app>