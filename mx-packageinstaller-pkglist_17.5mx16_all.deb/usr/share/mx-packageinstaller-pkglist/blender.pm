<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
Blender
</name>

<description>  
a free and open source 3D animation suite
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/012/359/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
blender
libgl1-mesa-dri
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
blender
libgl1-mesa-dri
</uninstall_package_names>
</app>