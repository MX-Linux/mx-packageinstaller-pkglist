<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Chinese_CN_Firefox
</name>

<description>  
Chinese_simplified localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-zh-tw
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-zh-tw
</uninstall_package_names>
</app>