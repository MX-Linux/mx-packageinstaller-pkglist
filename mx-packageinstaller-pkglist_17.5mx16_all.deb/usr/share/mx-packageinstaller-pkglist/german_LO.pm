<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
German_Libreoffice
</name>

<description>  
German Language Meta-Package for LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
      libreoffice-draw     
      libreoffice-impress 
      libreoffice-math
      libreoffice-writer
      libreoffice-l10n-de
      libreoffice-help-de
      libreoffice-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
      libreoffice-draw     
      libreoffice-impress 
      libreoffice-math
      libreoffice-writer
      libreoffice-l10n-de
      libreoffice-help-de
      libreoffice-gtk
</uninstall_package_names>
</app>