<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
GB_English_Libreoffice
</name>

<description>  
GB English Help for LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-help-en-gb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-help-en-gb
</uninstall_package_names>
</app>