<?xml version="1.0"?>
<app>

<category>
Torrent
</category>

<name>  
qBittorrent
</name>

<description>  
a QT4 feature rich but lightweight client that is very similar to uTorrent
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/486/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
qbittorrent
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
qbittorrent
</uninstall_package_names>
</app>