<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Italian_Libreoffice
</name>

<description>  
Italian LibreOffice Language Meta-Package
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-it
	libreoffice-help-it
        libreoffice-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-it
	libreoffice-help-it
        libreoffice-gtk
</uninstall_package_names>
</app>