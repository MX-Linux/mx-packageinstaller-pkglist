<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>  
GIT Tools
</name>

<description>  
GIT Repo tools
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
git
gitk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
git
gitk
</uninstall_package_names>
</app>