<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>  
SuperTux
</name>

<description>  
Mario style platform game w/ Tux
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/007/228/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
supertux
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
supertux
</uninstall_package_names>
</app>