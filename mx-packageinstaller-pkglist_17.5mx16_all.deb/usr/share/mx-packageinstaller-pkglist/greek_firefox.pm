<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Greek_Firefox
</name>

<description>  
Greek localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-el
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-el
</uninstall_package_names>
</app>