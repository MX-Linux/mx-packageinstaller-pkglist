<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
4.10 kernel
</name>

<description>  
antiX 4.10 kernel, 64 bit 
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.10.5-antix.3-686-smp-pae
linux-headers-4.10.5-antix.3-686-smp-pae
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.10.5-antix.3-686-smp-pae
linux-headers-4.10.5-antix.3-686-smp-pae
</uninstall_package_names>
</app>