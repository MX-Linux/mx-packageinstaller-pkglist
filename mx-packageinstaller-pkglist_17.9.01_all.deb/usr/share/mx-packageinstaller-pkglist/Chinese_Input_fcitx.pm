<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Chinese_Input_fcitx
</name>

<description>  
Chinese fcitx
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
fcitx
fcitx-config-gtk
fcitx-frontend-all
fcitx-frontend-fbterm
fcitx-tools
fcitx-ui-classic
fcitx-ui-light
fcitx-googlepinyin
fcitx-libpinyin
fcitx-rime 
fcitx-sunpinyin
fcitx-chewing
fcitx-table-all 
fcitx-config-gtk2
fcitx-frontend-gtk2
fcitx-frontend-gtk3
fcitx-frontend-qt4
fcitx-frontend-qt5
im-config
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
fcitx
fcitx-config-gtk
fcitx-frontend-all
fcitx-frontend-fbterm
fcitx-tools
fcitx-ui-classic
fcitx-ui-light
fcitx-googlepinyin
fcitx-libpinyin
fcitx-rime 
fcitx-sunpinyin
fcitx-chewing
fcitx-table-all 
fcitx-config-gtk2
fcitx-frontend-gtk2
fcitx-frontend-gtk3
fcitx-frontend-qt4
fcitx-frontend-qt5
im-config
</uninstall_package_names>
</app>