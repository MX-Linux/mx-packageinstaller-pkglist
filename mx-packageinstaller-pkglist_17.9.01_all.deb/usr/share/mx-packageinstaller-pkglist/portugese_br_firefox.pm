<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Portugese(BR)_Firefox
</name>

<description>  
Portuguese(BR) localisation of Firefox
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
     firefox-l10n-xpi-pt-br 
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
     firefox-l10n-xpi-pt-br 
</uninstall_package_names>
</app>