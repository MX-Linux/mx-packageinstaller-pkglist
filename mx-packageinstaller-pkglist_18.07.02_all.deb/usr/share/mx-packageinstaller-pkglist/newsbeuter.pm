<?xml version="1.0"?>
<app>

<category>
Newsreader
</category>

<name>
Newsbeuter
</name>

<description>
   <am>a text mode rss feed reader with podcast support</am>
   <ca>a text mode rss feed reader with podcast support</ca>
   <cs>a text mode rss feed reader with podcast support</cs>
   <de>Ein Textmodus-RSS-Feedreader mit Podcast-Unterstützung</de>
   <el>a text mode rss feed reader with podcast support</el>
   <en>a text mode rss feed reader with podcast support</en>
   <es>a text mode rss feed reader with podcast support</es>
   <fi>a text mode rss feed reader with podcast support</fi>
   <fr>a text mode rss feed reader with podcast support</fr>
   <hi>a text mode rss feed reader with podcast support</hi>
   <hr>a text mode rss feed reader with podcast support</hr>
   <hu>a text mode rss feed reader with podcast support</hu>
   <it>a text mode rss feed reader with podcast support</it>
   <ja>a text mode rss feed reader with podcast support</ja>
   <kk>a text mode rss feed reader with podcast support</kk>
   <lt>a text mode rss feed reader with podcast support</lt>
   <nl>a text mode rss feed reader with podcast support</nl>
   <pl>a text mode rss feed reader with podcast support</pl>
   <pt_BR>a text mode rss feed reader with podcast support</pt_BR>
   <pt>a text mode rss feed reader with podcast support</pt>
   <ro>a text mode rss feed reader with podcast support</ro>
   <ru>a text mode rss feed reader with podcast support</ru>
   <sk>a text mode rss feed reader with podcast support</sk>
   <sv>en textläges  rss feed läsare med podcast support</sv>
   <tr>a text mode rss feed reader with podcast support</tr>
   <uk>a text mode rss feed reader with podcast support</uk>
   <zh_TW>a text mode rss feed reader with podcast support</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/063/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
newsbeuter
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
newsbeuter
</uninstall_package_names>
</app>
