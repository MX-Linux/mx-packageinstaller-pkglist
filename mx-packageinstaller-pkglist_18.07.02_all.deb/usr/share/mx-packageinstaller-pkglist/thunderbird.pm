<?xml version="1.0"?>
<app>

<category>
Email
</category>

<name>
Thunderbird
</name>

<description>
   <am>Latest Thunderbird email client from MX Community</am>
   <ca>Darrer client de correu Thunderbird de la Comunitat MX</ca>
   <cs>Latest Thunderbird email client from MX Community</cs>
   <de>Neuester Thunderbird E-Mail-Client von MX Community</de>
   <el>Latest Thunderbird email client from MX Community</el>
   <en>Latest Thunderbird email client from MX Community</en>
   <es>Latest Thunderbird email client from MX Community</es>
   <fi>Latest Thunderbird email client from MX Community</fi>
   <fr>La dernière version du client mail Thunderbird par la Communauté MX</fr>
   <hi>Latest Thunderbird email client from MX Community</hi>
   <hr>Latest Thunderbird email client from MX Community</hr>
   <hu>Latest Thunderbird email client from MX Community</hu>
   <it>Latest Thunderbird email client from MX Community</it>
   <ja>Latest Thunderbird email client from MX Community</ja>
   <kk>Latest Thunderbird email client from MX Community</kk>
   <lt>Latest Thunderbird email client from MX Community</lt>
   <nl>Latest Thunderbird email client from MX Community</nl>
   <pl>Latest Thunderbird email client from MX Community</pl>
   <pt_BR>Latest Thunderbird email client from MX Community</pt_BR>
   <pt>Latest Thunderbird email client from MX Community</pt>
   <ro>Latest Thunderbird email client from MX Community</ro>
   <ru>Latest Thunderbird email client from MX Community</ru>
   <sk>Latest Thunderbird email client from MX Community</sk>
   <sv>Senaste Thunderbird mejlklient från MX Community</sv>
   <tr>Latest Thunderbird email client from MX Community</tr>
   <uk>Latest Thunderbird email client from MX Community</uk>
   <zh_TW>Latest Thunderbird email client from MX Community</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/137/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird
</uninstall_package_names>
</app>
