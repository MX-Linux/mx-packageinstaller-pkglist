<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>
GIT Tools
</name>

<description>
   <am>GIT Repo tools</am>
   <ca>GIT Repo tools</ca>
   <cs>GIT Repo tools</cs>
   <de>GIT Repo Werkzeuge</de>
   <el>GIT Repo tools</el>
   <en>GIT Repo tools</en>
   <es>GIT Repo tools</es>
   <fi>GIT Repo tools</fi>
   <fr>GIT Repo tools</fr>
   <hi>GIT Repo tools</hi>
   <hr>GIT Repo tools</hr>
   <hu>GIT Repo tools</hu>
   <it>GIT Repo tools</it>
   <ja>GIT Repo tools</ja>
   <kk>GIT Repo tools</kk>
   <lt>GIT Repo tools</lt>
   <nl>GIT Repo tools</nl>
   <pl>GIT Repo tools</pl>
   <pt_BR>GIT Repo tools</pt_BR>
   <pt>GIT Repo tools</pt>
   <ro>GIT Repo tools</ro>
   <ru>GIT Repo tools</ru>
   <sk>GIT Repo tools</sk>
   <sv>GIT Förråds verktyg</sv>
   <tr>GIT Repo tools</tr>
   <uk>GIT Repo tools</uk>
   <zh_TW>GIT Repo tools</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
git
gitk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
git
gitk
</uninstall_package_names>
</app>
