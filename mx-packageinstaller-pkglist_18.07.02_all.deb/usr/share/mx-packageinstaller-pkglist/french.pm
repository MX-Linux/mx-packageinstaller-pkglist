<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
French
</name>

<description>
   <am>French Language Meta-Package</am>
   <ca>Meta-paquet de llengua Francesa</ca>
   <cs>French Language Meta-Package</cs>
   <de>Französisches Sprach-Meta-Paket</de>
   <el>French Language Meta-Package</el>
   <en>French Language Meta-Package</en>
   <es>French Language Meta-Package</es>
   <fi>French Language Meta-Package</fi>
   <fr>French Language Meta-Package</fr>
   <hi>French Language Meta-Package</hi>
   <hr>French Language Meta-Package</hr>
   <hu>French Language Meta-Package</hu>
   <it>French Language Meta-Package</it>
   <ja>French Language Meta-Package</ja>
   <kk>French Language Meta-Package</kk>
   <lt>French Language Meta-Package</lt>
   <nl>French Language Meta-Package</nl>
   <pl>French Language Meta-Package</pl>
   <pt_BR>French Language Meta-Package</pt_BR>
   <pt>French Language Meta-Package</pt>
   <ro>French Language Meta-Package</ro>
   <ru>French Language Meta-Package</ru>
   <sk>French Language Meta-Package</sk>
   <sv>Franskt Språk Meta-Paket</sv>
   <tr>French Language Meta-Package</tr>
   <uk>French Language Meta-Package</uk>
   <zh_TW>French Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-fr
myspell-fr
manpages-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-fr
myspell-fr
manpages-fr
</uninstall_package_names>
</app>
