<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Croatian_Additional
</name>

<description>
   <am>Additional Croatian Meta-Package</am>
   <ca>Meta-paquet addicional en Croata</ca>
   <cs>Additional Croatian Meta-Package</cs>
   <de>Zusätzliches kroatisches Sprach-Meta-Paket</de>
   <el>Additional Croatian Meta-Package</el>
   <en>Additional Croatian Meta-Package</en>
   <es>Additional Croatian Meta-Package</es>
   <fi>Additional Croatian Meta-Package</fi>
   <fr>Additional Croatian Meta-Package</fr>
   <hi>Additional Croatian Meta-Package</hi>
   <hr>Additional Croatian Meta-Package</hr>
   <hu>Additional Croatian Meta-Package</hu>
   <it>Meta-pacchetto aggiuntivo della lingua croata</it>
   <ja>Additional Croatian Meta-Package</ja>
   <kk>Additional Croatian Meta-Package</kk>
   <lt>Additional Croatian Meta-Package</lt>
   <nl>Additional Croatian Meta-Package</nl>
   <pl>Additional Croatian Meta-Package</pl>
   <pt_BR>Additional Croatian Meta-Package</pt_BR>
   <pt>Additional Croatian Meta-Package</pt>
   <ro>Additional Croatian Meta-Package</ro>
   <ru>Additional Croatian Meta-Package</ru>
   <sk>Additional Croatian Meta-Package</sk>
   <sv>Kroatiskt Tillägg Meta-Paket</sv>
   <tr>Additional Croatian Meta-Package</tr>
   <uk>Additional Croatian Meta-Package</uk>
   <zh_TW>Additional Croatian Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
maint-guide
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
maint-guide
</uninstall_package_names>
</app>
