<?xml version="1.0"?>
<app>

<category>
Themes
</category>

<name>
Obsidian-2 Gtk Theme
</name>

<description>
   <am>a dark Gtk Theme</am>
   <ca>a dark Gtk Theme</ca>
   <cs>a dark Gtk Theme</cs>
   <de>Ein dunkles Gtk-Thema</de>
   <el>a dark Gtk Theme</el>
   <en>a dark Gtk Theme</en>
   <es>a dark Gtk Theme</es>
   <fi>a dark Gtk Theme</fi>
   <fr>Thème sombre GTK</fr>
   <hi>a dark Gtk Theme</hi>
   <hr>a dark Gtk Theme</hr>
   <hu>a dark Gtk Theme</hu>
   <it>a dark Gtk Theme</it>
   <ja>a dark Gtk Theme</ja>
   <kk>a dark Gtk Theme</kk>
   <lt>a dark Gtk Theme</lt>
   <nl>a dark Gtk Theme</nl>
   <pl>a dark Gtk Theme</pl>
   <pt_BR>a dark Gtk Theme</pt_BR>
   <pt>a dark Gtk Theme</pt>
   <ro>a dark Gtk Theme</ro>
   <ru>a dark Gtk Theme</ru>
   <sk>a dark Gtk Theme</sk>
   <sv>ett mörkt Gtk Tema</sv>
   <tr>a dark Gtk Theme</tr>
   <uk>a dark Gtk Theme</uk>
   <zh_TW>a dark Gtk Theme</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
obsidian-2-gtk-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
obsidian-2-gtk-theme
</uninstall_package_names>
</app>
