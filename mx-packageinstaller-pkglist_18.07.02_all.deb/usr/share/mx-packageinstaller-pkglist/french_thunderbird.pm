<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
French_Thunderbird
</name>

<description>
   <am>French localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Francès</ca>
   <cs>French localisation of Thunderbird</cs>
   <de>Französische Lokalisierung von Thunderbird</de>
   <el>French localisation of Thunderbird</el>
   <en>French localisation of Thunderbird</en>
   <es>French localisation of Thunderbird</es>
   <fi>French localisation of Thunderbird</fi>
   <fr>French localisation of Thunderbird</fr>
   <hi>French localisation of Thunderbird</hi>
   <hr>French localisation of Thunderbird</hr>
   <hu>French localisation of Thunderbird</hu>
   <it>French localisation of Thunderbird</it>
   <ja>French localisation of Thunderbird</ja>
   <kk>French localisation of Thunderbird</kk>
   <lt>French localisation of Thunderbird</lt>
   <nl>French localisation of Thunderbird</nl>
   <pl>French localisation of Thunderbird</pl>
   <pt_BR>French localisation of Thunderbird</pt_BR>
   <pt>French localisation of Thunderbird</pt>
   <ro>French localisation of Thunderbird</ro>
   <ru>French localisation of Thunderbird</ru>
   <sk>French localisation of Thunderbird</sk>
   <sv>Fransk lokalisering av Thunderbird</sv>
   <tr>French localisation of Thunderbird</tr>
   <uk>French localisation of Thunderbird</uk>
   <zh_TW>French localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-fr
lightning-l10n-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-fr
lightning-l10n-fr
</uninstall_package_names>
</app>
