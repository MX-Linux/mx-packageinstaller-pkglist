<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
GB_English_Libreoffice
</name>

<description>
   <am>GB English Help for LibreOffice</am>
   <ca>Ajuda en anglès (UK) per LibreOffice</ca>
   <cs>GB English Help for LibreOffice</cs>
   <de>English (GB) Help for LibreOffice</de>
   <el>GB English Help for LibreOffice</el>
   <en>GB English Help for LibreOffice</en>
   <es>GB English Help for LibreOffice</es>
   <fi>GB English Help for LibreOffice</fi>
   <fr>GB English Help for LibreOffice</fr>
   <hi>GB English Help for LibreOffice</hi>
   <hr>GB English Help for LibreOffice</hr>
   <hu>GB English Help for LibreOffice</hu>
   <it>GB English Help for LibreOffice</it>
   <ja>GB English Help for LibreOffice</ja>
   <kk>GB English Help for LibreOffice</kk>
   <lt>GB English Help for LibreOffice</lt>
   <nl>GB English Help for LibreOffice</nl>
   <pl>GB English Help for LibreOffice</pl>
   <pt_BR>GB English Help for LibreOffice</pt_BR>
   <pt>GB English Help for LibreOffice</pt>
   <ro>GB English Help for LibreOffice</ro>
   <ru>GB English Help for LibreOffice</ru>
   <sk>GB English Help for LibreOffice</sk>
   <sv>GB Engelsk Hjälp för LibreOffice</sv>
   <tr>GB English Help for LibreOffice</tr>
   <uk>GB English Help for LibreOffice</uk>
   <zh_TW>GB English Help for LibreOffice</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-help-en-gb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-help-en-gb
</uninstall_package_names>
</app>
