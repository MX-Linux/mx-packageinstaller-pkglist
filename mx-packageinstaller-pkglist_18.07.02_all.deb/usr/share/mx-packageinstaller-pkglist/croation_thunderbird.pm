<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Croatian_thunderbird
</name>

<description>
   <am>Croatian localisation of thunderbird</am>
   <ca>Localització de Thunderbird en Croata</ca>
   <cs>Croatian localisation of thunderbird</cs>
   <de>Kroatische Lokalisierung von Thunderbird</de>
   <el>Croatian localisation of thunderbird</el>
   <en>Croatian localisation of thunderbird</en>
   <es>Croatian localisation of thunderbird</es>
   <fi>Croatian localisation of thunderbird</fi>
   <fr>Localisation croate pour Thunderbird</fr>
   <hi>Croatian localisation of thunderbird</hi>
   <hr>Croatian localisation of thunderbird</hr>
   <hu>Croatian localisation of thunderbird</hu>
   <it>Localizzazione croata di Thunderbird</it>
   <ja>Croatian localisation of thunderbird</ja>
   <kk>Croatian localisation of thunderbird</kk>
   <lt>Croatian localisation of thunderbird</lt>
   <nl>Croatian localisation of thunderbird</nl>
   <pl>Croatian localisation of thunderbird</pl>
   <pt_BR>Croatian localisation of thunderbird</pt_BR>
   <pt>Croatian localisation of thunderbird</pt>
   <ro>Croatian localisation of thunderbird</ro>
   <ru>Croatian localisation of thunderbird</ru>
   <sk>Croatian localisation of thunderbird</sk>
   <sv>Kroatisk lokalisering av thunderbird</sv>
   <tr>Croatian localisation of thunderbird</tr>
   <uk>Croatian localisation of thunderbird</uk>
   <zh_TW>Croatian localisation of thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-hr
lightning-l10n-hr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-hr
lightning-l10n-hr
</uninstall_package_names>
</app>
