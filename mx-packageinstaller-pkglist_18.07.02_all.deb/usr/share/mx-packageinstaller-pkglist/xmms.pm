<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>
XMMS
</name>

<description>
   <am>multimedia player modelled on winamp</am>
   <ca>Reproductor multimèdia modelat en winamp</ca>
   <cs>multimedia player modelled on winamp</cs>
   <de>Multimedia-Player nach dem Vorbild von Winamp</de>
   <el>multimedia player modelled on winamp</el>
   <en>multimedia player modelled on winamp</en>
   <es>multimedia player modelled on winamp</es>
   <fi>multimedia player modelled on winamp</fi>
   <fr>lecteur multimédia inspiré de winamp</fr>
   <hi>multimedia player modelled on winamp</hi>
   <hr>multimedia player modelled on winamp</hr>
   <hu>multimedia player modelled on winamp</hu>
   <it>multimedia player modelled on winamp</it>
   <ja>multimedia player modelled on winamp</ja>
   <kk>multimedia player modelled on winamp</kk>
   <lt>multimedia player modelled on winamp</lt>
   <nl>multimedia player modelled on winamp</nl>
   <pl>multimedia player modelled on winamp</pl>
   <pt_BR>multimedia player modelled on winamp</pt_BR>
   <pt>multimedia player modelled on winamp</pt>
   <ro>multimedia player modelled on winamp</ro>
   <ru>multimedia player modelled on winamp</ru>
   <sk>multimedia player modelled on winamp</sk>
   <sv>multimediaspelare formad efter winamp</sv>
   <tr>multimedia player modelled on winamp</tr>
   <uk>multimedia player modelled on winamp</uk>
   <zh_TW>multimedia player modelled on winamp</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://www.xmms.org/screenshots/main.gif</screenshot>

<preinstall>

</preinstall>

<install_package_names>
xmms
xmms-plugins-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
xmms
xmms-plugins-antix
</uninstall_package_names>
</app>
