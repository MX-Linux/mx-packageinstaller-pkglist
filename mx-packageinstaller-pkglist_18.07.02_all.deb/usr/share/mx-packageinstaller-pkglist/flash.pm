<?xml version="1.0"?>
<app>

<category>
Flash
</category>

<name>
adobe flash
</name>

<description>
   <am>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</am>
   <ca>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ca>
   <cs>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</cs>
   <de>Offizielles Adobe-Flash-Plugin für Chromium (pepperflash) und Firefox</de>
   <el>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</el>
   <en>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</en>
   <es>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</es>
   <fi>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</fi>
   <fr>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</fr>
   <hi>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</hi>
   <hr>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</hr>
   <hu>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</hu>
   <it>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</it>
   <ja>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ja>
   <kk>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</kk>
   <lt>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</lt>
   <nl>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</nl>
   <pl>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</pl>
   <pt_BR>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</pt_BR>
   <pt>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</pt>
   <ro>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ro>
   <ru>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</ru>
   <sk>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</sk>
   <sv>Officiell Adobe Flash, inkluderande plugins för chromium (pepperflash) och firefox</sv>
   <tr>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</tr>
   <uk>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</uk>
   <zh_TW>Official Adobe Flash, including plugins for chromium (pepperflash) and firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
adobe-flashplugin
adobe-flash-properties-gtk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
adobe-flashplugin
adobe-flash-properties-gtk
</uninstall_package_names>
</app>
