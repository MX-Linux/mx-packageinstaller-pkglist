<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>
Geany
</name>

<description>
   <am>fast and lightweight IDE and text editor</am>
   <ca>fast and lightweight IDE and text editor</ca>
   <cs>fast and lightweight IDE and text editor</cs>
   <de>Schneller und schlanker Texteditor und IDE</de>
   <el>fast and lightweight IDE and text editor</el>
   <en>fast and lightweight IDE and text editor</en>
   <es>fast and lightweight IDE and text editor</es>
   <fi>fast and lightweight IDE and text editor</fi>
   <fr>fast and lightweight IDE and text editor</fr>
   <hi>fast and lightweight IDE and text editor</hi>
   <hr>fast and lightweight IDE and text editor</hr>
   <hu>fast and lightweight IDE and text editor</hu>
   <it>fast and lightweight IDE and text editor</it>
   <ja>fast and lightweight IDE and text editor</ja>
   <kk>fast and lightweight IDE and text editor</kk>
   <lt>fast and lightweight IDE and text editor</lt>
   <nl>fast and lightweight IDE and text editor</nl>
   <pl>fast and lightweight IDE and text editor</pl>
   <pt_BR>fast and lightweight IDE and text editor</pt_BR>
   <pt>fast and lightweight IDE and text editor</pt>
   <ro>fast and lightweight IDE and text editor</ro>
   <ru>fast and lightweight IDE and text editor</ru>
   <sk>fast and lightweight IDE and text editor</sk>
   <sv>snabb lättvikts IDE och textredigerare</sv>
   <tr>fast and lightweight IDE and text editor</tr>
   <uk>fast and lightweight IDE and text editor</uk>
   <zh_TW>fast and lightweight IDE and text editor</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://screenshots.debian.net/screenshots/000/010/462/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
geany
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
geany
</uninstall_package_names>
</app>
