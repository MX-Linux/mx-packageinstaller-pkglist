<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>
Start Menu Button Icons
</name>

<description>
   <am>extra icons for customizing the start menu button (antechdesigns collection)</am>
   <ca>extra icons for customizing the start menu button (antechdesigns collection)</ca>
   <cs>extra icons for customizing the start menu button (antechdesigns collection)</cs>
   <de>Zusätzliche Icons zum Anpassen des Startmenüs (antechdesigns collection)</de>
   <el>extra icons for customizing the start menu button (antechdesigns collection)</el>
   <en>extra icons for customizing the start menu button (antechdesigns collection)</en>
   <es>extra icons for customizing the start menu button (antechdesigns collection)</es>
   <fi>extra icons for customizing the start menu button (antechdesigns collection)</fi>
   <fr>extra icons for customizing the start menu button (antechdesigns collection)</fr>
   <hi>extra icons for customizing the start menu button (antechdesigns collection)</hi>
   <hr>extra icons for customizing the start menu button (antechdesigns collection)</hr>
   <hu>extra icons for customizing the start menu button (antechdesigns collection)</hu>
   <it>extra icons for customizing the start menu button (antechdesigns collection)</it>
   <ja>extra icons for customizing the start menu button (antechdesigns collection)</ja>
   <kk>extra icons for customizing the start menu button (antechdesigns collection)</kk>
   <lt>extra icons for customizing the start menu button (antechdesigns collection)</lt>
   <nl>extra icons for customizing the start menu button (antechdesigns collection)</nl>
   <pl>extra icons for customizing the start menu button (antechdesigns collection)</pl>
   <pt_BR>extra icons for customizing the start menu button (antechdesigns collection)</pt_BR>
   <pt>extra icons for customizing the start menu button (antechdesigns collection)</pt>
   <ro>extra icons for customizing the start menu button (antechdesigns collection)</ro>
   <ru>extra icons for customizing the start menu button (antechdesigns collection)</ru>
   <sk>extra icons for customizing the start menu button (antechdesigns collection)</sk>
   <sv>extra ikoner för att anpassa startmeny-knappen (antechdesigns kollektion)</sv>
   <tr>extra icons for customizing the start menu button (antechdesigns collection)</tr>
   <uk>extra icons for customizing the start menu button (antechdesigns collection)</uk>
   <zh_TW>extra icons for customizing the start menu button (antechdesigns collection)</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mx-icons-start
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mx-icons-start
</uninstall_package_names>
</app>
