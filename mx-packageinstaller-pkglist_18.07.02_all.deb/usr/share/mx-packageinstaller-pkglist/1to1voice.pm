<?xml version="1.0"?>
<app>

<category>
Messaging
</category>

<name>
1-to-1 Voice
</name>

<description>
   <am>voice chat between two pc's via encrypted mumble</am>
   <ca>Xat de veu entre dos PCs amb mumble encriptat</ca>
   <cs>voice chat between two pc's via encrypted mumble</cs>
   <de>Verschlüsselte Privatgespräche mittels Mumble über SSL</de>
   <el>voice chat between two pc's via encrypted mumble</el>
   <en>voice chat between two pc's via encrypted mumble</en>
   <es>voice chat between two pc's via encrypted mumble</es>
   <fi>voice chat between two pc's via encrypted mumble</fi>
   <fr>Échanges vocaux chiffrés entre deux PC via mumble</fr>
   <hi>voice chat between two pc's via encrypted mumble</hi>
   <hr>voice chat between two pc's via encrypted mumble</hr>
   <hu>voice chat between two pc's via encrypted mumble</hu>
   <it>Chat voce tra due pc attraverso mumble in forma criptata</it>
   <ja>voice chat between two pc's via encrypted mumble</ja>
   <kk>voice chat between two pc's via encrypted mumble</kk>
   <lt>voice chat between two pc's via encrypted mumble</lt>
   <nl>voice chat tussen twee PCs via beveiligde mumble</nl>
   <pl>voice chat between two pc's via encrypted mumble</pl>
   <pt_BR>voice chat between two pc's via encrypted mumble</pt_BR>
   <pt>voice chat between two pc's via encrypted mumble</pt>
   <ro>voice chat between two pc's via encrypted mumble</ro>
   <ru>voice chat between two pc's via encrypted mumble</ru>
   <sk>voice chat between two pc's via encrypted mumble</sk>
   <sv>röstchatt mellan två pc's via encrypted mumble</sv>
   <tr>voice chat between two pc's via encrypted mumble</tr>
   <uk>voice chat between two pc's via encrypted mumble</uk>
   <zh_TW>voice chat between two pc's via encrypted mumble</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
1-to-1-voice-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
1-to-1-voice-antix
</uninstall_package_names>
</app>
