<?xml version="1.0"?>
<app>

<category>
Utility
</category>

<name>
Streamlight
</name>

<description>
   <am>View Youtube Videos outside the browser by selecting links</am>
   <ca>View Youtube Videos outside the browser by selecting links</ca>
   <cs>View Youtube Videos outside the browser by selecting links</cs>
   <de>Anzeigen von Videos von Youtube und andere Services außerhalb des Browsers durch Auswahl von Links</de>
   <el>View Youtube Videos outside the browser by selecting links</el>
   <en>View Youtube Videos outside the browser by selecting links</en>
   <es>View Youtube Videos outside the browser by selecting links</es>
   <fi>View Youtube Videos outside the browser by selecting links</fi>
   <fr>View Youtube Videos outside the browser by selecting links</fr>
   <hi>View Youtube Videos outside the browser by selecting links</hi>
   <hr>View Youtube Videos outside the browser by selecting links</hr>
   <hu>View Youtube Videos outside the browser by selecting links</hu>
   <it>View Youtube Videos outside the browser by selecting links</it>
   <ja>View Youtube Videos outside the browser by selecting links</ja>
   <kk>View Youtube Videos outside the browser by selecting links</kk>
   <lt>View Youtube Videos outside the browser by selecting links</lt>
   <nl>View Youtube Videos outside the browser by selecting links</nl>
   <pl>View Youtube Videos outside the browser by selecting links</pl>
   <pt_BR>View Youtube Videos outside the browser by selecting links</pt_BR>
   <pt>View Youtube Videos outside the browser by selecting links</pt>
   <ro>View Youtube Videos outside the browser by selecting links</ro>
   <ru>View Youtube Videos outside the browser by selecting links</ru>
   <sk>View Youtube Videos outside the browser by selecting links</sk>
   <sv>Se Youtube Videos utanför webbläsaren genom att välja länkar</sv>
   <tr>View Youtube Videos outside the browser by selecting links</tr>
   <uk>View Youtube Videos outside the browser by selecting links</uk>
   <zh_TW>View Youtube Videos outside the browser by selecting links</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
streamlight-antix
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
streamlight-antix
</uninstall_package_names>
</app>
