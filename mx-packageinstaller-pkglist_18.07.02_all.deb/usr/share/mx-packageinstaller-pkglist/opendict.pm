<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Dictionary
</name>

<description>
   <am>OpenDict Dictionary</am>
   <ca>Diccionari OpenDict</ca>
   <cs>OpenDict Dictionary</cs>
   <de>OpenDict Wörterbuch</de>
   <el>OpenDict Dictionary</el>
   <en>OpenDict Dictionary</en>
   <es>OpenDict Dictionary</es>
   <fi>OpenDict Dictionary</fi>
   <fr>OpenDict Dictionary</fr>
   <hi>OpenDict Dictionary</hi>
   <hr>OpenDict Dictionary</hr>
   <hu>OpenDict Dictionary</hu>
   <it>OpenDict Dictionary</it>
   <ja>OpenDict Dictionary</ja>
   <kk>OpenDict Dictionary</kk>
   <lt>OpenDict Dictionary</lt>
   <nl>OpenDict Dictionary</nl>
   <pl>OpenDict Dictionary</pl>
   <pt_BR>OpenDict Dictionary</pt_BR>
   <pt>OpenDict Dictionary</pt>
   <ro>OpenDict Dictionary</ro>
   <ru>OpenDict Dictionary</ru>
   <sk>OpenDict Dictionary</sk>
   <sv>OpenDict Ordbok</sv>
   <tr>OpenDict Dictionary</tr>
   <uk>OpenDict Dictionary</uk>
   <zh_TW>OpenDict Dictionary</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
opendict
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
opendict
</uninstall_package_names>
</app>
