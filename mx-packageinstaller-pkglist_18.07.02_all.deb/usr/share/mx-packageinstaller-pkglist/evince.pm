<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
Evince
</name>

<description>
   <am>a simple document (PostScript, PDF) viewer</am>
   <ca>a simple document (PostScript, PDF) viewer</ca>
   <cs>a simple document (PostScript, PDF) viewer</cs>
   <de>Ein einfacher Dokumentenbetrachter (PostScript, PDF)</de>
   <el>a simple document (PostScript, PDF) viewer</el>
   <en>a simple document (PostScript, PDF) viewer</en>
   <es>a simple document (PostScript, PDF) viewer</es>
   <fi>a simple document (PostScript, PDF) viewer</fi>
   <fr>visionneuse simple de documents (PostScript, PDF)</fr>
   <hi>a simple document (PostScript, PDF) viewer</hi>
   <hr>a simple document (PostScript, PDF) viewer</hr>
   <hu>a simple document (PostScript, PDF) viewer</hu>
   <it>a simple document (PostScript, PDF) viewer</it>
   <ja>a simple document (PostScript, PDF) viewer</ja>
   <kk>a simple document (PostScript, PDF) viewer</kk>
   <lt>a simple document (PostScript, PDF) viewer</lt>
   <nl>a simple document (PostScript, PDF) viewer</nl>
   <pl>a simple document (PostScript, PDF) viewer</pl>
   <pt_BR>a simple document (PostScript, PDF) viewer</pt_BR>
   <pt>a simple document (PostScript, PDF) viewer</pt>
   <ro>a simple document (PostScript, PDF) viewer</ro>
   <ru>a simple document (PostScript, PDF) viewer</ru>
   <sk>a simple document (PostScript, PDF) viewer</sk>
   <sv>en enkel dokument (PostScript, PDF) läsare</sv>
   <tr>a simple document (PostScript, PDF) viewer</tr>
   <uk>a simple document (PostScript, PDF) viewer</uk>
   <zh_TW>a simple document (PostScript, PDF) viewer</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/840/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
evince
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
evince
</uninstall_package_names>
</app>
