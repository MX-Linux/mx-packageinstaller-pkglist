<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>
SuperTuxKart
</name>

<description>
   <am>Mario kart style racing</am>
   <ca>Mario kart style racing</ca>
   <cs>Mario kart style racing</cs>
   <de>Mario-Kart-Rennen</de>
   <el>Mario kart style racing</el>
   <en>Mario kart style racing</en>
   <es>Mario kart style racing</es>
   <fi>Mario kart style racing</fi>
   <fr>Jeu de courses de type Mario-kart</fr>
   <hi>Mario kart style racing</hi>
   <hr>Mario kart style racing</hr>
   <hu>Mario kart style racing</hu>
   <it>Mario kart style racing</it>
   <ja>Mario kart style racing</ja>
   <kk>Mario kart style racing</kk>
   <lt>Mario kart style racing</lt>
   <nl>Mario kart style racing</nl>
   <pl>Mario kart style racing</pl>
   <pt_BR>Mario kart style racing</pt_BR>
   <pt>Mario kart style racing</pt>
   <ro>Mario kart style racing</ro>
   <ru>Mario kart style racing</ru>
   <sk>Mario kart style racing</sk>
   <sv>Mario kart stil racing</sv>
   <tr>Mario kart style racing</tr>
   <uk>Mario kart style racing</uk>
   <zh_TW>Mario kart style racing</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/727/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
supertuxkart
supertuxkart-data
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
supertuxkart
supertuxkart-data
</uninstall_package_names>
</app>
