<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Croatian
</name>

<description>
   <am>Croatian Language Meta-Package</am>
   <ca>Meta-paquet per llengua Croata</ca>
   <cs>Croatian Language Meta-Package</cs>
   <de>Kroatisches Sprach-Meta-Paket</de>
   <el>Croatian Language Meta-Package</el>
   <en>Croatian Language Meta-Package</en>
   <es>Croatian Language Meta-Package</es>
   <fi>Croatian Language Meta-Package</fi>
   <fr>Méta-Paquet pour langue croate</fr>
   <hi>Croatian Language Meta-Package</hi>
   <hr>Croatian Language Meta-Package</hr>
   <hu>Croatian Language Meta-Package</hu>
   <it>Meta-pacchetto della lingua croata</it>
   <ja>Croatian Language Meta-Package</ja>
   <kk>Croatian Language Meta-Package</kk>
   <lt>Croatian Language Meta-Package</lt>
   <nl>Croatian Language Meta-Package</nl>
   <pl>Croatian Language Meta-Package</pl>
   <pt_BR>Croatian Language Meta-Package</pt_BR>
   <pt>Croatian Language Meta-Package</pt>
   <ro>Croatian Language Meta-Package</ro>
   <ru>Croatian Language Meta-Package</ru>
   <sk>Croatian Language Meta-Package</sk>
   <sv>Kroatiskt Språk Meta-Paket</sv>
   <tr>Croatian Language Meta-Package</tr>
   <uk>Croatian Language Meta-Package</uk>
   <zh_TW>Croatian Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-hr
myspell-hr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-hr
myspell-hr
</uninstall_package_names>
</app>
