<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Polish_Firefox
</name>

<description>
   <am>Polish localisation of Firefox</am>
   <ca>Localització de Firefox en Polonès</ca>
   <cs>Polish localisation of Firefox</cs>
   <de>Polnische Lokalisierung von Firefox</de>
   <el>Polish localisation of Firefox</el>
   <en>Polish localisation of Firefox</en>
   <es>Polish localisation of Firefox</es>
   <fi>Polish localisation of Firefox</fi>
   <fr>Polish localisation of Firefox</fr>
   <hi>Polish localisation of Firefox</hi>
   <hr>Polish localisation of Firefox</hr>
   <hu>Polish localisation of Firefox</hu>
   <it>Polish localisation of Firefox</it>
   <ja>Polish localisation of Firefox</ja>
   <kk>Polish localisation of Firefox</kk>
   <lt>Polish localisation of Firefox</lt>
   <nl>Polish localisation of Firefox</nl>
   <pl>Polish localisation of Firefox</pl>
   <pt_BR>Polish localisation of Firefox</pt_BR>
   <pt>Polish localisation of Firefox</pt>
   <ro>Polish localisation of Firefox</ro>
   <ru>Polish localisation of Firefox</ru>
   <sk>Polish localisation of Firefox</sk>
   <sv>Polsk lokalisering av Firefox</sv>
   <tr>Polish localisation of Firefox</tr>
   <uk>Polish localisation of Firefox</uk>
   <zh_TW>Polish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-pl
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-pl
</uninstall_package_names>
</app>
