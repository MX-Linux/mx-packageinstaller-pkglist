<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>
Simple Card Games
</name>

<description>
   <am>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</am>
   <ca>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</ca>
   <cs>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</cs>
   <de>Einfache Desktop-Karten- und Puzzlespiele (Solitaire, Herzen, Minen, etc.)</de>
   <el>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</el>
   <en>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</en>
   <es>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</es>
   <fi>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</fi>
   <fr>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</fr>
   <hi>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</hi>
   <hr>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</hr>
   <hu>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</hu>
   <it>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</it>
   <ja>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</ja>
   <kk>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</kk>
   <lt>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</lt>
   <nl>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</nl>
   <pl>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</pl>
   <pt_BR>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</pt_BR>
   <pt>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</pt>
   <ro>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</ro>
   <ru>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</ru>
   <sk>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</sk>
   <sv>Enkla skrivbords kort och pusselspel (patiens, hjärter, minor, etc)</sv>
   <tr>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</tr>
   <uk>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</uk>
   <zh_TW>Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/909/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gnome-games
gnome-hearts
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gnome-games
gnome-hearts
</uninstall_package_names>
</app>
