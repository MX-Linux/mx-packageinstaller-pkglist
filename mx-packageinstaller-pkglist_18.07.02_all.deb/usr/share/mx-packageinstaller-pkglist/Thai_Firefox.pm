<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Thai_Firefox
</name>

<description>
   <am>Thai localisation of Firefox</am>
   <ca>Localització de Firefox en Tailandès</ca>
   <cs>Thai localisation of Firefox</cs>
   <de>Thailändische Lokalisierung von Firefox</de>
   <el>Thai localisation of Firefox</el>
   <en>Thai localisation of Firefox</en>
   <es>Thai localisation of Firefox</es>
   <fi>Thai localisation of Firefox</fi>
   <fr>Thai localisation of Firefox</fr>
   <hi>Thai localisation of Firefox</hi>
   <hr>Thai localisation of Firefox</hr>
   <hu>Thai localisation of Firefox</hu>
   <it>Thai localisation of Firefox</it>
   <ja>Thai localisation of Firefox</ja>
   <kk>Thai localisation of Firefox</kk>
   <lt>Thai localisation of Firefox</lt>
   <nl>Thai localisation of Firefox</nl>
   <pl>Thai localisation of Firefox</pl>
   <pt_BR>Thai localisation of Firefox</pt_BR>
   <pt>Thai localisation of Firefox</pt>
   <ro>Thai localisation of Firefox</ro>
   <ru>Thai localisation of Firefox</ru>
   <sk>Thai localisation of Firefox</sk>
   <sv>Thailändsk lokalisering av Firefox</sv>
   <tr>Thai localisation of Firefox</tr>
   <uk>Thai localisation of Firefox</uk>
   <zh_TW>Thai localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-th
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-th
</uninstall_package_names>
</app>
