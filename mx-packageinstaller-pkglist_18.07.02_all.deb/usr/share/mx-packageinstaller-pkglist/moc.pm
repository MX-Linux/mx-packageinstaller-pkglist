<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>
MOC
</name>

<description>
   <am>a console audio player designed to be powerful and easy to use</am>
   <ca>a console audio player designed to be powerful and easy to use</ca>
   <cs>a console audio player designed to be powerful and easy to use</cs>
   <de>Ein Konsolen-Audio-Player, der leistungsstark und einfach zu bedienen ist.</de>
   <el>a console audio player designed to be powerful and easy to use</el>
   <en>a console audio player designed to be powerful and easy to use</en>
   <es>a console audio player designed to be powerful and easy to use</es>
   <fi>a console audio player designed to be powerful and easy to use</fi>
   <fr>a console audio player designed to be powerful and easy to use</fr>
   <hi>a console audio player designed to be powerful and easy to use</hi>
   <hr>a console audio player designed to be powerful and easy to use</hr>
   <hu>a console audio player designed to be powerful and easy to use</hu>
   <it>a console audio player designed to be powerful and easy to use</it>
   <ja>a console audio player designed to be powerful and easy to use</ja>
   <kk>a console audio player designed to be powerful and easy to use</kk>
   <lt>a console audio player designed to be powerful and easy to use</lt>
   <nl>a console audio player designed to be powerful and easy to use</nl>
   <pl>a console audio player designed to be powerful and easy to use</pl>
   <pt_BR>a console audio player designed to be powerful and easy to use</pt_BR>
   <pt>a console audio player designed to be powerful and easy to use</pt>
   <ro>a console audio player designed to be powerful and easy to use</ro>
   <ru>a console audio player designed to be powerful and easy to use</ru>
   <sk>a console audio player designed to be powerful and easy to use</sk>
   <sv>en konsol-ljudspelare designad för att vara kraftfull och lättanvänd</sv>
   <tr>a console audio player designed to be powerful and easy to use</tr>
   <uk>a console audio player designed to be powerful and easy to use</uk>
   <zh_TW>a console audio player designed to be powerful and easy to use</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/008/410/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
moc
moc-ffmpeg-plugin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
moc
moc-ffmpeg-plugin
</uninstall_package_names>
</app>
