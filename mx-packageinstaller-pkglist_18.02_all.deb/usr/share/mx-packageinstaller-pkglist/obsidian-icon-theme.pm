<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>  
Obsidian Icon Theme
</name>

<description>  
an updated/refreshed Faenza-ish icon theme with many colour choices
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
obsidian-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
obsidian-icon-theme
</uninstall_package_names>
</app>
