<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>
KDE5 Standard
</name>

<description>
Installs kde-standard, kde-plasma-desktop
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
kde-standard
kde-plasma-desktop
</install_package_names>

<postinstall>

</postinstall>

<uninstall_package_names>
kde-standard
kde-standard
</uninstall_package_names>

</app>
