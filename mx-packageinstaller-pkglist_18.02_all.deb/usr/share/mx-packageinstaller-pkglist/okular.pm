<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>  
Okular
</name>

<description>  
a universal document viewer -WARNING- pulls in elements of KDE
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/644/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
okular
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
okular
</uninstall_package_names>
</app>
