<?xml version="1.0"?>
<app>

<category>
Video
</category>

<name>  
Kdenlive
</name>

<description>  
the KDE video editor
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/004/462/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
kdenlive
frei0r-plugins
breeze-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
kdenlive
frei0r-plugins
</uninstall_package_names>
</app>