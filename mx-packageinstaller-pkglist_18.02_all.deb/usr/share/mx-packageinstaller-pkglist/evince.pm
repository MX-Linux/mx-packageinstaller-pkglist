<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>  
Evince
</name>

<description>  
a simple document (PostScript, PDF) viewer
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/840/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
evince
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
evince
</uninstall_package_names>
</app>
