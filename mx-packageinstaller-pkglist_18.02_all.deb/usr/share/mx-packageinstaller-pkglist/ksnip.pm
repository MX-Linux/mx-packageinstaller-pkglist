<?xml version="1.0"?>
<app>


<category>
Screenshot Utilities
</category>

<name>  
ksnip
</name>

<description>  
Qt (not kde) -based screenshot tool inspired by the Windows Snipping Tools
</description>

<installable>
all
</installable>

<screenshot>https://a.fsdn.com/con/app/proj/ksnip/screenshots/32b0eaefbc23f9053d9f2f68065fc2bcbb93.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
ksnip
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
ksnip
</uninstall_package_names>

</app>
