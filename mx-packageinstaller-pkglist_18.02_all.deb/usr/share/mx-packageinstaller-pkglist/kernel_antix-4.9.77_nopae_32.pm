<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
antiX 32 bit no-pae
</name>

<description>  
antiX 4.9.77 kernel, 32 bit no-pae
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.77-antix.1-486-smp
linux-headers-4.9.77-antix.1-486-smp
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.77-antix.1-486-smp
linux-headers-4.9.77-antix.1-486-smp
</uninstall_package_names>
</app>
