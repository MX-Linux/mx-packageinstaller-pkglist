<?xml version="1.0"?>
<app>

<category>
Children
</category>

<name>  
Primary
</name>

<description>  
Primary. Includes: celestia-gnome, gcompris, laby, lybniz, ri-li, stellarium, tuxmath, tuxpaint, tuxtype, and marble
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gcompris
gcompris-sound-en
laby
lybniz
ri-li
stellarium
tuxmath
tuxpaint
tuxtype
marble-qt
marble-plugins
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gcompris
gcompris-sound-en
laby
lybniz
ri-li
stellarium
tuxmath
tuxpaint
tuxtype
marble-qt
marble-plugins
</uninstall_package_names>
</app>
