<?xml version="1.0"?>
<app>

<category>
Development
</category>

<name>  
Geany 
</name>

<description>  
fast and lightweight IDE and text editor
</description>

<installable>
all
</installable>

<screenshot>http://screenshots.debian.net/screenshots/000/010/462/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
geany
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
geany
</uninstall_package_names>
</app>
