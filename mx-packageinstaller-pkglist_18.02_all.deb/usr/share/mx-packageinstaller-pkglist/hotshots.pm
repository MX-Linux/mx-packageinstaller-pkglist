<?xml version="1.0"?>
<app>


<category>
Screenshot Utilities
</category>

<name>  
Hotshots
</name>

<description>  
a Qt-4 based advanced screencapture app
</description>

<installable>
all
</installable>

<screenshot>http://ubuntuhandbook.org/wp-content/uploads/2013/07/HotShots-300x248.jpg</screenshot>

<preinstall>

</preinstall>

<install_package_names>
hotshots
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
hotshots
</uninstall_package_names>

</app>
