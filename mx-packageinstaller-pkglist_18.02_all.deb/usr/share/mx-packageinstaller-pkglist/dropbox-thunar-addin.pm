<?xml version="1.0"?>
<app>

<category>
Network
</category>

<name>  
Dropbox Thunar Addin
</name>

<description>  
Thunar Addin for Dropbox file sync utility
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunar-dropbox-plugin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunar-dropbox-plugin
</uninstall_package_names>
</app>
