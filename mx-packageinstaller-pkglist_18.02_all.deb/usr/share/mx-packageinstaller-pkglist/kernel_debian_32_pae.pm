<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
Debian 32 bit w/pae
</name>

<description>  
Default Debian 4.9 32bit linux kernel w/PAE
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.0-5-686-pae
linux-headers-4.9.0-5-686-pae
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.0-5-686-pae
linux-headers-4.9.0-5-686-pae
</uninstall_package_names>
</app>
