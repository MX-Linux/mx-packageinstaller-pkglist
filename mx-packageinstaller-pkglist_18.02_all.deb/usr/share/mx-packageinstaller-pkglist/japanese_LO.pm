<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Japanses_Libreoffice
</name>

<description>  
Japanese localisation of LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-ja
	libreoffice-help-ja
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
        libreoffice-draw     
        libreoffice-impress 
        libreoffice-math
        libreoffice-writer
	libreoffice-l10n-ja
	libreoffice-help-ja
</uninstall_package_names>
</app>
