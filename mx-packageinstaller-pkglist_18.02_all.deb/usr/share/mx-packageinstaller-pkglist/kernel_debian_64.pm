<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
Debian 64 bit
</name>

<description>  
Default Debian 4.9 kernel Meltdown patched, 64bit 
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.0-5-amd64
linux-headers-4.9.0-5-amd64
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.0-5-amd64
linux-headers-4.9.0-5-amd64
</uninstall_package_names>
</app>
