<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
Debian 32 bit no-pae
</name>

<description>  
Default Debian 4.9 32bit linux kernel, no-PAE, single core
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.0-5-686
linux-headers-4.9.0-5-686
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.0-5-686
linux-headers-4.9.0-5-686
</uninstall_package_names>
</app>
