<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
gThumb
</name>

<description>  
advanced image viewer and browser
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/461/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gthumb
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gthumb
</uninstall_package_names>
</app>
