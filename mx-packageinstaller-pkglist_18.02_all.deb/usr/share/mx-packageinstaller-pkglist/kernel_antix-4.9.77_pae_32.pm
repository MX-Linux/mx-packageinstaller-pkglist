<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
antix 32-bit pae
</name>

<description>  
antiX 4.9.77 kernel, 32 bit pae
</description>

<installable>
32
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.77-antix.1-686-smp-pae
linux-headers-4.9.77-antix.1-686-smp-pae
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.77-antix.1-686-smp-pae
linux-headers-4.9.77-antix.1-686-smp-pae
</uninstall_package_names>
</app>
