<?xml version="1.0"?>
<app>

<category>
Themes
</category>

<name>  
Adwaita Dark WM Themes
</name>

<description>  
Window Manager Themes to match the Obsidian-2 Gtk Theme
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
adwaita-dark-squared-xfce-wm-theme 
adwaita-dark-xfce-wm-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
adwaita-dark-squared-xfce-wm-theme 
adwaita-dark-xfce-wm-theme
</uninstall_package_names>
</app>
