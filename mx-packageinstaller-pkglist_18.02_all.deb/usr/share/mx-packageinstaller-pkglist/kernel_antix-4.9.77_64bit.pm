<?xml version="1.0"?>
<app>

<category>
Kernels
</category>

<name>  
antiX 64 bit
</name>

<description>  
antiX 4.9.77 kernel Meltdown patched, 64 bit 
</description>

<installable>
64
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
linux-image-4.9.77-antix.1-amd64-smp
linux-headers-4.9.77-antix.1-amd64-smp
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
linux-image-4.9.77-antix.1-amd64-smp
linux-headers-4.9.77-antix.1-amd64-smp
</uninstall_package_names>
</app>
