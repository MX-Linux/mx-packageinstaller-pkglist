<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>  
Budgie Desktop
</name>

<description>  
a lightweight desktop environment
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>
</preinstall>

<install_package_names>
budgie-desktop
gnome-tweak-tool
budgie-desktop-doc
</install_package_names>

<postinstall>

</postinstall>

<uninstall_package_names>
budgie-desktop
gnome-tweak-tool
budgie-desktop-doc
</uninstall_package_names>

</app>
