<?xml version="1.0"?>
<app>

<category>
Window Managers
</category>

<name>  
Compiz
</name>

<description>  
OpenGL Window Manager with compositing
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
compiz
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
compiz
compiz-core 
compiz-fusion-plugins-experimental 
compiz-fusion-plugins-extra 
compiz-fusion-plugins-main 
compiz-gtk
compiz-plugins 
compizconfig-settings-manager 
emerald 
emerald-themes 
fusion-icon 
libcompizconfig0
libemeraldengine0 
python-compizconfig 
simple-ccsm
</uninstall_package_names>
</app>