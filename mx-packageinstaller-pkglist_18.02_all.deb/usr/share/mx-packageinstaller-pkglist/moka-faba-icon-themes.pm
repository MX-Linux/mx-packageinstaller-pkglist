<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>  
Moka/Faba Icon Themes
</name>

<description>  
a comprehensive icon set with a uniform flat "rounded square" look
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
moka-icon-theme
faba-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
moka-icon-theme
faba-icon-theme
</uninstall_package_names>
</app>
