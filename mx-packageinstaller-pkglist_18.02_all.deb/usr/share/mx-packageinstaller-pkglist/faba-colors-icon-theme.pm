<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>  
Faba Icon Colors
</name>

<description>  
a Faba icon theme with many colour choices
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
faba-colors-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
faba-colors-icon-theme
</uninstall_package_names>
</app>
