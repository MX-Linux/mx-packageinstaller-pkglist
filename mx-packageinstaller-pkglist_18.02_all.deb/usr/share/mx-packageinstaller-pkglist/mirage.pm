<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
Mirage
</name>

<description>  
fast and simple image viewer
</description>

<installable>
all
</installable>

<screenshot>http://screenshots.debian.net/screenshots/000/005/675/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
mirage
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
mirage
</uninstall_package_names>
</app>
