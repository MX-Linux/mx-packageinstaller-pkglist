<?xml version="1.0"?>
<app>


<category>
Screenshot Utilities
</category>

<name>  
Shutter
</name>

<description>  
a feature rich screenshot app
</description>

<installable>
all
</installable>

<screenshot>http://shutter-project.org/wp-content/uploads/key_feature_030.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
shutter
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
shutter
</uninstall_package_names>

</app>
