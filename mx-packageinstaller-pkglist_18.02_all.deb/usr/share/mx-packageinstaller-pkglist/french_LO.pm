<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
French_Libreoffice
</name>

<description>  
French Language Meta-Package for LibreOffice
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-fr
libreoffice-help-fr
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
libreoffice-calc
libreoffice-draw     
libreoffice-impress 
libreoffice-math
libreoffice-writer
libreoffice-l10n-fr
libreoffice-help-fr
</uninstall_package_names>
</app>
