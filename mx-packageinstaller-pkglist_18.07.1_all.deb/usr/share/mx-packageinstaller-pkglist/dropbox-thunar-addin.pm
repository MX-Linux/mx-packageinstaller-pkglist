<?xml version="1.0"?>
<app>

<category>
Network
</category>

<name>
Dropbox Thunar Addin
</name>

<description>
   <am>Thunar Addin for Dropbox file sync utility</am>
   <ca>Thunar Addin for Dropbox file sync utility</ca>
   <cs>Thunar Addin for Dropbox file sync utility</cs>
   <de>Thunar-Erweiterung für Dropbox Dateisynchronisationsprogramm</de>
   <el>Thunar Addin for Dropbox file sync utility</el>
   <en>Thunar Addin for Dropbox file sync utility</en>
   <es>Thunar Addin for Dropbox file sync utility</es>
   <fi>Thunar Addin for Dropbox file sync utility</fi>
   <fr>Plugin Thunar pour utilitaire de synchronisation de fichier Dropbox</fr>
   <hi>Thunar Addin for Dropbox file sync utility</hi>
   <hr>Thunar Addin for Dropbox file sync utility</hr>
   <hu>Thunar Addin for Dropbox file sync utility</hu>
   <it>Thunar Addin for Dropbox file sync utility</it>
   <ja>Thunar Addin for Dropbox file sync utility</ja>
   <kk>Thunar Addin for Dropbox file sync utility</kk>
   <lt>Thunar Addin for Dropbox file sync utility</lt>
   <nl>Thunar Addin for Dropbox file sync utility</nl>
   <pl>Thunar Addin for Dropbox file sync utility</pl>
   <pt_BR>Thunar Addin for Dropbox file sync utility</pt_BR>
   <pt>Thunar Addin for Dropbox file sync utility</pt>
   <ro>Thunar Addin for Dropbox file sync utility</ro>
   <ru>Thunar Addin for Dropbox file sync utility</ru>
   <sk>Thunar Addin for Dropbox file sync utility</sk>
   <sv>Thunar tillägg för Dropbox filsynkroniserings-redskap</sv>
   <tr>Thunar Addin for Dropbox file sync utility</tr>
   <uk>Thunar Addin for Dropbox file sync utility</uk>
   <zh_TW>Thunar Addin for Dropbox file sync utility</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunar-dropbox-plugin
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunar-dropbox-plugin
</uninstall_package_names>
</app>
