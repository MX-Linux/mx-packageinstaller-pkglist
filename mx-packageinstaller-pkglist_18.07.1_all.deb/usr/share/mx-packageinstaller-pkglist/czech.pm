<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Czech
</name>

<description>
   <am>Czech Language Meta-Package</am>
   <ca>Meta-paquet per llengua Txeca</ca>
   <cs>Czech Language Meta-Package</cs>
   <de>Tschechisches Sprach-Meta-Paket</de>
   <el>Czech Language Meta-Package</el>
   <en>Czech Language Meta-Package</en>
   <es>Czech Language Meta-Package</es>
   <fi>Czech Language Meta-Package</fi>
   <fr>Méta-Paquet langue tchèque</fr>
   <hi>Czech Language Meta-Package</hi>
   <hr>Czech Language Meta-Package</hr>
   <hu>Czech Language Meta-Package</hu>
   <it>Meta-pacchetto della lingua ceca</it>
   <ja>Czech Language Meta-Package</ja>
   <kk>Czech Language Meta-Package</kk>
   <lt>Czech Language Meta-Package</lt>
   <nl>Czech Language Meta-Package</nl>
   <pl>Czech Language Meta-Package</pl>
   <pt_BR>Czech Language Meta-Package</pt_BR>
   <pt>Czech Language Meta-Package</pt>
   <ro>Czech Language Meta-Package</ro>
   <ru>Czech Language Meta-Package</ru>
   <sk>Czech Language Meta-Package</sk>
   <sv>Tjeckiskt Språk Meta-Paket</sv>
   <tr>Czech Language Meta-Package</tr>
   <uk>Czech Language Meta-Package</uk>
   <zh_TW>Czech Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-cs
myspell-cs
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-cs
myspell-cs
</uninstall_package_names>
</app>
