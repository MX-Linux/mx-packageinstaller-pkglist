<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
German_Firefox
</name>

<description>
   <am>German localisation of Firefox</am>
   <ca>Localització de Firefox en Alemany</ca>
   <cs>German localisation of Firefox</cs>
   <de>Deutsche Lokalisierung von Firefox</de>
   <el>German localisation of Firefox</el>
   <en>German localisation of Firefox</en>
   <es>German localisation of Firefox</es>
   <fi>German localisation of Firefox</fi>
   <fr>German localisation of Firefox</fr>
   <hi>German localisation of Firefox</hi>
   <hr>German localisation of Firefox</hr>
   <hu>German localisation of Firefox</hu>
   <it>German localisation of Firefox</it>
   <ja>German localisation of Firefox</ja>
   <kk>German localisation of Firefox</kk>
   <lt>German localisation of Firefox</lt>
   <nl>German localisation of Firefox</nl>
   <pl>German localisation of Firefox</pl>
   <pt_BR>German localisation of Firefox</pt_BR>
   <pt>German localisation of Firefox</pt>
   <ro>German localisation of Firefox</ro>
   <ru>German localisation of Firefox</ru>
   <sk>German localisation of Firefox</sk>
   <sv>Tysk lokalisering av Firefox</sv>
   <tr>German localisation of Firefox</tr>
   <uk>German localisation of Firefox</uk>
   <zh_TW>German localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-de
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-de
</uninstall_package_names>
</app>
