<?xml version="1.0"?>
<app>

<category>
Newsreader
</category>

<name>
Pan
</name>

<description>
   <am>a gnome Usenet newsreader</am>
   <ca>a gnome Usenet newsreader</ca>
   <cs>a gnome Usenet newsreader</cs>
   <de>Ein Gnome Usenet Newsreader</de>
   <el>a gnome Usenet newsreader</el>
   <en>a gnome Usenet newsreader</en>
   <es>a gnome Usenet newsreader</es>
   <fi>a gnome Usenet newsreader</fi>
   <fr>a gnome Usenet newsreader</fr>
   <hi>a gnome Usenet newsreader</hi>
   <hr>a gnome Usenet newsreader</hr>
   <hu>a gnome Usenet newsreader</hu>
   <it>a gnome Usenet newsreader</it>
   <ja>a gnome Usenet newsreader</ja>
   <kk>a gnome Usenet newsreader</kk>
   <lt>a gnome Usenet newsreader</lt>
   <nl>a gnome Usenet newsreader</nl>
   <pl>a gnome Usenet newsreader</pl>
   <pt_BR>a gnome Usenet newsreader</pt_BR>
   <pt>a gnome Usenet newsreader</pt>
   <ro>a gnome Usenet newsreader</ro>
   <ru>a gnome Usenet newsreader</ru>
   <sk>a gnome Usenet newsreader</sk>
   <sv>en gnome Usenet nyhetsläsare</sv>
   <tr>a gnome Usenet newsreader</tr>
   <uk>a gnome Usenet newsreader</uk>
   <zh_TW>a gnome Usenet newsreader</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/000/586/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
pan
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
pan
</uninstall_package_names>
</app>
