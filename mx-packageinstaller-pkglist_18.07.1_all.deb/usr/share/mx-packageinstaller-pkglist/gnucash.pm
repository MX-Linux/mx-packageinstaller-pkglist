<?xml version="1.0"?>
<app>

<category>
Office
</category>

<name>
GnuCash
</name>

<description>
   <am>personal and small-business financial-accounting software</am>
   <ca>personal and small-business financial-accounting software</ca>
   <cs>personal and small-business financial-accounting software</cs>
   <de>Personal- und Kleinunternehmer-Finanzbuchhaltungssoftware</de>
   <el>personal and small-business financial-accounting software</el>
   <en>personal and small-business financial-accounting software</en>
   <es>personal and small-business financial-accounting software</es>
   <fi>personal and small-business financial-accounting software</fi>
   <fr>personal and small-business financial-accounting software</fr>
   <hi>personal and small-business financial-accounting software</hi>
   <hr>personal and small-business financial-accounting software</hr>
   <hu>personal and small-business financial-accounting software</hu>
   <it>personal and small-business financial-accounting software</it>
   <ja>personal and small-business financial-accounting software</ja>
   <kk>personal and small-business financial-accounting software</kk>
   <lt>personal and small-business financial-accounting software</lt>
   <nl>personal and small-business financial-accounting software</nl>
   <pl>personal and small-business financial-accounting software</pl>
   <pt_BR>personal and small-business financial-accounting software</pt_BR>
   <pt>personal and small-business financial-accounting software</pt>
   <ro>personal and small-business financial-accounting software</ro>
   <ru>personal and small-business financial-accounting software</ru>
   <sk>personal and small-business financial-accounting software</sk>
   <sv>personlig och småföretags finansiell räkenskaps-mjukvara</sv>
   <tr>personal and small-business financial-accounting software</tr>
   <uk>personal and small-business financial-accounting software</uk>
   <zh_TW>personal and small-business financial-accounting software</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/007/648/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gnucash
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gnucash
</uninstall_package_names>
</app>
