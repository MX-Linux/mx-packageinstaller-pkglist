<?xml version="1.0"?>
<app>

<category>
Icons
</category>

<name>
Faba Icon Colors
</name>

<description>
   <am>a Faba icon theme with many colour choices</am>
   <ca>a Faba icon theme with many colour choices</ca>
   <cs>a Faba icon theme with many colour choices</cs>
   <de>Ein Faba-Icon-Thema mit vielen Farbvarianten</de>
   <el>a Faba icon theme with many colour choices</el>
   <en>a Faba icon theme with many colour choices</en>
   <es>a Faba icon theme with many colour choices</es>
   <fi>a Faba icon theme with many colour choices</fi>
   <fr>a Faba icon theme with many colour choices</fr>
   <hi>a Faba icon theme with many colour choices</hi>
   <hr>a Faba icon theme with many colour choices</hr>
   <hu>a Faba icon theme with many colour choices</hu>
   <it>a Faba icon theme with many colour choices</it>
   <ja>a Faba icon theme with many colour choices</ja>
   <kk>a Faba icon theme with many colour choices</kk>
   <lt>a Faba icon theme with many colour choices</lt>
   <nl>a Faba icon theme with many colour choices</nl>
   <pl>a Faba icon theme with many colour choices</pl>
   <pt_BR>a Faba icon theme with many colour choices</pt_BR>
   <pt>a Faba icon theme with many colour choices</pt>
   <ro>a Faba icon theme with many colour choices</ro>
   <ru>a Faba icon theme with many colour choices</ru>
   <sk>a Faba icon theme with many colour choices</sk>
   <sv>ett Faba ikontema med många färgval</sv>
   <tr>a Faba icon theme with many colour choices</tr>
   <uk>a Faba icon theme with many colour choices</uk>
   <zh_TW>a Faba icon theme with many colour choices</zh_TW>
</description>

<installable>
all
</installable>

<screenshot></screenshot>

<preinstall>

</preinstall>

<install_package_names>
faba-colors-icon-theme
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
faba-colors-icon-theme
</uninstall_package_names>
</app>
