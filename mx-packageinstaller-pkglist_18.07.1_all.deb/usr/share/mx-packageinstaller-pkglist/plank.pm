<?xml version="1.0"?>
<app>

<category>
Docks
</category>

<name>
Plank
</name>

<description>
   <am>Simple but good looking dock</am>
   <ca>Simple but good looking dock</ca>
   <cs>Simple but good looking dock</cs>
   <de>Einfaches, aber gut aussehendes Dock</de>
   <el>Simple but good looking dock</el>
   <en>Simple but good looking dock</en>
   <es>Simple but good looking dock</es>
   <fi>Simple but good looking dock</fi>
   <fr>Simple but good looking dock</fr>
   <hi>Simple but good looking dock</hi>
   <hr>Simple but good looking dock</hr>
   <hu>Simple but good looking dock</hu>
   <it>Simple but good looking dock</it>
   <ja>Simple but good looking dock</ja>
   <kk>Simple but good looking dock</kk>
   <lt>Simple but good looking dock</lt>
   <nl>Simple but good looking dock</nl>
   <pl>Simple but good looking dock</pl>
   <pt_BR>Simple but good looking dock</pt_BR>
   <pt>Simple but good looking dock</pt>
   <ro>Simple but good looking dock</ro>
   <ru>Simple but good looking dock</ru>
   <sk>Simple but good looking dock</sk>
   <sv>Enkel men snygg docka</sv>
   <tr>Simple but good looking dock</tr>
   <uk>Simple but good looking dock</uk>
   <zh_TW>Simple but good looking dock</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/015/110/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
plank
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
plank
</uninstall_package_names>
</app>
