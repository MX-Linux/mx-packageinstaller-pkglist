<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Romanian
</name>

<description>
   <am>Romanian Language Meta-Package</am>
   <ca>Meta-paquet de llengua en Romanès</ca>
   <cs>Romanian Language Meta-Package</cs>
   <de>Rumänisches Sprach-Meta-Paket</de>
   <el>Romanian Language Meta-Package</el>
   <en>Romanian Language Meta-Package</en>
   <es>Romanian Language Meta-Package</es>
   <fi>Romanian Language Meta-Package</fi>
   <fr>Romanian Language Meta-Package</fr>
   <hi>Romanian Language Meta-Package</hi>
   <hr>Romanian Language Meta-Package</hr>
   <hu>Romanian Language Meta-Package</hu>
   <it>Romanian Language Meta-Package</it>
   <ja>Romanian Language Meta-Package</ja>
   <kk>Romanian Language Meta-Package</kk>
   <lt>Romanian Language Meta-Package</lt>
   <nl>Romanian Language Meta-Package</nl>
   <pl>Romanian Language Meta-Package</pl>
   <pt_BR>Romanian Language Meta-Package</pt_BR>
   <pt>Romanian Language Meta-Package</pt>
   <ro>Romanian Language Meta-Package</ro>
   <ru>Romanian Language Meta-Package</ru>
   <sk>Romanian Language Meta-Package</sk>
   <sv>Rumänskt Språk-Meta-Paket</sv>
   <tr>Romanian Language Meta-Package</tr>
   <uk>Romanian Language Meta-Package</uk>
   <zh_TW>Romanian Language Meta-Package</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
aspell-ro
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
aspell-ro
</uninstall_package_names>
</app>
