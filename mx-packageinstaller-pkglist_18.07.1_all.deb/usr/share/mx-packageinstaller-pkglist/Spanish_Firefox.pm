<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Spanish_Firefox
</name>

<description>
   <am>Spanish localisation of Firefox</am>
   <ca>Localització de Firefox en Castellà</ca>
   <cs>Spanish localisation of Firefox</cs>
   <de>Spanische Lokalisierung von Firefox</de>
   <el>Spanish localisation of Firefox</el>
   <en>Spanish localisation of Firefox</en>
   <es>Spanish localisation of Firefox</es>
   <fi>Spanish localisation of Firefox</fi>
   <fr>Spanish localisation of Firefox</fr>
   <hi>Spanish localisation of Firefox</hi>
   <hr>Spanish localisation of Firefox</hr>
   <hu>Spanish localisation of Firefox</hu>
   <it>Spanish localisation of Firefox</it>
   <ja>Spanish localisation of Firefox</ja>
   <kk>Spanish localisation of Firefox</kk>
   <lt>Spanish localisation of Firefox</lt>
   <nl>Spanish localisation of Firefox</nl>
   <pl>Spanish localisation of Firefox</pl>
   <pt_BR>Spanish localisation of Firefox</pt_BR>
   <pt>Spanish localisation of Firefox</pt>
   <ro>Spanish localisation of Firefox</ro>
   <ru>Spanish localisation of Firefox</ru>
   <sk>Spanish localisation of Firefox</sk>
   <sv>Spansk lokalisering av Firefox </sv>
   <tr>Spanish localisation of Firefox</tr>
   <uk>Spanish localisation of Firefox</uk>
   <zh_TW>Spanish localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-es-es
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-es-es
</uninstall_package_names>
</app>
