<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Slovenian_Firefox
</name>

<description>
   <am>Slovenian localisation of Firefox</am>
   <ca>Localització de Firefox en Eslovè</ca>
   <cs>Slovenian localisation of Firefox</cs>
   <de>Slowenische Lokalisierung von Firefox</de>
   <el>Slovenian localisation of Firefox</el>
   <en>Slovenian localisation of Firefox</en>
   <es>Slovenian localisation of Firefox</es>
   <fi>Slovenian localisation of Firefox</fi>
   <fr>Slovenian localisation of Firefox</fr>
   <hi>Slovenian localisation of Firefox</hi>
   <hr>Slovenian localisation of Firefox</hr>
   <hu>Slovenian localisation of Firefox</hu>
   <it>Slovenian localisation of Firefox</it>
   <ja>Slovenian localisation of Firefox</ja>
   <kk>Slovenian localisation of Firefox</kk>
   <lt>Slovenian localisation of Firefox</lt>
   <nl>Slovenian localisation of Firefox</nl>
   <pl>Slovenian localisation of Firefox</pl>
   <pt_BR>Slovenian localisation of Firefox</pt_BR>
   <pt>Slovenian localisation of Firefox</pt>
   <ro>Slovenian localisation of Firefox</ro>
   <ru>Slovenian localisation of Firefox</ru>
   <sk>Slovenian localisation of Firefox</sk>
   <sv>Slovensk lokalisering av Firefox</sv>
   <tr>Slovenian localisation of Firefox</tr>
   <uk>Slovenian localisation of Firefox</uk>
   <zh_TW>Slovenian localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sl
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sl
</uninstall_package_names>
</app>
