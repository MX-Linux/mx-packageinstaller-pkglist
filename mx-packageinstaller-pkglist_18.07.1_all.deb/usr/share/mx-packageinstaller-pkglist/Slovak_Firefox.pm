<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Slovak_Firefox
</name>

<description>
   <am>Slovak localisation of Firefox</am>
   <ca>Localització de Firefox en Eslovac</ca>
   <cs>Slovak localisation of Firefox</cs>
   <de>Slowakische Lokalisierung von Firefox</de>
   <el>Slovak localisation of Firefox</el>
   <en>Slovak localisation of Firefox</en>
   <es>Slovak localisation of Firefox</es>
   <fi>Slovak localisation of Firefox</fi>
   <fr>Slovak localisation of Firefox</fr>
   <hi>Slovak localisation of Firefox</hi>
   <hr>Slovak localisation of Firefox</hr>
   <hu>Slovak localisation of Firefox</hu>
   <it>Slovak localisation of Firefox</it>
   <ja>Slovak localisation of Firefox</ja>
   <kk>Slovak localisation of Firefox</kk>
   <lt>Slovak localisation of Firefox</lt>
   <nl>Slovak localisation of Firefox</nl>
   <pl>Slovak localisation of Firefox</pl>
   <pt_BR>Slovak localisation of Firefox</pt_BR>
   <pt>Slovak localisation of Firefox</pt>
   <ro>Slovak localisation of Firefox</ro>
   <ru>Slovak localisation of Firefox</ru>
   <sk>Slovak localisation of Firefox</sk>
   <sv>Slovakisk lokalisering av Firefox</sv>
   <tr>Slovak localisation of Firefox</tr>
   <uk>Slovak localisation of Firefox</uk>
   <zh_TW>Slovak localisation of Firefox</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
firefox-l10n-xpi-sk
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
firefox-l10n-xpi-sk
</uninstall_package_names>
</app>
