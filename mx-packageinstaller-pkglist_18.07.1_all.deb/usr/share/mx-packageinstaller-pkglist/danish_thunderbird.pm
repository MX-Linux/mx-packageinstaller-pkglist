<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>
Danish_Thunderbird
</name>

<description>
   <am>Danish localisation of Thunderbird</am>
   <ca>Localització de Thunderbird en Danès</ca>
   <cs>Danish localisation of Thunderbird</cs>
   <de>Dänische Lokalisierung von Thunderbird</de>
   <el>Danish localisation of Thunderbird</el>
   <en>Danish localisation of Thunderbird</en>
   <es>Danish localisation of Thunderbird</es>
   <fi>Danish localisation of Thunderbird</fi>
   <fr>Localisation danoise pour Thunderbird</fr>
   <hi>Danish localisation of Thunderbird</hi>
   <hr>Danish localisation of Thunderbird</hr>
   <hu>Danish localisation of Thunderbird</hu>
   <it>Localizzazione danese di Thunderbird</it>
   <ja>Danish localisation of Thunderbird</ja>
   <kk>Danish localisation of Thunderbird</kk>
   <lt>Danish localisation of Thunderbird</lt>
   <nl>Danish localisation of Thunderbird</nl>
   <pl>Danish localisation of Thunderbird</pl>
   <pt_BR>Danish localisation of Thunderbird</pt_BR>
   <pt>Danish localisation of Thunderbird</pt>
   <ro>Danish localisation of Thunderbird</ro>
   <ru>Danish localisation of Thunderbird</ru>
   <sk>Danish localisation of Thunderbird</sk>
   <sv>Dansk lokalisering av Thunderbird</sv>
   <tr>Danish localisation of Thunderbird</tr>
   <uk>Danish localisation of Thunderbird</uk>
   <zh_TW>Danish localisation of Thunderbird</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird-l10n-da
lightning-l10n-da
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird-l10n-da
lightning-l10n-da
</uninstall_package_names>
</app>
