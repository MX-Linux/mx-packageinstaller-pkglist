<?xml version="1.0"?>
<app>

<category>
Browser
</category>

<name>
Palemoon
</name>

<description>
   <am>Palemoon from the mx repo</am>
   <ca>Palemoon from the mx repo</ca>
   <cs>Palemoon from the mx repo</cs>
   <de>Pale Moon aus dem MX-Repo</de>
   <el>Palemoon from the mx repo</el>
   <en>Palemoon from the mx repo</en>
   <es>Palemoon from the mx repo</es>
   <fi>Palemoon from the mx repo</fi>
   <fr>Palemoon du dépôt MX</fr>
   <hi>Palemoon from the mx repo</hi>
   <hr>Palemoon from the mx repo</hr>
   <hu>Palemoon from the mx repo</hu>
   <it>Palemoon from the mx repo</it>
   <ja>Palemoon from the mx repo</ja>
   <kk>Palemoon from the mx repo</kk>
   <lt>Palemoon from the mx repo</lt>
   <nl>Palemoon from the mx repo</nl>
   <pl>Palemoon from the mx repo</pl>
   <pt_BR>Palemoon from the mx repo</pt_BR>
   <pt>Palemoon from the mx repo</pt>
   <ro>Palemoon from the mx repo</ro>
   <ru>Palemoon from the mx repo</ru>
   <sk>Palemoon from the mx repo</sk>
   <sv>Palemoon från mx repo</sv>
   <tr>Palemoon from the mx repo</tr>
   <uk>Palemoon from the mx repo</uk>
   <zh_TW>Palemoon from the mx repo</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>http://www.palemoon.org/images/screenshots/Win10-start-portal-th.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
palemoon
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
palemoon
</uninstall_package_names>
</app>
