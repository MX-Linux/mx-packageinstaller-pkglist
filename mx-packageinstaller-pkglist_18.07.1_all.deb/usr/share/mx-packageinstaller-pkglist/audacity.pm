<?xml version="1.0"?>
<app>

<category>
Audio
</category>

<name>
Audacity
</name>

<description>
   <am>a multi-track audio editor</am>
   <ca>Editor d'àudio multipista</ca>
   <cs>a multi-track audio editor</cs>
   <de>Ein Mehrspur-Audio-Editor</de>
   <el>a multi-track audio editor</el>
   <en>a multi-track audio editor</en>
   <es>a multi-track audio editor</es>
   <fi>a multi-track audio editor</fi>
   <fr>Un éditeur audio multi-pistes</fr>
   <hi>a multi-track audio editor</hi>
   <hr>a multi-track audio editor</hr>
   <hu>a multi-track audio editor</hu>
   <it>Audio editor multi-traccia</it>
   <ja>a multi-track audio editor</ja>
   <kk>a multi-track audio editor</kk>
   <lt>a multi-track audio editor</lt>
   <nl>a multi-track audio editor</nl>
   <pl>a multi-track audio editor</pl>
   <pt_BR>a multi-track audio editor</pt_BR>
   <pt>a multi-track audio editor</pt>
   <ro>a multi-track audio editor</ro>
   <ru>a multi-track audio editor</ru>
   <sk>a multi-track audio editor</sk>
   <sv>en flerspårs ljudredigerare</sv>
   <tr>a multi-track audio editor</tr>
   <uk>a multi-track audio editor</uk>
   <zh_TW>a multi-track audio editor</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/010/385/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
audacity
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
audacity
</uninstall_package_names>
</app>
