<?xml version="1.0"?>
<app>

<category>
Media Converter
</category>

<name>
WinFF
</name>

<description>
   <am>graphical video and audio batch converter</am>
   <ca>graphical video and audio batch converter</ca>
   <cs>graphical video and audio batch converter</cs>
   <de>Grafischer Video- und Audio-Batch-Konverter</de>
   <el>graphical video and audio batch converter</el>
   <en>graphical video and audio batch converter</en>
   <es>graphical video and audio batch converter</es>
   <fi>graphical video and audio batch converter</fi>
   <fr>convertisseur vidéo et audio</fr>
   <hi>graphical video and audio batch converter</hi>
   <hr>graphical video and audio batch converter</hr>
   <hu>graphical video and audio batch converter</hu>
   <it>graphical video and audio batch converter</it>
   <ja>graphical video and audio batch converter</ja>
   <kk>graphical video and audio batch converter</kk>
   <lt>graphical video and audio batch converter</lt>
   <nl>graphical video and audio batch converter</nl>
   <pl>graphical video and audio batch converter</pl>
   <pt_BR>graphical video and audio batch converter</pt_BR>
   <pt>graphical video and audio batch converter</pt>
   <ro>graphical video and audio batch converter</ro>
   <ru>graphical video and audio batch converter</ru>
   <sk>graphical video and audio batch converter</sk>
   <sv>grafisk video och ljud mass-konverterare</sv>
   <tr>graphical video and audio batch converter</tr>
   <uk>graphical video and audio batch converter</uk>
   <zh_TW>graphical video and audio batch converter</zh_TW>
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/557/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
winff
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
winff
</uninstall_package_names>
</app>
