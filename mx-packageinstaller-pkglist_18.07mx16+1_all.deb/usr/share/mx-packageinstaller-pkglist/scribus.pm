<?xml version="1.0"?>
<app>

<category>
Graphics
</category>

<name>  
Scribus
</name>

<description>  
a desktop page layout program
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/005/761/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
scribus
scribus-template
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
scribus
scribus-template
</uninstall_package_names>
</app>