<?xml version="1.0"?>
<app>

<category>
Language
</category>

<name>  
Vietnamese_Input_fcitx
</name>

<description>  
Vietnamese Fonts and fcitx
</description>

<installable>
all
</installable>

<screenshot>none</screenshot>

<preinstall>

</preinstall>

<install_package_names>
fcitx
        fcitx-config-gtk
        fcitx-frontend-all
        fcitx-frontend-fbterm
        fcitx-tools
        fcitx-ui-classic
        fcitx-ui-light 
        fcitx-unikey
	im-config
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
fcitx
        fcitx-config-gtk
        fcitx-frontend-all
        fcitx-frontend-fbterm
        fcitx-tools
        fcitx-ui-classic
        fcitx-ui-light 
        fcitx-unikey
	im-config
</uninstall_package_names>
</app>