<?xml version="1.0"?>
<app>

<category>
Games
</category>

<name>  
Simple Card Games
</name>

<description>  
Simple Desktop Card and Puzzle Games (solitare, hearts, mines, etc)
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/014/909/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
gnome-games
gnome-hearts
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
gnome-games
gnome-hearts
</uninstall_package_names>
</app>