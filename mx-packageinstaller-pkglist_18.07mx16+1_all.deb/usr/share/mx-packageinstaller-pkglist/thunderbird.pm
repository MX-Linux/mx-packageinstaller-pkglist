<?xml version="1.0"?>
<app>

<category>
Email
</category>

<name>  
Thunderbird
</name>

<description>  
Latest Thunderbird email client from MX Community
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/009/137/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
thunderbird
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
thunderbird
</uninstall_package_names>
</app>
