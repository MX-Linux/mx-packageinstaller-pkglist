<?xml version="1.0"?>
<app>

<category>
Media Center
</category>

<name>  
Kodi
</name>

<description>  
Kodi Media Center (formerly XBMC)
</description>

<installable>
all
</installable>

<screenshot>https://screenshots.debian.net/screenshots/000/013/655/large.png</screenshot>

<preinstall>

</preinstall>

<install_package_names>
kodi
</install_package_names>


<postinstall>

</postinstall>


<uninstall_package_names>
kodi
</uninstall_package_names>
</app>